/**
 * Created by dario on 23/10/17.
 */


AnaliseProtocolo = {

    atualizarProtocolo : function (codigo) {
        $.ajax({
            type: "PUT",
            url: 'retirarAnalise/',
            dataType: 'json',
            charset: 'utf-8',
            data : {
                codigo : codigo
            },
            success: function (data) {
                window.location.reload();
            },
            error: function (data) {
                window.location.reload();
            },
        });
    },

    atualizarProtocoloReprovado : function (codigo) {
        $.ajax({
            type: "PUT",
            url: 'retirarAnaliseReprovado/',
            dataType: 'json',
            charset: 'utf-8',
            data : {
                codigo : codigo
            },
            success: function (data) {
                window.location.reload();
            },
            error: function (data) {
                window.location.reload();
            },
        });
    },

    buscarFlagProtocolo : function (id) {
        $.ajax({
            type: "GET",
            url: 'buscarFlag/'+id,
            dataType: 'json',
            charset: 'utf-8',
            success: function (data) {
                //console.log(data.data.observacao.present);
                if(data.data.observacao.present == true){
                    AnaliseProtocolo.atualizarProtocoloReprovado(id);
                }else{
                    AnaliseProtocolo.atualizarProtocolo(id);
                }
            },
            error: function (data) {
                console.log("Erro inesperado");
            },
        });
    },

}

$( document ).ready(function() {

    $( ".js-btn-open-analise" ).click(function() {

        //AnaliseProtocolo.atualizarProtocolo($(this).attr('id'))
        AnaliseProtocolo.buscarFlagProtocolo($(this).attr('id'))

    });
});