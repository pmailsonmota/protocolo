/**
 * Created by dario on 04/10/17.
 */

function closeValidate() {

    $(document).keydown(function(e){

        var teclas = [116];

        if(teclas.includes(e.which)){
            return false;
        }
    });

};

function actionModal() {

    $(".js-btn-close-modal + .js-btn-close-modal").remove();

    $(".motivo_recusa_protocolo + .motivo_recusa_protocolo").remove();

    if($('.js-formulario').attr('data-tipo-formulario-modal') == "pendente_modal"){
        $(".motivo_recusa_protocolo").remove()
    }


    $(".js-btn-close-modal").on('click', function () {

        if ($('.js-formulario').attr('data-tipo-formulario-modal') == "pendente_modal") {

            EnvioSEI.buscarFlagParaFechar($(this).attr("data-codigo-protocolo-analisar"));

        }

        if ($('.js-formulario').attr('data-tipo-formulario-modal') == "reprovado_modal") {

            EnvioSEI.buscarFlagParaFecharReprovacao($(this).attr("data-codigo-protocolo-analisar"));

        }

    });
}







