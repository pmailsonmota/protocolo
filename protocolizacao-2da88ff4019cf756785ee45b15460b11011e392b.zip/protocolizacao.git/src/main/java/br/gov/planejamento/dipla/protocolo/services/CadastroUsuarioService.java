/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.services;

import br.gov.planejamento.dipla.protocolo.dto.UsuarioBrasilCidadaoDto;
import br.gov.planejamento.dipla.protocolo.entities.AcaoEnum;
import br.gov.planejamento.dipla.protocolo.entities.Grupo;
import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.entities.UsuarioBrasilCidadao;
import br.gov.planejamento.dipla.protocolo.mail.Mailer;
import br.gov.planejamento.dipla.protocolo.repositories.*;
import br.gov.planejamento.dipla.protocolo.services.exeptions.EmailUsuarioJaCadastradoException;
import br.gov.planejamento.dipla.protocolo.services.exeptions.SenhaObrigatoriaUsuarioException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author leonardo
 */
@Service
public class CadastroUsuarioService {

	@Autowired
    private LogProtocoloService logProtocoloService;
	
    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;
    
    @Autowired
    private Mailer mailer;
    
    @Transactional
    public void salvar(Usuario usuario) {
    	AcaoEnum acao=null;

        Optional<Usuario> usuarioEmailExistente = usuarioRepository.findByEmail(usuario.getEmail());
        if (usuarioEmailExistente.isPresent() && !usuarioEmailExistente.get().equals(usuario)) {
            throw new EmailUsuarioJaCadastradoException("E-mail já cadastrado");
        }

        if (usuario.isNovo() && StringUtils.isEmpty(usuario.getSenha())) {
            throw new SenhaObrigatoriaUsuarioException("Senha é obrigatória para novo usuário");
        }

        if (usuario.isNovo() || !StringUtils.isEmpty(usuario.getSenha())) {
            usuario.setSenha(this.passwordEncoder.encode(usuario.getSenha()));
            usuario.setAtivo(Boolean.TRUE);
        } else if (StringUtils.isEmpty(usuario.getSenha())) {
            Usuario usuarioExistente = usuarioRepository.findOne(usuario.getCodigo());
            usuario.setSenha(usuarioExistente.getSenha());

        }
        usuario.setConfirmacaoSenha(usuario.getSenha());
        if (!usuario.isNovo()) {
            Usuario usuarioExistente = usuarioRepository.findOne(usuario.getCodigo());
            if(usuario.getAtivo() == null) {
            	usuario.setAtivo(usuarioExistente.getAtivo());
            }
        }
        if (usuario.isNovo()){
        	acao=AcaoEnum.INSERIR;
        }else {
        	acao=AcaoEnum.ALTERAR;
        }
        usuarioRepository.saveAndFlush(usuario);
        logProtocoloService.saveLog(usuario,acao);
    }
    
    @Transactional
    public void alterarStatus(Long[] codigos, StatusUsuario statusUsuario) {
        statusUsuario.executar(codigos, usuarioRepository);
    }

    @Transactional
    public void excluir(Usuario usuario){
        usuarioRepository.delete(usuario);
    }
    @Transactional
    public void reiniciarSenha(Usuario usuario) {
        String senha;
        Optional<Usuario> usuarioOptional = usuarioRepository.findByEmail(usuario.getEmail());
        if (usuarioOptional.isPresent()) {
        	Boolean userBrasilCidadao = usuarioRepository.verificarUsuarioBrasilCidadao(usuarioOptional.get().getCodigo());
        	if ((userBrasilCidadao!=null)&&(!userBrasilCidadao)) {
        		Usuario usuarioRecuperado = usuarioOptional.get();
                senha = generatePassword();
                usuarioRecuperado.setSenha(this.passwordEncoder.encode(senha));
                usuarioRepository.save(usuarioRecuperado);
                usuario.setSenha(senha);
                mailer.enviarNovaSenha(usuario);
        	}else {
            	throw new RuntimeException("Usuário Cadastrado como Brasil Cidadão.");
            }
        }else{
            throw new RuntimeException("Email não cadastrado.");
        }        
    }


    private String generatePassword() {
        return new BigInteger(130, new SecureRandom()).toString(32);
    }
}
