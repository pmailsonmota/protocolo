package br.gov.planejamento.dipla.protocolo.repositories;

import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.entities.UsuarioBrasilCidadao;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
/**
 *
 * @author Leonardo Dias
 */
@Repository
public interface UsuarioBrasilCidadaoRepository extends JpaRepository<UsuarioBrasilCidadao, Long> {

    public List<UsuarioBrasilCidadao> findByCodigoIn(Long[] codigos);
    public Optional<UsuarioBrasilCidadao> findByUsuarioIn(Usuario usuario);
    
}
