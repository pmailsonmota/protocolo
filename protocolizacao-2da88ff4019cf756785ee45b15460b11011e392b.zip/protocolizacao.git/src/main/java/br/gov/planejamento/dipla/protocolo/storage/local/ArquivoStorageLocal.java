package br.gov.planejamento.dipla.protocolo.storage.local;

import br.gov.planejamento.dipla.protocolo.clamav.ClamavUtil;
import br.gov.planejamento.dipla.protocolo.storage.ArquivoStorage;
import br.gov.planejamento.dipla.protocolo.util.MyStringUtil;
import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

import static java.nio.file.FileSystems.getDefault;

/**
 * @author Leonardo Dias
 */
public class ArquivoStorageLocal implements ArquivoStorage {

    @Autowired
    private MyStringUtil myStringUtil;

    private static final Logger LOGGER = LoggerFactory.getLogger(ArquivoStorageLocal.class);

    private Path local;
    private Path localTemporario;
    private Path localLogo;

    public ArquivoStorageLocal(Path local) {
        this.local = local;
        criarPastas();
    }

    @Override
    public String salvarTemporariamente(MultipartFile[] files) {
        String novoNome = null;
        if (files != null && files.length > 0) {
            MultipartFile arquivo = files[0];
            novoNome = renomearArquivo(myStringUtil.removerCaracteresEspeciais(arquivo.getOriginalFilename()));
            try {
                arquivo.transferTo(new File(localTemporario.toAbsolutePath().toString() + getDefault().getSeparator() + novoNome));
            } catch (IOException e) {
                throw new RuntimeException("Erro salvando o arquivo na pasta temporária", e);
            }
        }
        return novoNome;
    }

    @Override
    public byte[] recuperarFotoTemporaria(String nome) {
        try {
            return Files.readAllBytes(localTemporario.resolve(nome));
        } catch (IOException e) {
            throw new RuntimeException("Erro lendo o arquivo temporária", e);
        }
    }

    @Override
    public byte[] recuperarLogo(String nome) {
        try {
            return Files.readAllBytes(localLogo.resolve(nome));
        } catch (IOException e) {
            throw new RuntimeException("Erro lendo o arquivo temporária", e);
        }
    }

    @Override
    public void salvar(String arquivo) {
        try {
            Files.move(localTemporario.resolve(arquivo), local.resolve(arquivo));
        } catch (IOException e) {
            throw new RuntimeException("Erro movendo o arquivo para destino final", e);
        }
    }

    @Override
    public byte[] recuperar(String nome) {
        try {
            return Files.readAllBytes(local.resolve(nome));
        } catch (IOException e) {
            throw new RuntimeException("Erro lendo o arquivo", e);
        }
    }

    @Override
    public void excluir(String arquivo) {
        try {
            Files.deleteIfExists(local.resolve(arquivo));
        } catch (IOException e) {
            LOGGER.warn(String.format("Erro apagando foto '%s'. Mensagem: %s", arquivo, e.getMessage()));
        }
    }

    @Override
    public void excluirTemporario(String arquivo) {
        try {
            Files.deleteIfExists(localTemporario.resolve(arquivo));
        } catch (IOException e) {
            LOGGER.warn(String.format("Erro apagando foto '%s'. Mensagem: %s", arquivo, e.getMessage()));
        }
    }

    private void criarPastas() {
        try {
            Files.createDirectories(local);
            localTemporario = getDefault().getPath(local.toString(), "temp");
            localLogo = getDefault().getPath(local.toString(), "logos");
            Files.createDirectories(localTemporario);
            Files.createDirectories(localLogo);

            ClassLoader loader = this.getClass().getClassLoader();

            copyFile(loader.getResource("static/images/pdf-logo.png").toString().replaceAll("file:/", ""), localLogo.toAbsolutePath().toString());

            if (LOGGER.isDebugEnabled()) {
                LOGGER.debug("Pastas criadas para salvar arquivos.");
                LOGGER.debug("Pasta default: " + local.toAbsolutePath());
                LOGGER.debug("Pasta temporária: " + localTemporario.toAbsolutePath());
            }

            excluirTodosTemporarios();

        } catch (IOException e) {
            throw new RuntimeException("Erro criando pasta para salvar arquivo", e);
        }
    }

    private void excluirTodosTemporarios() {
        try {
            FileUtils.cleanDirectory(localTemporario.toFile());
        } catch (IOException e) {
            LOGGER.warn(String.format("Erro Mensagem: %s", e.getMessage()));
        }
    }

    private void copyFile(String filePath, String dir) {
        Path sourceFile = Paths.get(filePath);
        Path targetDir = Paths.get(dir);
        Path targetFile = targetDir.resolve(sourceFile.getFileName());

        try {

            Files.copy(sourceFile, targetFile);

        } catch (FileAlreadyExistsException ex) {
            System.err.format("File %s already exists.", targetFile);
        } catch (IOException ex) {
            System.err.format("I/O Error when copying file");
        }
    }

    private String renomearArquivo(String nomeOriginal) {
        String novoNome = UUID.randomUUID().toString() + "_" + nomeOriginal;

        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(String.format("Nome original: %s, novo nome: %s", nomeOriginal, novoNome));
        }

        return novoNome;
    }
}
