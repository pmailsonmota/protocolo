package br.gov.planejamento.dipla.protocolo.controllers;

import br.gov.planejamento.dipla.protocolo.controllers.page.PageWrapper;
import br.gov.planejamento.dipla.protocolo.controllers.sessions.ArquivosSession;
import br.gov.planejamento.dipla.protocolo.dto.ArquivoDTO;
import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
import br.gov.planejamento.dipla.protocolo.entities.StatusEnum;
import br.gov.planejamento.dipla.protocolo.repositories.ProtocoloRepository;
import br.gov.planejamento.dipla.protocolo.repositories.TiposDocumentoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.UsuarioRepository;
import br.gov.planejamento.dipla.protocolo.repositories.filter.ProtocoloFilter;
import br.gov.planejamento.dipla.protocolo.security.UsuarioSistema;
import br.gov.planejamento.dipla.protocolo.services.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.util.Optional;
import br.gov.planejamento.dipla.protocolo.response.Response;
import br.gov.planejamento.dipla.protocolo.dto.ProtocoloFlagDTO;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import org.hibernate.service.spi.ServiceException;


/**
 * @author Leonardo Dias
 */
@Controller
public class ProtocoloController {

    @Autowired
    private ArquivosSession arquivosSession;

    @Autowired
    private TiposDocumentoRepository tipoDocumentoRepository;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private ProtocoloRepository protocoloRepository;

    @Autowired
    private EnviarProtocoloService enviarProtocoloService;

    @Autowired
    private SalvarProtocoloService salvarProtocoloService;

    @Autowired
    private UnidadeService unidadeService;

    @Autowired
    private ProtocoloFlagService protocoloFlagService;

    @Autowired
    private EventServerService eventServerService;

    private final int DEFAULT_PAGEABLE_SIZE = 10;

    @GetMapping("/")
    public ModelAndView principal(Protocolo protocolo, @AuthenticationPrincipal UsuarioSistema usuarioSistema) {
        List<String> permissoes = usuarioRepository.permissoes(usuarioSistema.getUsuario());
        if (permissoes.contains("ROLE_CADASTRO") & usuarioSistema.getUsuario().getTemPerfilBrasilCidadao() == null) {
            ModelAndView mv = new ModelAndView("Dashboard");
            mv.addObject("usuario", usuarioSistema.getUsuario());
            mv.addObject("protocolosAprovados", protocoloRepository.protocolosAprovados());
            mv.addObject("protocolosAprovadosManualmente", protocoloRepository.protocolosAprovadosManualmente());
            mv.addObject("protocolosReprovados", protocoloRepository.protocolosReprovados());
            mv.addObject("protocolosPendentes", protocoloRepository.protocolosPendentes());
            mv.addObject("protocolosAnalise", protocoloRepository.protocolosAnalisando());
            mv.addObject("unidades", unidadeService.obterUnidades());
            return mv;
        }

        return enviar(protocolo, usuarioSistema);
    }

    @GetMapping("/pendentes")
    public ModelAndView pesquisaProtocolosPendentes(ProtocoloFilter filter, BindingResult result, @PageableDefault(size = DEFAULT_PAGEABLE_SIZE) Pageable pageable, HttpServletRequest httpServletRequest) {
        ModelAndView mv = new ModelAndView("protocolo/PesquisaProtocolosPendentes");
        filter.setStatus(StatusEnum.PENDENTE);
        PageWrapper<Protocolo> paginaWrapper = new PageWrapper<>(protocoloRepository.filtrar(filter, pageable), httpServletRequest);
        mv.addObject("protocolosAprovados", protocoloRepository.protocolosAprovados());
        mv.addObject("protocolosAprovadosManualmente", protocoloRepository.protocolosAprovadosManualmente());
        mv.addObject("protocolosReprovados", protocoloRepository.protocolosReprovados());
        mv.addObject("protocolosPendentes", protocoloRepository.protocolosPendentes());
        mv.addObject("protocolosAnalise", protocoloRepository.protocolosAnalisando());
        mv.addObject("pagina", paginaWrapper);
        return mv;
    }

    @GetMapping("/aprovados")
    public ModelAndView pesquisaProtocolosAprovados(ProtocoloFilter filter, BindingResult result, @PageableDefault(size = DEFAULT_PAGEABLE_SIZE) Pageable pageable, HttpServletRequest httpServletRequest) {
        ModelAndView mv = new ModelAndView("protocolo/PesquisaProtocolosAprovados");
        filter.setStatus(StatusEnum.APROVADO);
        PageWrapper<Protocolo> paginaWrapper = new PageWrapper<>(protocoloRepository.filtrar(filter, pageable), httpServletRequest);
        mv.addObject("protocolosAprovados", protocoloRepository.protocolosAprovados());
        mv.addObject("protocolosAprovadosManualmente", protocoloRepository.protocolosAprovadosManualmente());
        mv.addObject("protocolosReprovados", protocoloRepository.protocolosReprovados());
        mv.addObject("protocolosPendentes", protocoloRepository.protocolosPendentes());
        mv.addObject("protocolosAnalise", protocoloRepository.protocolosAnalisando());
        mv.addObject("pagina", paginaWrapper);
        return mv;
    }

    @GetMapping("/aprovadosManualmente")
    public ModelAndView pesquisaProtocolosAprovadosManualmente(ProtocoloFilter filter, BindingResult result, @PageableDefault(size = DEFAULT_PAGEABLE_SIZE) Pageable pageable, HttpServletRequest httpServletRequest) {
        ModelAndView mv = new ModelAndView("protocolo/PesquisaProtocolosAprovadosManualmente");
        filter.setStatus(StatusEnum.APROVADO_MANUALMENTE);
        PageWrapper<Protocolo> paginaWrapper = new PageWrapper<>(protocoloRepository.filtrar(filter, pageable), httpServletRequest);
        mv.addObject("protocolosAprovados", protocoloRepository.protocolosAprovados());
        mv.addObject("protocolosAprovadosManualmente", protocoloRepository.protocolosAprovadosManualmente());
        mv.addObject("protocolosReprovados", protocoloRepository.protocolosReprovados());
        mv.addObject("protocolosPendentes", protocoloRepository.protocolosPendentes());
        mv.addObject("protocolosAnalise", protocoloRepository.protocolosAnalisando());
        mv.addObject("pagina", paginaWrapper);
        return mv;
    }
    
    @GetMapping("/reprovados")
    public ModelAndView pesquisaProtocolosReprovados(ProtocoloFilter filter, BindingResult result, @PageableDefault(size = DEFAULT_PAGEABLE_SIZE) Pageable pageable, HttpServletRequest httpServletRequest) {
        ModelAndView mv = new ModelAndView("protocolo/PesquisaProtocolosReprovados");
        filter.setStatus(StatusEnum.REPROVADO);
        PageWrapper<Protocolo> paginaWrapper = new PageWrapper<>(protocoloRepository.filtrar(filter, pageable), httpServletRequest);
        mv.addObject("protocolosAprovados", protocoloRepository.protocolosAprovados());
        mv.addObject("protocolosAprovadosManualmente", protocoloRepository.protocolosAprovadosManualmente());
        mv.addObject("protocolosReprovados", protocoloRepository.protocolosReprovados());
        mv.addObject("protocolosPendentes", protocoloRepository.protocolosPendentes());
        mv.addObject("protocolosAnalise", protocoloRepository.protocolosAnalisando());
        mv.addObject("pagina", paginaWrapper);
        return mv;
    }

    @GetMapping("/analisando")
    public ModelAndView pesquisaProtocolosAnalisando(ProtocoloFilter filter, BindingResult result, @PageableDefault(size = DEFAULT_PAGEABLE_SIZE) Pageable pageable, HttpServletRequest httpServletRequest) {
        ModelAndView mv = new ModelAndView("protocolo/PesquisaProtocolosAnalisando");
        filter.setStatus(StatusEnum.ANALISANDO);
        PageWrapper<Protocolo> paginaWrapper = new PageWrapper<>(protocoloRepository.filtrar(filter, pageable), httpServletRequest);
        mv.addObject("protocolosAprovados", protocoloRepository.protocolosAprovados());
        mv.addObject("protocolosAprovadosManualmente", protocoloRepository.protocolosAprovadosManualmente());
        mv.addObject("protocolosReprovados", protocoloRepository.protocolosReprovados());
        mv.addObject("protocolosPendentes", protocoloRepository.protocolosPendentes());
        mv.addObject("protocolosAnalise", protocoloRepository.protocolosAnalisando());
        mv.addObject("pagina", paginaWrapper);
        return mv;
    }

    @GetMapping("/opcoes")
    public ModelAndView opcoes() {
        return new ModelAndView("/protocolo/OpcoesProtocolo");
    }

    @GetMapping("/enviar")
    public ModelAndView enviar(Protocolo protocolo, @AuthenticationPrincipal UsuarioSistema usuarioSistema) {
        if (StringUtils.isEmpty(protocolo.getUuid())) {
            protocolo.setUuid(UUID.randomUUID().toString());
            protocolo.setPossuiProtocoloAnterior("N");
        }
        ModelAndView mv = new ModelAndView("/protocolo/CadastroProtocolo");
        mv.addObject("usuario", usuarioSistema.getUsuario());
        mv.addObject("tiposDocumento", tipoDocumentoRepository.findByAtivo(true));
        mv.addObject("unidades", unidadeService.obterUnidades());
        return mv;
    }

    @PostMapping("/enviar")
    public ModelAndView enviar(@Valid Protocolo protocolo, BindingResult result, RedirectAttributes attributes, @AuthenticationPrincipal UsuarioSistema usuarioSistema) {
        if ("S".equals(protocolo.getPossuiProtocoloAnterior()) && StringUtils.isEmpty(protocolo.getNumeroProtocoloAnterior())) {
            result.rejectValue("numeroProtocoloAnterior", "Número do protocolo Anterior é obrigatório.", "Número do protocolo Anterior é obrigatório.");
            return enviar(protocolo, usuarioSistema);
        }

        if (result.hasErrors()) {
            return enviar(protocolo, usuarioSistema);
        }

        List<ArquivoDTO> arquivoDTOList = arquivosSession.obterArquivos(protocolo.getUuid());

        if (CollectionUtils.isEmpty(arquivoDTOList)) {
            String msg = "Nenhum arquivo anexado, favor incluir algum arquivo antes de efetuar a protocolização.";
            result.rejectValue("arquivo", msg, msg);
            return enviar(protocolo, usuarioSistema);
        }

        protocolo.setUsuario(usuarioSistema.getUsuario());
        enviarProtocoloService.enviar(protocolo, arquivoDTOList);
        attributes.addFlashAttribute("mensagem", String.format("Protocolo Nº %s salvo com sucesso.", protocolo.getNumero()));
        return new ModelAndView("redirect:/enviar");
    }

    @GetMapping("/meus-protocolos")
    public ModelAndView meusProtocolos(ProtocoloFilter filter, BindingResult result, @PageableDefault(size = DEFAULT_PAGEABLE_SIZE) Pageable pageable, HttpServletRequest httpServletRequest, @AuthenticationPrincipal UsuarioSistema usuarioSistema) {
        ModelAndView mv = new ModelAndView("protocolo/MeusProtocolos");

        PageWrapper<Protocolo> paginaWrapper = new PageWrapper<>(protocoloRepository.filtrarMeusProtocolos(usuarioSistema.getUsuario(), filter, pageable), httpServletRequest);
        mv.addObject("pagina", paginaWrapper);
       
        return mv;
    }
    
    @GetMapping("/reenvioRecibo/{codigo}")
    public @ResponseBody
    ResponseEntity<?> reenviarRecibo(@PathVariable("codigo") Protocolo protocolo,@RequestParam(value = "email", required = false) String email) {
        enviarProtocoloService.reenviarRecibo(protocolo,email);
        Response<String> response = new Response<String>();
        String resposta=null;
        if(!email.isEmpty()||email!=null) {
        	resposta=email;
        }
        if(!protocolo.getEmail1().isEmpty()&&protocolo.getEmail1()!=null&&protocolo.getEmail1()!="") {
        	resposta=resposta+" "+protocolo.getEmail1();
        }
        if(!protocolo.getEmail2().isEmpty()&&protocolo.getEmail2()!=null&&protocolo.getEmail2()!="") {
        	resposta=resposta+" "+protocolo.getEmail2();
        }
        if(!protocolo.getUsuario().getEmail().isEmpty()&&protocolo.getUsuario().getEmail()!=null&&protocolo.getUsuario().getEmail()!="") {
        	resposta=resposta+" "+protocolo.getUsuario().getEmail();
        }
        response.setData(resposta);
        return ResponseEntity.ok(response);
    }


    @RequestMapping("/stream")
    public SseEmitter enableNotifier(){
        //SseEmitter notifier = new SseEmitter();
        return eventServerService;
    }

    @PutMapping("/aprovar/{codigo}")
    public @ResponseBody
    ResponseEntity<?> aprovar(@PathVariable("codigo") Protocolo protocolo, @RequestParam(value = "sei", required = false) String sei, @RequestParam(value = "tipo", required = false) String tipo) {
        //SseEmitter sseEmitter = new SseEmitter();
        CompletableFuture.supplyAsync( () -> {
            try {
                enviarProtocoloService.enviarSEI( protocolo, sei, tipo );
                return "Sincronizado com Sucesso !";
            } catch (ServiceException e) {
                return e.getMessage();
            } catch (Exception e) {
                return e.getMessage();
            }
        } )
        .whenCompleteAsync( (result, throwable) -> {
            try {
                eventServerService.send( result );
            } catch (IOException e) {
                e.printStackTrace();
            }
        } )
        .exceptionally( ex -> {
            try {
                eventServerService.send( ex.getMessage() );
            } catch (Exception e) {
                e.printStackTrace();
            }
            return "erro";
        } );

        return ResponseEntity.ok().build();
    }
    
    @PutMapping("/aprovarManualmente/{sei}/{codigo}")
    public @ResponseBody
    ResponseEntity<?> aprovarManualmente(@PathVariable("sei") String sei, @PathVariable("codigo") Protocolo protocolo) {
    	protocolo.setNupe(sei);
    	salvarProtocoloService.aprovarManualmente(protocolo);
        return ResponseEntity.ok().build();
    }
    
    @GetMapping("/aprovarManualmente/{sei}")
    public ResponseEntity<Response<String>> consultarSei(@PathVariable("sei") String sei) {
    	Optional<String>  linkSei = enviarProtocoloService.consultarSei(sei);
    	Response<String> response = new Response<String>();
        if (!linkSei.isPresent()) {
            response.getErrors().add("Nº SEI não encontrado: " + sei);
            return ResponseEntity.badRequest().body(response);
        }
        response.setData(linkSei.get());
        return ResponseEntity.ok(response);
    }
    
    @PutMapping("/reprovar/{codigo}")
    public @ResponseBody
    ResponseEntity<?> reprovar(@PathVariable("codigo") Protocolo protocolo, @RequestBody String observacao) {
        protocolo.setObservacao(observacao);
        enviarProtocoloService.recusar(protocolo);
        return ResponseEntity.ok().build();
    }

    /**
     * atulizado o status de pendente para analise na tabela protocolo
     *
     * @param protocolo
     * @return ResponseEntity
     */
    @PutMapping("/atualizarFlag/{codigo}")
    public @ResponseBody
    ResponseEntity<?> atualizarflag(@PathVariable("codigo") Protocolo protocolo) {
        salvarProtocoloService.analisando(protocolo);
        return ResponseEntity.ok().build();
    }

    /**
     * atulizado o status para pendente
     *
     * @param protocolo
     * @return ResponseEntity
     */
    @PutMapping("/atuzalizarFlagPendente/{codigo}")
    public @ResponseBody
    ResponseEntity<?> atuzalizarFlagPendente(@PathVariable("codigo") Protocolo protocolo) {
        salvarProtocoloService.pendente(protocolo);
        return ResponseEntity.ok().build();
    }

    /**
     * método para reprovar o protocolo
     *
     * @param protocolo
     * @return ResponseEntity
     */
    @PutMapping("/atuzalizarFlagReprovado/{codigo}")
    public @ResponseBody
    ResponseEntity<?> atuzalizarFlagReprovado(@PathVariable("codigo") Protocolo protocolo) {
        salvarProtocoloService.reprovar(protocolo);
        return ResponseEntity.ok().build();
    }

    /**
     * método para retirar o protocolo da análise
     *
     * @param protocolo
     * @return ResponseEntity
     */
    @PutMapping("/retirarAnalise")
    public @ResponseBody
    ResponseEntity<?> retirarAnalise(@RequestParam("codigo") Protocolo protocolo) {
        salvarProtocoloService.pendente(protocolo);
        return ResponseEntity.ok().build();
    }

    /**
     * método para retirar o protocolo da análise e deixar reprovado
     *
     * @param protocolo
     * @return ResponseEntity
     */
    @PutMapping("/retirarAnaliseReprovado")
    public @ResponseBody
    ResponseEntity<?> retirarAnaliseReprovado(@RequestParam("codigo") Protocolo protocolo) {
        salvarProtocoloService.reprovar(protocolo);
        return ResponseEntity.ok().build();
    }

    /**
     * busca o status passado o código
     *
     * @param codigo
     * @return ResponseEntity
     */
    @GetMapping(value = "/buscarFlag/{codigo}")
    public ResponseEntity<Response<ProtocoloFlagDTO>> buscarStatusPorCodigp(@PathVariable("codigo") Long codigo) {
        Response<ProtocoloFlagDTO> response = new Response<ProtocoloFlagDTO>();
        Optional<Protocolo> protocolo = protocoloFlagService.buscarStatusPorCodigo(codigo);

        if (!protocolo.isPresent()) {
            response.getErrors().add("Status não encontrado para o código: " + codigo);
            return ResponseEntity.badRequest().body(response);
        }

        response.setData(this.converterProtocoloFlagDto(protocolo.get()));
        return ResponseEntity.ok(response);
    }

    /**
     * convertendo a entidade para objeto DTO
     *
     * @param protocolo
     * @return protocoloFlagDTO
     */
    private ProtocoloFlagDTO converterProtocoloFlagDto(Protocolo protocolo) {
        ProtocoloFlagDTO protocoloFlagDTO = new ProtocoloFlagDTO();
        protocoloFlagDTO.setStatus(protocolo.getStatus().toString());
        //protocoloFlagDTO.setObservacao(Optional.of(protocolo.getObservacao().toString()));
        //protocoloFlagDTO.setObservacao().ifPresent(x -> protocolo.getObservacao(x.toString()));
        protocolo.getObservacaoOpt().ifPresent(observacao -> protocoloFlagDTO.setObservacao(Optional.of(observacao.toString())));
        return protocoloFlagDTO;
    }

}
