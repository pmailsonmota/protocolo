package br.gov.planejamento.dipla.protocolo.controllers;

import br.gov.planejamento.dipla.protocolo.config.BrasilCidadaoConfig.UrlBrasilCidadao;
import br.gov.planejamento.dipla.protocolo.controllers.page.PageWrapper;
import br.gov.planejamento.dipla.protocolo.controllers.sessions.ArquivosSession;
import br.gov.planejamento.dipla.protocolo.dto.ArquivoDTO;
import br.gov.planejamento.dipla.protocolo.dto.MetadadosDTO;
import br.gov.planejamento.dipla.protocolo.entities.Configuracao;
import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEmail;
import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEnum;
import br.gov.planejamento.dipla.protocolo.entities.EmailEnum;
import br.gov.planejamento.dipla.protocolo.entities.Metadado;
import br.gov.planejamento.dipla.protocolo.entities.MetadadosEmail;
import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
import br.gov.planejamento.dipla.protocolo.entities.StatusEnum;
import br.gov.planejamento.dipla.protocolo.entities.TiposDocumento;
import br.gov.planejamento.dipla.protocolo.mail.Mailer;
import br.gov.planejamento.dipla.protocolo.repositories.ClassificacaoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoEmailRepository;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.ProtocoloRepository;
import br.gov.planejamento.dipla.protocolo.repositories.TiposDocumentoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.UsuarioRepository;
import br.gov.planejamento.dipla.protocolo.repositories.filter.ConfiguracaoFilter;
import br.gov.planejamento.dipla.protocolo.repositories.filter.ProtocoloFilter;
import br.gov.planejamento.dipla.protocolo.security.UsuarioSistema;
import br.gov.planejamento.dipla.protocolo.services.AutoCadastroService;
import br.gov.planejamento.dipla.protocolo.services.ConfiguracaoEmailService;
import br.gov.planejamento.dipla.protocolo.services.ConfiguracaoService;
import br.gov.planejamento.dipla.protocolo.services.EnviarProtocoloService;
import br.gov.planejamento.dipla.protocolo.services.SalvarProtocoloService;
import br.gov.planejamento.dipla.protocolo.services.UnidadeService;
import br.gov.planejamento.dipla.protocolo.services.ProtocoloFlagService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.util.Optional;
import br.gov.planejamento.dipla.protocolo.response.Response;
import br.gov.planejamento.dipla.protocolo.dto.ProtocoloFlagDTO;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import org.springframework.validation.ObjectError;


/**
 * @author Leonardo Dias
 */
@Controller
@RequestMapping("/configuracao")
public class ConfiguracaoController {

    @Autowired
    private ConfiguracaoRepository configuracaoRepository;
    
    @Autowired
    private ClassificacaoRepository classificacaoRepository;
    
    @Autowired
    private ConfiguracaoEmailRepository configuracaoEmailRepository;
    
    @Autowired
    private ConfiguracaoService configuracaoService;
    
    @Autowired
    private ConfiguracaoEmailService configuracaoEmailService;
    
    @Autowired
    private Mailer mailer;

    private final int DEFAULT_PAGEABLE_SIZE = 10;

    @GetMapping("/configuracaoClassificacao/{classificacao}")
    public ModelAndView configuracao(@PathVariable("classificacao") String classificacao,ConfiguracaoFilter filter, BindingResult result, @PageableDefault(size = DEFAULT_PAGEABLE_SIZE) Pageable pageable, HttpServletRequest httpServletRequest) {
        ModelAndView mv = new ModelAndView("configuracao/ConfiguracaoAmbiente");
        filter.setClassificacao(classificacaoRepository.findByNome(classificacao).get());
        PageWrapper<Configuracao> paginaWrapper = new PageWrapper<>(configuracaoRepository.filtrar(filter, pageable), httpServletRequest);
        mv.addObject("pagina", paginaWrapper);
        return mv;
    }
    
    @GetMapping("/configuracaoEmail")
    public ModelAndView configuracao(HttpServletRequest httpServletRequest) {
        ModelAndView mv = new ModelAndView("configuracao/ConfiguracaoEmail");
        List<ConfiguracaoEmail> configuracaoEmailList = configuracaoEmailRepository.findAll();
        mv.addObject("configuracoes", configuracaoEmailList);
        return mv;
    }
    
    
    @GetMapping("/{codigo}")
    public ModelAndView editar(@PathVariable("codigo") Configuracao configuracao) {
    	ModelAndView mv = new ModelAndView("configuracao/EditarConfiguracao");
        mv.addObject(configuracao);
        return mv;
    }
    
    @GetMapping("/configuracaoEmail/{codigo}")
    public ModelAndView editarEmail(@PathVariable("codigo") ConfiguracaoEmail configuracaoEmail) {
    	ModelAndView mv  = new ModelAndView("configuracao/EditarConfiguracaoEmail");
    	List<Metadado> listMetadado = configuracaoEmail.getMetadados();
    	mv.addObject(configuracaoEmail);
		mv.addObject("metadados", retornarScript(listMetadado));
        return mv;
    }
    
       
    @PostMapping("/editarConfiguracao/{codigo}")
    public ModelAndView editarEditarConfiguracao(@Valid Configuracao configuracao, BindingResult result, RedirectAttributes attributes) {
        if (result.hasFieldErrors()) {
            return new ModelAndView("redirect:/");
        }
        configuracaoService.editar(configuracao);
        attributes.addFlashAttribute("mensagem", "Configuração editada com sucesso.");
        String url= "redirect:/configuracao/configuracaoClassificacao/"+configuracaoRepository.findByCodigo(configuracao.getCodigo()).get().getClassificacao().getNome();
        ModelAndView mv = new ModelAndView(url);
        return mv;
    }
    
    @PostMapping("/editarConfiguracaoEmail/{codigo}")
    public ModelAndView editarEditarConfiguracaoEmail(@Valid ConfiguracaoEmail configuracaoEmail, BindingResult result, RedirectAttributes attributes) {
        if (result.hasFieldErrors()) {
            return new ModelAndView("redirect:/");
        }
        configuracaoEmailService.editar(configuracaoEmail);
        attributes.addFlashAttribute("mensagem", "Configuração editada com sucesso.");
        ModelAndView mv = new ModelAndView("redirect:/configuracao/configuracaoEmail");
        return mv;
    }
    

    public Object retornarScript(List<Metadado> metadados) {
    	String retorno=""+
    			"tinymce.init({ selector:'textarea#valor' ,\r\n" + 
    			"        		plugins: \"link\" , \r\n" + 
    			"        		extended_valid_elements : 'span', \r\n" +
    			"        		custom_elements : 'span', \r\n" +
    			"        		toolbar: 'metadado | insert | undo redo |  formatselect | bold italic backcolor  | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',\r\n" + 
    			"        		menubar: false,\r\n" + 
    			"        		    content_css: [\r\n" + 
    			"        		    '//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',\r\n" + 
    			"        		    '//www.tinymce.com/css/codepen.min.css'],\r\n" + 
    			"        		  \r\n" + 
    			"        		setup: function(editor) {\r\n" + 
    			"        		    editor.addButton('metadado', {\r\n" + 
    			"        		      type: 'menubutton',\r\n" + 
    			"        		      text: 'Metadado',\r\n" + 
    			"        		      icon: false,\r\n" + 
    			"        		      menu: [ \r\n";
    	Iterator i = metadados.iterator();
    	
    	while (i.hasNext()) {
    		Metadado metadado = (Metadado)i.next();
	    	retorno=retorno+
		    		"        		      	{ \r\n"+
					"        		      	text: '"+metadado.getNome()+"', \r\n"+
					"        		      	onclick: function() { \r\n"+
				    "        		      		editor.insertContent('<span>{$"+metadado.getNome()+"}</span>'); \r\n"+
			        "							} \r\n";
	    	if(i.hasNext()) {
	    		retorno=retorno+
		    		"						} ,\r\n";
	    	}else {
	    		retorno=retorno+
		    		"						} \r\n";
	    	}
    	}
    	retorno=retorno+
    			"        		    ]}"+
    			"				);\r\n" + 
    			"        	} \r\n"+
    			"        });";
        return retorno;
        
    }
    
    

}
