/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.repositories;

import br.gov.planejamento.dipla.protocolo.entities.TiposDocumento;
import br.gov.planejamento.dipla.protocolo.repositories.helper.tiposDocumento.TiposDocumentoRepositoryQueries;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.List;

/**
 * @author leonardo
 */
@Repository
public interface TiposDocumentoRepository extends JpaRepository<TiposDocumento, Long>, TiposDocumentoRepositoryQueries {

    Optional<TiposDocumento> findByDescricao(String descricao);

    List<TiposDocumento> findByAtivo(Boolean True);

}
