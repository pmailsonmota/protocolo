package br.gov.planejamento.dipla.protocolo.security;


import java.util.Date;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.gov.planejamento.dipla.protocolo.entities.LoginAttempt;
import br.gov.planejamento.dipla.protocolo.repositories.LoginAttemptRepository;
import br.gov.planejamento.dipla.protocolo.repositories.UsuarioRepository;


@Service
public class LoginAttemptService {
	
	@Autowired
    private LoginAttemptRepository loginAttemptRepository;

    public void loginSucceeded(String key) {
    	String keyCodec = DigestUtils.sha1Hex(key);
    	Optional<LoginAttempt> loginAttempt = loginAttemptRepository.findByKey(keyCodec);
    	if(loginAttempt.isPresent()) {
    		loginAttemptRepository.delete(loginAttempt.get());
    	}
    }

    public int loginFailed(String key) {
    	int amount=1;
    	String keyCodec = DigestUtils.sha1Hex(key);
        Optional<LoginAttempt> loginAttemptOptional = loginAttemptRepository.findByKey(keyCodec);
        if (loginAttemptOptional.isPresent()){
        	amount = amount+loginAttemptOptional.get().getAmount();
        	loginAttemptRepository.setFixedAmountFor(amount,new Date(),keyCodec);
        }else {
        	loginAttemptRepository.insertLogginAttempt(keyCodec);
        }
        return amount;
    }

    public boolean isBlocked(String key) {
    	String keyCodec = DigestUtils.sha1Hex(key);
        Optional<LoginAttempt> loginAttemptOptional = loginAttemptRepository.findByKey(keyCodec);
        if(loginAttemptOptional.isPresent()) {
        	if(loginAttemptOptional.get().getAmount()<3) {
        		return false;
        	} else {
        		return true;
        	}
        }        
        return false;
    }
    
    
}