package br.gov.planejamento.dipla.protocolo.repositories.helper.configuracao;

import br.gov.planejamento.dipla.protocolo.entities.Configuracao;
import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEnum;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import br.gov.planejamento.dipla.protocolo.repositories.filter.ConfiguracaoFilter;
import br.gov.planejamento.dipla.protocolo.repositories.paginacao.PaginacaoUtil;

import java.util.List;
import java.util.Optional;

/**
 *
 * @author Leonardo Dias
 */
public class ConfiguracaoRepositoryImpl implements ConfiguracaoRepositoryQueries {

    @PersistenceContext
    private EntityManager manager;

    @Autowired
    private PaginacaoUtil paginacaoUtil;

	@Override
	public String recuperarValor(ConfiguracaoEnum nome) {
		Optional<String> valor = manager.createQuery("select distinct c.valor from Configuracao c where c.nome= :nome", String.class)
        .setParameter("nome", nome.name()).getResultList().stream().findFirst();
		return valor.get();
	}
	
	@Override
    public Page<Configuracao> filtrar(ConfiguracaoFilter configuracaoFilter, Pageable pageable) {
        Criteria criteria = manager.unwrap(Session.class).createCriteria(Configuracao.class);

        paginacaoUtil.preparaPaginacao(criteria, pageable);

        adicionarFiltro(configuracaoFilter, criteria);

        return new PageImpl<>(criteria.list(), pageable, total(configuracaoFilter));
    }
	@Override
	public Optional<Configuracao> findByNome(String nome) {
		Optional<Configuracao> valor = manager.createQuery("from Configuracao c where c.nome= :nome",Configuracao.class)
		        .setParameter("nome", nome).getResultList().stream().findFirst();
		return valor;
	}
	private void adicionarFiltro(ConfiguracaoFilter filtro, Criteria criteria) {
        
        if (filtro != null) {
            if (filtro.getPesquisa() != null) {
                criteria.add(Restrictions.or(
                        Restrictions.ilike("nome", filtro.getPesquisa(), MatchMode.ANYWHERE),
                        Restrictions.ilike("descricao", filtro.getPesquisa(), MatchMode.ANYWHERE),
                        Restrictions.ilike("valor", filtro.getPesquisa(), MatchMode.ANYWHERE)
                ));
            }
            if (filtro.getClassificacao() != null) {
            	criteria.add(Restrictions.eq("classificacao", filtro.getClassificacao()));
            }
        }
    }
	private Long total(ConfiguracaoFilter configuracaoFilter) {
        Criteria criteria = manager.unwrap(Session.class).createCriteria(Configuracao.class);
        adicionarFiltro(configuracaoFilter, criteria);
        criteria.setProjection(Projections.rowCount());
        return (Long) criteria.uniqueResult();
    }
}
