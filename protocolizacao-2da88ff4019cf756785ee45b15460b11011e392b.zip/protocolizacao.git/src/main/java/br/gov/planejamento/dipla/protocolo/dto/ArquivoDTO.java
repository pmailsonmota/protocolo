package br.gov.planejamento.dipla.protocolo.dto;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

/**
 *
 * @author Leonardo Dias
 */
@Getter
@Setter
@EqualsAndHashCode(of = {"uuid", "nome"})
public class ArquivoDTO {

    private String uuid;
    private String nome;
    private String contentType;
    private String logo;
    private String nomeOriginal;
    private String tipoDocumento;
    private String descricaoDocumento;
    private String tamanho;
    private String codigoTipoDocumento;

    public ArquivoDTO() {
    }
    
    public ArquivoDTO(String _nomeOriginal, String _nome, String _contentType, String _logo, String _tamanho) {
        this.nomeOriginal = _nomeOriginal;
        this.nome = _nome;
        this.contentType = _contentType;
        this.logo = _logo;
        this.tamanho = _tamanho;
    }

}
