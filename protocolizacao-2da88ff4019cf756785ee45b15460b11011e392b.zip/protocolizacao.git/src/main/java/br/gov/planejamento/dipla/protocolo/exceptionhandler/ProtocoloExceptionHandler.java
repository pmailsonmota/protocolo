package br.gov.planejamento.dipla.protocolo.exceptionhandler;

import lombok.Getter;
import org.apache.tomcat.util.http.fileupload.FileUploadBase;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.multipart.MultipartException;

import java.text.DecimalFormat;
import java.text.NumberFormat;

@ControllerAdvice
public class ProtocoloExceptionHandler {

    NumberFormat numberFormatter = new DecimalFormat("#0");

    @ExceptionHandler({MultipartException.class})
    public ResponseEntity<Erro> handleSizeLimitExceededException(MultipartException e) {
        String message = "Invalid form data";
        if (e.getCause() instanceof IllegalStateException) {
            if (e.getRootCause() instanceof FileUploadBase.SizeException) {
                FileUploadBase.SizeException sizeException = (FileUploadBase.SizeException) e.getRootCause();
                if (sizeException instanceof FileUploadBase.FileSizeLimitExceededException) {
                    FileUploadBase.FileSizeLimitExceededException cause = (FileUploadBase.FileSizeLimitExceededException) sizeException;
                    message = "O arquivo deve ser menor que: " + numberFormatter.format(cause.getPermittedSize() / Math.pow(2F, 20)) + "MB";
                } else if (sizeException instanceof FileUploadBase.SizeLimitExceededException) {
                    FileUploadBase.SizeLimitExceededException cause = (FileUploadBase.SizeLimitExceededException) sizeException;
                    message = "O arquivo deve ser menor que: " + numberFormatter.format(cause.getPermittedSize() / Math.pow(2F, 20)) + "MB";
                }
            }
        }
        return new ResponseEntity<>(new Erro(message), HttpStatus.BAD_REQUEST);
    }

    @Getter
    public static class Erro {
        private String message;

        public Erro(String message) {
            this.message = message;
        }
    }
}
