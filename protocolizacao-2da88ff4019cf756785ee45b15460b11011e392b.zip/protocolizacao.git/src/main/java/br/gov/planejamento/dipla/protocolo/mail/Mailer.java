package br.gov.planejamento.dipla.protocolo.mail;

import br.gov.planejamento.dipla.protocolo.dto.UsuarioBrasilCidadaoDto;
import br.gov.planejamento.dipla.protocolo.entities.Configuracao;
import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEmail;
import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEnum;
import br.gov.planejamento.dipla.protocolo.entities.EmailEnum;
import br.gov.planejamento.dipla.protocolo.entities.Metadado;
import br.gov.planejamento.dipla.protocolo.entities.MetadadosEmail;
import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoEmailRepository;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.MetadadoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.UsuarioRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring4.SpringTemplateEngine;
import org.thymeleaf.spring4.dialect.SpringStandardDialect;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.StringTemplateResolver;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import java.io.StringReader;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/**
 * @author Leonardo Dias
 */

@Component
//@PropertySource(value = {"classpath:/protocolo-mail.properties"})
public class Mailer {

    private static final Logger LOGGER = LoggerFactory.getLogger(Mailer.class);

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private TemplateEngine thymeleaf;

    @Autowired
    private ConfiguracaoRepository configuracaoRepository;
    
    @Autowired
    private ConfiguracaoEmailRepository configuracaoEmailRepository;
    
    @Autowired
    private MetadadoRepository metadadoRepository;

    @Async
    public void enviarConfirmacao(Protocolo protocolo) {
    	Context context = new Context(new Locale("pt", "BR"));
        context.setVariable("protocolo", protocolo);

        try {
        	
        	String email = processarTemplate(context,(montarEmail(EmailEnum.EMAIL_CONTEUDO_PROTOCOLO)));

            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setFrom(configuracaoRepository.recuperarValor(ConfiguracaoEnum.MAIL_FROM));
            helper.setTo(protocolo.getUsuario().getEmail());

            if (!StringUtils.isEmpty(protocolo.getEmail1())) {
                helper.addCc(protocolo.getEmail1());
            }

            if (!StringUtils.isEmpty(protocolo.getEmail2())) {
                helper.addCc(protocolo.getEmail2());
            }
            
            if (!StringUtils.isEmpty(protocolo.getInteressado())) {
            	helper.addCc(protocolo.getInteressado());
            }

            helper.setSubject(String.format("Protocolo de Entrega de Documentos Nº Provisório: %s", protocolo.getNumero()));
            helper.setText(email, true);

            helper.addInline("logo", new ClassPathResource("static/images/brasao-brasil.png"));

            mailSender.send(mimeMessage);
            
        } catch (MessagingException e) {
            LOGGER.error("Erro enviando e-mail", e);
        }
    }

    @Async
    public void enviarAceite(Protocolo protocolo) {
    	
    	Context context = new Context(new Locale("pt", "BR"));
		context.setVariable("protocolo", protocolo);

        try {
        	
        	String email = processarTemplate(context,(montarEmail(EmailEnum.EMAIL_CONTEUDO_RECEBIMENTO_SEI)));

            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setFrom(configuracaoRepository.recuperarValor(ConfiguracaoEnum.MAIL_FROM));
            helper.setTo(protocolo.getUsuario().getEmail());


            if (!StringUtils.isEmpty(protocolo.getEmail1())) {
                helper.addCc(protocolo.getEmail1());
            }

            if (!StringUtils.isEmpty(protocolo.getEmail2())) {
                helper.addCc(protocolo.getEmail2());
            }
            
            if (!StringUtils.isEmpty(protocolo.getInteressado())) {
            	helper.addCc(protocolo.getInteressado());
            }

            helper.setSubject(String.format("Protocolo de Recebimento de Documentos NUP: %s", protocolo.getNupe()));
            helper.setText(email, true);

            helper.addInline("logo", new ClassPathResource("static/images/brasao-brasil.png"));

            mailSender.send(mimeMessage);
        } catch (MessagingException e) {
            LOGGER.error("Erro enviando e-mail", e);
        }
    }

    @Async
    public void enviarRecusa(Protocolo protocolo) {
    	
    	Context context = new Context(new Locale("pt", "BR"));
        context.setVariable("protocolo", protocolo);
        
        try {
        	String email = processarTemplate(context,(montarEmail(EmailEnum.EMAIL_CONTEUDO_NEGADO)));
            

            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setFrom(configuracaoRepository.recuperarValor(ConfiguracaoEnum.MAIL_FROM));
            helper.setTo(protocolo.getUsuario().getEmail());


            if (!StringUtils.isEmpty(protocolo.getEmail1())) {
                helper.addCc(protocolo.getEmail1());
            }

            if (!StringUtils.isEmpty(protocolo.getEmail2())) {
                helper.addCc(protocolo.getEmail2());
            }
            
            if (!StringUtils.isEmpty(protocolo.getInteressado())) {
            	helper.addCc(protocolo.getInteressado());
            }

            helper.setSubject(String.format("Informações sobre o Número do Protocolo Provisório %s", protocolo.getNumero()));
            helper.setText(email, true);

            helper.addInline("logo", new ClassPathResource("static/images/brasao-brasil.png"));

            mailSender.send(mimeMessage);
            
        } catch (MessagingException e) {
            LOGGER.error("Erro enviando e-mail", e);
        }
    }

    @Async
    public void enviarNovaSenha(Usuario usuario) {
    	
    	
    	Context context = new Context(new Locale("pt", "BR"));
        context.setVariable("usuario", usuario);

        try {
            String email = processarTemplate(context,(montarEmail(EmailEnum.EMAIL_CONTEUDO_ESQUECI_SENHA)));
            

            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setFrom(configuracaoRepository.recuperarValor(ConfiguracaoEnum.MAIL_FROM));
            helper.setTo(usuario.getEmail());
            helper.setSubject("Solicitação de Nova Senha");
            helper.setText(email, true);

            helper.addInline("logo", new ClassPathResource("static/images/brasao-brasil.png"));

            mailSender.send(mimeMessage);
        } catch (MessagingException e) {
            LOGGER.error("Erro enviando e-mail", e);
        }
    }

    @Async
    public void enviarConfirmacaoCadastro(Usuario usuario) {

    	Context context = new Context(new Locale("pt", "BR"));
        context.setVariable("usuario", usuario);

        try {
        	String email = processarTemplate(context,(montarEmail(EmailEnum.EMAIL_CONTEUDO_CADASTRO)));

            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setFrom(configuracaoRepository.recuperarValor(ConfiguracaoEnum.MAIL_FROM));
            helper.setTo(usuario.getEmail());
            helper.setSubject("Confirmação de cadastro no sistema de protocolo");
            helper.setText(email, true);

            helper.addInline("logo", new ClassPathResource("static/images/brasao-brasil.png"));

            mailSender.send(mimeMessage);
        } catch (MessagingException e) {
            LOGGER.error("Erro enviando e-mail", e);
        }
    }
    
    @Async
    public void enviarConsiliacaoUsuario(Usuario usuario, String emailEnvio) {

    	Context context = new Context(new Locale("pt", "BR"));
        context.setVariable("usuario", usuario);

        try {
        	String email = processarTemplate(context,(montarEmail(EmailEnum.EMAIL_CONTEUDO_CONSOLIDACAO)));

            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setFrom(configuracaoRepository.recuperarValor(ConfiguracaoEnum.MAIL_FROM));
            helper.setTo(emailEnvio);
            helper.setSubject("Confirmação de cadastro no sistema de protocolo");
            helper.setText(email, true);

            helper.addInline("logo", new ClassPathResource("static/images/brasao-brasil.png"));

            mailSender.send(mimeMessage);
        } catch (MessagingException e) {
            LOGGER.error("Erro enviando e-mail", e);
        }
    }
    
    @Async
    public void enviarDesbloqueio(Usuario usuario, String emailEnvio) {

    	Context context = new Context(new Locale("pt", "BR"));
        context.setVariable("usuario", usuario);

        try {
        	String email = processarTemplate(context,(montarEmail(EmailEnum.EMAIL_CONTEUDO_DESBLOQUEIO)));

            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setFrom(configuracaoRepository.recuperarValor(ConfiguracaoEnum.MAIL_FROM));
            helper.setTo(emailEnvio);
            helper.setSubject("Confirmação de cadastro no sistema de protocolo");
            helper.setText(email, true);

            helper.addInline("logo", new ClassPathResource("static/images/brasao-brasil.png"));

            mailSender.send(mimeMessage);
        } catch (MessagingException e) {
            LOGGER.error("Erro enviando e-mail", e);
        }
    }

    @Async
    public void enviarEmailErroEnvioSEI(Protocolo protocolo, String msgErro) {
    	
    	Context context = new Context(new Locale("pt", "BR"));

        context.setVariable("protocolo", protocolo);
        context.setVariable("msgErro", msgErro);

        try {
        	String email = processarTemplate(context,(montarEmail(EmailEnum.EMAIL_CONTEUDO_ERRO_SEI)));

            MimeMessage mimeMessage = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
            helper.setFrom(configuracaoRepository.recuperarValor(ConfiguracaoEnum.MAIL_FROM));
            helper.setTo(configuracaoRepository.recuperarValor(ConfiguracaoEnum.EMAIL_RESPONSAVEL));
            helper.setSubject("Erro no envio do protocolo " + protocolo.getNumero() + " para o SEI");
            helper.setText(email, true);

            helper.addInline("logo", new ClassPathResource("static/images/brasao-brasil.png"));

            mailSender.send(mimeMessage);
        } catch (MessagingException e) {
            LOGGER.error("Erro enviando e-mail", e);
        }
    }
    
    private String recuperarMetadados(String texto, List<Metadado> listMetadado) {
    	if (texto!=null) {
    		Context context = new Context(new Locale("pt", "BR"));
    		Iterator i = listMetadado.iterator();
        	while (i.hasNext()) {
        		Metadado metadado = (Metadado)i.next();
        		texto=texto.replace("{$"+metadado.getNome()+"}", metadado.getValor());
          	}
    	}
	    return texto;
    }

    private String montarEmail(EmailEnum emailEnum) {
    	
    	String email = "<!DOCTYPE html>\n" + 
    			"<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:th=\"http://www.thymeleaf.org\" >\n" + 
    			"    <head>\n" + 
    			"        <meta charset=\"UTF-8\" />\n" + 
    			"    </head>\n" + 
    			"<body style=\"font-family: Arial; font-size: 14px;\">";
    	
    	
    	Optional<ConfiguracaoEmail> cabecalho = configuracaoEmailRepository.findByNome(EmailEnum.EMAIL_CABECALHO.name());
        Optional<ConfiguracaoEmail> conteudo = configuracaoEmailRepository.findByNome(emailEnum.name());
        Optional<ConfiguracaoEmail> rodape = configuracaoEmailRepository.findByNome(EmailEnum.EMAIL_RODAPE.name());
        email=email.concat(recuperarMetadados(cabecalho.get().getValor(),metadadoRepository.findByEmail(cabecalho.get())));
        email=email.concat(recuperarMetadados(conteudo.get().getValor(),metadadoRepository.findByEmail(conteudo.get())));
        email=email.concat(recuperarMetadados(rodape.get().getValor(),metadadoRepository.findByEmail(rodape.get())));
        
        
        email=email.concat("</body>\n" + 
        		"</html>");
        
        return email;
    }
    
    private String processarTemplate(Context context, String email ) {
     
        StringTemplateResolver templateResolver = new StringTemplateResolver();
    	templateResolver.setTemplateMode(TemplateMode.HTML);

    	SpringStandardDialect dialect = new SpringStandardDialect();
    	dialect.setEnableSpringELCompiler(true);

    	SpringTemplateEngine engine = new SpringTemplateEngine();
    	engine.setDialect(dialect);
    	engine.setEnableSpringELCompiler(true);
    	engine.setTemplateResolver(templateResolver);
        
    	String emailProcessado = engine.process(email, context);
    	
    	return emailProcessado;
    }
    
}
