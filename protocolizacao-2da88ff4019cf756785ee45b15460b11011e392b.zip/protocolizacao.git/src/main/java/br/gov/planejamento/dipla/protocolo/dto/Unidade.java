package br.gov.planejamento.dipla.protocolo.dto;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@EqualsAndHashCode(of = "codigo")
public class Unidade {

    private Long codigo;
    private String descricao;

}
