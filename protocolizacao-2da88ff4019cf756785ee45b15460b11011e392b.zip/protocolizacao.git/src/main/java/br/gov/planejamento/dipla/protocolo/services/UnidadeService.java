package br.gov.planejamento.dipla.protocolo.services;

import br.gov.planejamento.dipla.protocolo.dto.Unidade;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class UnidadeService {

    public List<Unidade> obterUnidades() {
        List<Unidade> unidadeList = new ArrayList<>();
        Unidade u1 = new Unidade();
        u1.setCodigo(1L);
        u1.setDescricao("Ministério do Planejamento");
        unidadeList.add(u1);
        return unidadeList;
    }
}
