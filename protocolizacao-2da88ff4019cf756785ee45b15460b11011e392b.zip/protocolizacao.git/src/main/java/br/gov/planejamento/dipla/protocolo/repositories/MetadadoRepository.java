package br.gov.planejamento.dipla.protocolo.repositories;

import br.gov.planejamento.dipla.protocolo.entities.Arquivos;
import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEmail;
import br.gov.planejamento.dipla.protocolo.entities.Metadado;
import br.gov.planejamento.dipla.protocolo.entities.MetadadosEmail;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 *
 * @author Leonardo Dias
 */
@Repository
public interface MetadadoRepository extends JpaRepository<Metadado, Integer> {

    public Optional<Metadado> findByCodigo(Integer codigo);
    public List<Metadado> findByEmail(ConfiguracaoEmail email);
    
}
