package br.gov.planejamento.dipla.protocolo.repositories;

import br.gov.planejamento.dipla.protocolo.entities.LogSistema;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Leonardo Dias
 */
@Repository
public interface LogStatusRepository extends JpaRepository<LogSistema, Long>{
	
}
