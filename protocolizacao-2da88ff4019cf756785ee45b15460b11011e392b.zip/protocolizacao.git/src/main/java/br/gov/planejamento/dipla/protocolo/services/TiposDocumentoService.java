/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.services;

import br.gov.planejamento.dipla.protocolo.entities.TiposDocumento;
import br.gov.planejamento.dipla.protocolo.repositories.TiposDocumentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 *
 * @author leonardo
 */
@Service
public class TiposDocumentoService {

    @Autowired
    private TiposDocumentoRepository tiposDocumentoRepository;
    
    public void salvar(TiposDocumento tiposDocumento) {
        Optional<TiposDocumento> tiposDocumentoOptional = tiposDocumentoRepository.findByDescricao(tiposDocumento.getDescricao());
        if (tiposDocumentoOptional.isPresent()) {
            tiposDocumentoRepository.delete(tiposDocumentoOptional.get());
        }
        tiposDocumentoRepository.save(tiposDocumento);
    }

    @Transactional
    public void editar(TiposDocumento tiposDocumento) {
        tiposDocumentoRepository.save(tiposDocumento);
    }
    
    public void excluir(TiposDocumento tiposDocumento) {
        tiposDocumentoRepository.delete(tiposDocumento);
    }
}
