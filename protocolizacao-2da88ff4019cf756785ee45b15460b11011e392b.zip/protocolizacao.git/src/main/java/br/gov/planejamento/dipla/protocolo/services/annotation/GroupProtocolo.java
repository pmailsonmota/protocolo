package br.gov.planejamento.dipla.protocolo.services.annotation;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

/**
 * Created by dario on 27/09/17.
 */

@Target({ ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Constraint(
        validatedBy = { GroupProtocoloValidator.class }
)
public @interface GroupProtocolo {

    String message();

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
