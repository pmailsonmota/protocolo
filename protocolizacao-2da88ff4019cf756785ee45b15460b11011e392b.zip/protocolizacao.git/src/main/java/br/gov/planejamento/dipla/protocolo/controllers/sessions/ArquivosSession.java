package br.gov.planejamento.dipla.protocolo.controllers.sessions;

import br.gov.planejamento.dipla.protocolo.dto.ArquivoDTO;
import br.gov.planejamento.dipla.protocolo.storage.ArquivoStorage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.annotation.SessionScope;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.*;

/**
 * @author Leonardo Dias
 */
@SessionScope
@Component
public class ArquivosSession {

    private final double TAMANHO_PERMITIDO_KB = 100000;
    //private final double TAMANHO_PERMITIDO_KB = 307200;

    @Autowired
    private ArquivoStorage arquivoStorage;

    private final Map<String, List<ArquivoDTO>> arquivosMap = new HashMap<>();

    public void adicionarArquivo(String uuid, ArquivoDTO arquivoDTO) {
        List<ArquivoDTO> arquivosDTOList = arquivosMap.get(uuid);
        if (CollectionUtils.isEmpty(arquivosDTOList)) {
            arquivosDTOList = new ArrayList<>();
        }

        if (isArquivoAdicionado(arquivoDTO.getNome(), arquivosDTOList)) {
            throw new RuntimeException("Arquivo já adicionado");
        }

        verificaTamanhoPermitido(arquivoDTO, arquivosDTOList);

        arquivosDTOList.add(arquivoDTO);
        arquivosMap.put(uuid, arquivosDTOList);
    }

    public void excluirArquivos(String uuid, ArquivoDTO arquivoDTO) {
        arquivosMap.remove(uuid);
        
    }

    public void excluirArquivo(String uuid, String nome) {
        List<ArquivoDTO> arquivos = arquivosMap.get(uuid);
        ArquivoDTO arquivoDTOExclusao = arquivos.stream().filter((arquivoDTO) -> (arquivoDTO.getNome().equals(nome))).findAny().get();
        arquivos.remove(arquivoDTOExclusao);
        arquivoStorage.excluirTemporario(nome);
    }

    public List<ArquivoDTO> obterArquivos(String uuid) {
        return arquivosMap.get(uuid);
    }

    private boolean isArquivoAdicionado(String nome, List<ArquivoDTO> arquivos) {
        return arquivos.stream().anyMatch((arquivo) -> (arquivo.getNome().equals(nome)));
    }

    private void verificaTamanhoPermitido(ArquivoDTO arquivoDTO, List<ArquivoDTO> arquivos) {
        try {
            double size = parseDouble(arquivoDTO.getTamanho());
            for (ArquivoDTO arquivo : arquivos) {
                size += parseDouble(arquivo.getTamanho());
            }

            if (size > TAMANHO_PERMITIDO_KB) {
                throw new RuntimeException("O limite de arquivos foi excedido e deverá ser feita uma nova solicitação fazendo referência ao número de protocolo que deseja complementar.");
            }
        } catch (ParseException pe) {
            throw new RuntimeException("Erro no cálculo das quantidades de arquivos.");
        }
    }

    private Double parseDouble(String valor) throws ParseException {
        DecimalFormat df = (DecimalFormat) DecimalFormat.getInstance(new Locale("pt", "BR"));
        try {
            return (Double) df.parse(valor);
        } catch (Exception e) {
            return new Double((Long) df.parse(valor));
        }
    }
}
