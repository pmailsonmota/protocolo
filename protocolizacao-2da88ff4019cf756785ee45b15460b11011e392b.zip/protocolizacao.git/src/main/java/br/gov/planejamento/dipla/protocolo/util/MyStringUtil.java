package br.gov.planejamento.dipla.protocolo.util;

import org.springframework.stereotype.Component;

import java.text.Normalizer;

@Component
public class MyStringUtil {

    public String removerCaracteresEspeciais(String string) {
        string = Normalizer.normalize(string, Normalizer.Form.NFD);
        string = string.replaceAll("[^\\p{ASCII}]", "");
        return string;
    }
}
