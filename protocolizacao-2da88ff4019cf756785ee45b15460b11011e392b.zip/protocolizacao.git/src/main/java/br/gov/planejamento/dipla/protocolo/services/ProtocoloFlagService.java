package br.gov.planejamento.dipla.protocolo.services;

import java.util.Optional;
import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
/**
 * Created by dario on 29/09/17.
 */
public interface ProtocoloFlagService {

    Optional<Protocolo> buscarStatusPorCodigo(Long codigo);

}
