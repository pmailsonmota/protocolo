package br.gov.planejamento.dipla.protocolo.config;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEnum;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoRepository;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
//@PropertySource(value = {"file:${HOME}/.protocolo-config/protocolo-brasilCidadao.properties"})
//@PropertySource(value = {"classpath:/protocolo-brasilCidadao.properties"})
public class BrasilCidadaoConfig {

    @Autowired
    private ConfiguracaoRepository configuracaoRepository;
    
    Random gerador = new Random();
	
	public String gerarUrlAutorizar(){
		disableSSLCertificateChecking(); 
		String url = configuracaoRepository.recuperarValor(ConfiguracaoEnum.URL_AUTORIZAR)+"?response_type=code&client_id="+
				configuracaoRepository.recuperarValor(ConfiguracaoEnum.CLIENT_ID)+"&redirect_uri="+
				configuracaoRepository.recuperarValor(ConfiguracaoEnum.REDIRECT_URI)+"&nonce="+gerador.hashCode()+
				"&state="+gerador.hashCode(); 
		return url;
	}
	public String gerarUrlToken(){
		String url = configuracaoRepository.recuperarValor(ConfiguracaoEnum.URL_TOKEN);
		return url;
	}
	public String gerarUrlDadosUsuarios(String token){
		String url = configuracaoRepository.recuperarValor(ConfiguracaoEnum.URL_DADOS_USUARIO)+
				configuracaoRepository.recuperarValor(ConfiguracaoEnum.ESCOPO)+"?access_token="+token;
		return url;
	}
	@Bean(name = "urlBrasilCidadao")
	public UrlBrasilCidadao gerarUrlBrasilCidadao(){
		String url = configuracaoRepository.recuperarValor(ConfiguracaoEnum.URL_BRASIL_CIDADAO);
		return () -> url;
	}
	@Bean(name = "urlPrimeiroAcesso")
	public UrlPrimeiroAcesso gerarUrlPrimeiroAcesso(){
		String url = configuracaoRepository.recuperarValor(ConfiguracaoEnum.URL_PRIMEIRO_ACESSO);
		return () -> url;
	}

	public String gerarRequisicaoAtributo(String code){
		String reqAtr = 
				"grant_type=authorization_code&"+
				"code="+code+"&"+
				"redirect_uri="+configuracaoRepository.recuperarValor(ConfiguracaoEnum.REDIRECT_URI);
				
		return reqAtr;
	}
    public HttpHeaders gerarRequisicaoHeader(){
    	HttpHeaders headers = new HttpHeaders();
    	headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
    	headers.add(headers.AUTHORIZATION, "Basic "+Base64.getEncoder().encodeToString((
    			configuracaoRepository.recuperarValor(ConfiguracaoEnum.CLIENT_ID)+":"+
    			configuracaoRepository.recuperarValor(ConfiguracaoEnum.CLIENT_SECRET)).getBytes()));
    	return headers;
	}
	
	
	private void disableSSLCertificateChecking() { 
		TrustManager[] trustAllCerts = new TrustManager[] { 
				new X509TrustManager() { 
					public X509Certificate[] getAcceptedIssuers() { 
						return null; 
					} 
					@Override 
					public void checkClientTrusted(X509Certificate[] arg0, String arg1) throws CertificateException { 
						// Not implemented 
					} 
					@Override public void checkServerTrusted(X509Certificate[] arg0, String arg1) throws CertificateException { 
						// Not implemented 
					}
				} 
			}; 
		try { 
			SSLContext sc = SSLContext.getInstance("TLS"); 
			sc.init(null, trustAllCerts, new java.security.SecureRandom()); 
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
			
		} catch (KeyManagementException e) {
			e.printStackTrace(); 
		} catch (NoSuchAlgorithmException e) { 
			e.printStackTrace(); 
		} 
	}
	public interface UrlBrasilCidadao {
        String getUrlBrasilCidadao();
    }

	public interface UrlPrimeiroAcesso {
        String getUrlPrimeiroAcesso();
    }
}
