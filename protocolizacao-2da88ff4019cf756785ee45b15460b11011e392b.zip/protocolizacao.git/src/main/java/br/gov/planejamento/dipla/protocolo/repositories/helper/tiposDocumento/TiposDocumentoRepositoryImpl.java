/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.repositories.helper.tiposDocumento;

import br.gov.planejamento.dipla.protocolo.entities.TiposDocumento;
import br.gov.planejamento.dipla.protocolo.repositories.filter.TiposDocumentoFilter;
import br.gov.planejamento.dipla.protocolo.repositories.paginacao.PaginacaoUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.util.StringUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author leonardo
 */
public class TiposDocumentoRepositoryImpl implements TiposDocumentoRepositoryQueries {

    @PersistenceContext
    private EntityManager manager;

    @Autowired
    private PaginacaoUtil paginacaoUtil;

    @Override
    public Page<TiposDocumento> filtrar(TiposDocumentoFilter estiloFilter, Pageable pageable) {
        Criteria criteria = manager.unwrap(Session.class).createCriteria(TiposDocumento.class);

        paginacaoUtil.preparaPaginacao(criteria, pageable);

        adicionarFiltro(estiloFilter, criteria);

        return new PageImpl<>(criteria.list(), pageable, total(estiloFilter));
    }

    private Long total(TiposDocumentoFilter tiposDocumentoFilter) {
        Criteria criteria = manager.unwrap(Session.class).createCriteria(TiposDocumento.class);
        adicionarFiltro(tiposDocumentoFilter, criteria);
        criteria.setProjection(Projections.rowCount());
        return (Long) criteria.uniqueResult();
    }

    private void adicionarFiltro(TiposDocumentoFilter tiposDocumentoFilter, Criteria criteria) {
        if (tiposDocumentoFilter != null) {
            if (tiposDocumentoFilter.getCodigo() != null) {
                criteria.add(Restrictions.eq("codigo", tiposDocumentoFilter.getCodigo()));
            }
            if (!StringUtils.isEmpty(tiposDocumentoFilter.getDescricao())) {
                criteria.add(Restrictions.ilike("descricao", tiposDocumentoFilter.getDescricao(), MatchMode.ANYWHERE));
            }
        }
    }
}
