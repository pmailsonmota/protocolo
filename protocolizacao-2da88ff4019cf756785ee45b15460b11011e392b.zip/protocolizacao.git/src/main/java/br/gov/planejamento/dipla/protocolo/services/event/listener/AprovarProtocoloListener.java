package br.gov.planejamento.dipla.protocolo.services.event.listener;

import br.gov.planejamento.dipla.protocolo.sei.ws.SeiWSClient;
import br.gov.planejamento.dipla.protocolo.services.event.AprovarProtocoloEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class AprovarProtocoloListener implements ApplicationListener<AprovarProtocoloEvent> {

    @Autowired
    private SeiWSClient seiWSClient;

    @Override
    public void onApplicationEvent(AprovarProtocoloEvent aprovarProtocoloEvent) {
        seiWSClient.enviar(aprovarProtocoloEvent.getProtocolo(),aprovarProtocoloEvent.getIdUsuario(), aprovarProtocoloEvent.getSei(),aprovarProtocoloEvent.getTipo());
    }
}
