package br.gov.planejamento.dipla.protocolo.dto;

public class ReqTokenDto {

    private String content_Type;
	private String Authorization;
	
    private String grant_type;
    private String code;
    private String redirect_uri;
    
    
    public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getContent_Type() {
		return content_Type;
	}
	public void setContent_Type(String content_Type) {
		this.content_Type = content_Type;
	}
	public String getAuthorization() {
		return Authorization;
	}
	public void setAuthorization(String authorization) {
		Authorization = authorization;
	}
	public String getGrant_type() {
		return grant_type;
	}
	public void setGrant_type(String grant_type) {
		this.grant_type = grant_type;
	}
	public String getRedirect_uri() {
		return redirect_uri;
	}
	public void setRedirect_uri(String redirect_uri) {
		this.redirect_uri = redirect_uri;
	}

}
