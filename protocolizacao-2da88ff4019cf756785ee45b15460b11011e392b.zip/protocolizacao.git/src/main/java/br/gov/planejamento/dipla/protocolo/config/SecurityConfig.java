package br.gov.planejamento.dipla.protocolo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.LoginUrlAuthenticationEntryPoint;
import org.springframework.security.web.authentication.preauth.AbstractPreAuthenticatedProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import br.gov.planejamento.dipla.protocolo.handler.LogoutBrasilCidadaoHandler;
import br.gov.planejamento.dipla.protocolo.security.CustomAuthenticationFailureHandler;



/**
 *
 * @author Leonardo Dias
 */
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private UserDetailsService userDetailsService;
	
	@Autowired
	private LogoutBrasilCidadaoHandler logoutBrasilCidadaoHandler;
	
	@Autowired
	private CustomAuthenticationFailureHandler customAuthenticationFailureHandler;
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
	    auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
	}
	
	@Override
	public void configure(WebSecurity web) throws Exception {
	    web
	            .ignoring()
	            .antMatchers("/layout/**")
	            .antMatchers("/images/**")
	            .antMatchers("/javascripts/vendors/**");
	}
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
	    http
	            .authorizeRequests()
	            .antMatchers("/usuarios/auto-cadastro/**").permitAll()
	            .antMatchers("/usuarios/auto-brasil-cidadao/**").permitAll()
	            .antMatchers("/usuarios/auto-desbloqueio/**").permitAll()
	            .antMatchers("/login/auto-brasil-cidadao/**").permitAll()
	            .antMatchers("/usuarios/esqueci-senha").permitAll()
	            .antMatchers("/login/**").permitAll()
	            .antMatchers("/fragments/ConfirmacaoCadastroSucesso").permitAll()
	            .antMatchers("/configuracao/**").hasRole("CADASTRO")
	            .antMatchers("/usuarios/perfil").hasRole("CADASTRO")
	            .antMatchers("/usuarios/perfil").hasRole("PROTOCOLO")
	            .antMatchers("/usuarios/**").hasRole("CADASTRO")
	            .antMatchers("/tipos-documento/**").hasRole("CADASTRO")
	            .antMatchers("/aprovados/**").hasRole("CADASTRO")
	            .antMatchers("/aprovados/**").hasRole("CADASTRO")
	            .antMatchers("/reprovados/**").hasRole("CADASTRO")
	            .antMatchers("/pendentes/**").hasRole("CADASTRO")
	            .antMatchers("/aprovarManualmente/**").hasRole("CADASTRO")
	            .antMatchers("/opcoes").permitAll()
	            .anyRequest().authenticated()
	            .and()
	            .formLogin()
	            .loginPage("/login").defaultSuccessUrl("/verificar-usuario")
	            .failureHandler(customAuthenticationFailureHandler)
	            .permitAll()
	            .and()
	            .logout().logoutRequestMatcher(new AntPathRequestMatcher("/logout")).logoutSuccessHandler(logoutBrasilCidadaoHandler)
	            .and()
	            .exceptionHandling()
	            .and()
	            .sessionManagement()
	            .invalidSessionUrl("/login");
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() {
	    return new BCryptPasswordEncoder();
	}

}
