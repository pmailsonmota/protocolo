/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.services.exeptions;

/**
 *
 * @author leonardo
 */
public class EmailUsuarioJaCadastradoException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public EmailUsuarioJaCadastradoException(String message) {
        super(message);
    }

}
