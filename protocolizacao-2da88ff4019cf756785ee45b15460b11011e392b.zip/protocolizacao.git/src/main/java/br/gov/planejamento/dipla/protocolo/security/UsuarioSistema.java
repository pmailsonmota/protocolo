package br.gov.planejamento.dipla.protocolo.security;

import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.util.Collection;

/**
 *
 * @author Leonardo Dias
 */
public class UsuarioSistema extends User {

    private static final long serialVersionUID = 1L;

    private final Usuario usuario;
    private final Boolean loginBrasilCidadao;

    public UsuarioSistema(Usuario usuario, Collection<? extends GrantedAuthority> authorities) {
        super(usuario.getEmail(), usuario.getSenha(), authorities);
        this.usuario = usuario;
        this.loginBrasilCidadao = false;
    }
    
    public UsuarioSistema(Usuario usuario, Collection<? extends GrantedAuthority> authorities,Boolean loginBrasilCidadao) {
        super(usuario.getEmail(), usuario.getSenha(), authorities);
        this.usuario = usuario;
        this.loginBrasilCidadao = loginBrasilCidadao;
    }

    public Usuario getUsuario() {
        return usuario;
    }
    
    public Boolean getLoginBrasilCidadao() {
        return loginBrasilCidadao;
    }

}
