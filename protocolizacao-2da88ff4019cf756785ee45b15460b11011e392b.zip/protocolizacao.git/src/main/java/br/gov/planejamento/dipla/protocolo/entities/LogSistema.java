package br.gov.planejamento.dipla.protocolo.entities;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Leonardo Dias
 */
@Entity
@Getter
@Setter
@EqualsAndHashCode(of = {"codigo"})
@Table(name = "log_sistema", schema = "protocolo")
public class LogSistema implements Serializable {

    private static final long serialVersionUID = 1L;

    public LogSistema() {
    	
    }
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codigo;

    @Column(name = "codigo_entidade")
    private Long codigo_entidade;
    
    @Enumerated(EnumType.STRING)
    private EntidadeEnum entidade;
    
    @Enumerated(EnumType.STRING)
    private AcaoEnum acao;
    
    @Column(name = "antes")
    private String antes;
    
    @Column(name = "depois")
    private String depois;
    
    @Column(name = "data_hora")
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date dataHora;
    
    @Column(name = "codigo_usuario")
    private Long codigo_usuario;
    
    public void carregarLog(Long codigo_entidade,EntidadeEnum entidade, AcaoEnum acao, String antes,String depois,Long codigo_usuario) {
    	this.codigo_entidade=codigo_entidade;
    	this.entidade=entidade;
    	this.acao=acao;
    	this.antes=antes;
    	this.depois=depois;
    	this.codigo_usuario=codigo_usuario;
    	this.dataHora=new Date();
    }
    
}
