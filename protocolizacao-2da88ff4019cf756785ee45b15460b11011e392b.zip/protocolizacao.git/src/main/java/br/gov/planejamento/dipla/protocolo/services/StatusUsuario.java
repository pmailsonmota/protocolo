/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.services;

import br.gov.planejamento.dipla.protocolo.repositories.UsuarioRepository;

/**
 *
 * @author leonardo
 */
public enum StatusUsuario {

    ATIVAR {
        @Override
        public void executar(Long[] codigos, UsuarioRepository usuarioRepository) {
            usuarioRepository.findByCodigoIn(codigos).forEach(u -> u.setAtivo(true));
        }
    },
    DESATIVAR {
        @Override
        public void executar(Long[] codigos, UsuarioRepository usuarioRepository) {
            usuarioRepository.findByCodigoIn(codigos).forEach(u -> u.setAtivo(false));
        }
    };

    public abstract void executar(Long[] codigos, UsuarioRepository usuarioRepository);
}
