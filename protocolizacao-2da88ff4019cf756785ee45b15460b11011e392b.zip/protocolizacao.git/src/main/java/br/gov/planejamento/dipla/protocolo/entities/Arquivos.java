/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.entities;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.io.Serializable;

/**
 *
 * @author Leonardo Dias
 */
@Entity
@Getter
@Setter
@EqualsAndHashCode(of = {"codigo"})
@Table(name = "arquivos", schema = "protocolo")
public class Arquivos implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codigo;

    private String nome;

    @Column(name = "nome_original")
    private String nomeOriginal;

    @Column(name = "content_type")
    private String contentType;

    private String tamanho;
    
    @ManyToOne
    @JoinColumn(name = "codigo_protocolo")
    private Protocolo protocolo;
    
    @Size(max = 200, message = "A descrição só pode conter 200 caracteres.")
    @Column(name = "descricao_documento")
    private String descricaoDocumento;
    
    @ManyToOne
    @JoinColumn(name = "codigo_tipo_documento")
    private TiposDocumento tipoDocumento = new TiposDocumento();

    @Transient
    private StatusEnum status;

    @Transient
    private String url;
}
