package br.gov.planejamento.dipla.protocolo.services;

import br.gov.planejamento.dipla.protocolo.dto.UsuarioBrasilCidadaoDto;
import br.gov.planejamento.dipla.protocolo.entities.AcaoEnum;
import br.gov.planejamento.dipla.protocolo.entities.Grupo;
import br.gov.planejamento.dipla.protocolo.entities.LoginAttempt;
import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.entities.UsuarioBrasilCidadao;
import br.gov.planejamento.dipla.protocolo.mail.Mailer;
import br.gov.planejamento.dipla.protocolo.repositories.GrupoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.LoginAttemptRepository;
import br.gov.planejamento.dipla.protocolo.repositories.ProtocoloRepository;
import br.gov.planejamento.dipla.protocolo.repositories.UsuarioBrasilCidadaoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.UsuarioRepository;
import br.gov.planejamento.dipla.protocolo.services.exeptions.EmailUsuarioJaCadastradoException;
import br.gov.planejamento.dipla.protocolo.services.exeptions.SenhaObrigatoriaUsuarioException;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Base64Utils;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Service
public class AutoCadastroService {

    @Autowired
    private UsuarioRepository usuarioRepository;
    
    @Autowired
    private ProtocoloRepository protocoloRepository;
    
	@Autowired
    private LoginAttemptRepository loginAttemptRepository;

    @Autowired
    private GrupoRepository grupoRepository;
    
    @Autowired
    private LogProtocoloService logProtocoloService;
    
    @Autowired
    private UsuarioBrasilCidadaoRepository usuarioBrasilCidadaoRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private Mailer mailer;

    @Transactional
    public void salvar(Usuario usuario) {
        List<Grupo> grupos = new ArrayList<>();
        grupos.add(grupoRepository.findOne(2L));
        salvar(usuario, grupos,false,true);
    }
    
    @Transactional
    public void salvar(Usuario usuario,List<Grupo> grupos, Boolean ativo,Boolean enviarEmail) {
        
        usuario.setGrupos(grupos);

        Optional<Usuario> usuarioExistente = usuarioRepository.findByEmail(usuario.getEmail());
        if (usuarioExistente.isPresent() && !usuarioExistente.get().equals(usuario)) {
            throw new EmailUsuarioJaCadastradoException("E-mail já cadastrado");
        }

        if (usuario.isNovo() && StringUtils.isEmpty(usuario.getSenha())) {
            throw new SenhaObrigatoriaUsuarioException("Senha é obrigatória para novo usuário");
        }

        usuario.setSenha(passwordEncoder.encode(usuario.getSenha()));
        usuario.setConfirmacaoSenha(usuario.getSenha());
        usuario.setAtivo(ativo);
        Usuario usuarioSalvo = usuarioRepository.saveAndFlush(usuario);
        logProtocoloService.saveLog(usuarioSalvo, AcaoEnum.INSERIR);
        String hash = Base64Utils.encodeToString(String.valueOf(usuario.getCodigo()).getBytes());
        usuarioSalvo.setUrlConfirmacaoCadastro(usuario.getUrlConfirmacaoCadastro() + "/" + hash);
        if (enviarEmail==true) {
        	mailer.enviarConfirmacaoCadastro(usuarioSalvo);
        }
    }
    
    @Transactional
    public void cadastrarBrasilCidadao(UsuarioBrasilCidadaoDto usuarioretorno) {
		
    	UsuarioBrasilCidadao usuarioBrasilCidadao= new UsuarioBrasilCidadao();
		Usuario usuario = new Usuario();
		usuario.setNome(usuarioretorno.getNome());
		usuario.setEmail(usuarioretorno.getEmail());
		usuario.setSenha(this.passwordEncoder.encode(usuarioretorno.getCpf()));
		usuario.setTelefone(usuarioretorno.getTelefone()==null||usuarioretorno.getTelefone().isEmpty()?"(00)00000-0000":usuarioretorno.getTelefone().trim());
		List<Grupo> grupos = new ArrayList<>();
	    grupos.add(grupoRepository.findOne(3L));
	    usuario.setGrupos(grupos);
	    
	    salvar(usuario,grupos,false,false);
	    
	}
    
    public void migrarBrasilCidadao(UsuarioBrasilCidadaoDto usuarioretorno) {
		UsuarioBrasilCidadao usuarioBrasilCidadao= new UsuarioBrasilCidadao();
	    //Salvando CPF
	    usuarioBrasilCidadao.setCpf(usuarioretorno.getCpf());
	    usuarioBrasilCidadao.setToken(usuarioretorno.getToken());
	    usuarioBrasilCidadao.setAtivo(Boolean.FALSE);
	    usuarioBrasilCidadaoRepository.save(usuarioBrasilCidadao);
	}
    public void atualizarBrasilCidadao(UsuarioBrasilCidadaoDto usuarioretorno, UsuarioBrasilCidadao usuarioBrasilCidadao, Boolean atualizaEmail) {

		Usuario userMp = usuarioBrasilCidadao.getUsuario() ;
		userMp.setNome(usuarioretorno.getNome());
		if(atualizaEmail) {
			userMp.setEmail(usuarioretorno.getEmail());
		}
		userMp.setSenha(this.passwordEncoder.encode(usuarioretorno.getCpf()));
		userMp.setTelefone(usuarioretorno.getTelefone()==null||usuarioretorno.getTelefone().isEmpty()?"(00)00000-0000":usuarioretorno.getTelefone().trim());
		List<Grupo> grupos = new ArrayList<>();
        grupos.add(grupoRepository.findOne(3L));
		
	    //Salvando usuario
	    salvar(userMp,grupos,userMp.getAtivo(),false);
	}
    

    @Transactional
    public void confirmarCadastro(String hash) {
        String decoded = new String(Base64Utils.decode(hash.getBytes()));
        Long codigo = Long.parseLong(decoded);
        Usuario usuarioExistente = usuarioRepository.findOne(codigo);
        usuarioExistente.setAtivo(Boolean.TRUE);
        usuarioRepository.saveAndFlush(usuarioExistente);
    }
    
    @Transactional
    public void confirmarDesbloqueio(String hash) {
    	Optional<LoginAttempt> loginAttempt = loginAttemptRepository.findByKey(hash);
    	if(loginAttempt.isPresent()) {
    		loginAttemptRepository.delete(loginAttempt.get());
    	}
    }
    
    @Transactional
    public void confirmarConciliacao(String hashBrasilCidadao,  String hashEmail) {
    	
        String decodedBrasilCidadao = new String(Base64Utils.decode(hashBrasilCidadao.getBytes())).substring(2);
        String decodedEmail = new String(Base64Utils.decode(hashEmail.getBytes()));
        
        Long codigoBrasilCidadao = Long.parseLong(decodedBrasilCidadao);
        
        Optional<Usuario> usuarioExistenteProtocolo = usuarioRepository.findByEmail(decodedEmail);
        UsuarioBrasilCidadao usuarioExistenteBrasilCidadao = usuarioBrasilCidadaoRepository.findOne(codigoBrasilCidadao);
        
        if(usuarioExistenteProtocolo.isPresent()) {
    		
	        if(!usuarioExistenteProtocolo.get().equals(usuarioExistenteBrasilCidadao.getUsuario())) {
	        	List<Protocolo> protocoloList = protocoloRepository.findByUsuario(usuarioExistenteBrasilCidadao.getUsuario());
	        	if(protocoloList!=null) {
		        	protocoloList.forEach(p->p.setUsuario(usuarioExistenteProtocolo.get()));
		        	protocoloRepository.save(protocoloList);
		        }
	        	
	        }
	        
	        usuarioExistenteProtocolo.get().setAtivo(Boolean.TRUE);
	        List<Grupo> grupos = new ArrayList<>();
		    grupos.add(grupoRepository.findOne(3L));
	        usuarioExistenteProtocolo.get().setGrupos(grupos);
	        
	        usuarioExistenteBrasilCidadao.setUsuario(usuarioExistenteProtocolo.get());
	        usuarioExistenteBrasilCidadao.setAtivo(Boolean.TRUE);
	        
	        usuarioRepository.save(usuarioExistenteProtocolo.get());
	        usuarioBrasilCidadaoRepository.save(usuarioExistenteBrasilCidadao);
	        
	        
        }else {
        	Usuario usuarioEmail = usuarioExistenteBrasilCidadao.getUsuario();
        	usuarioEmail.setEmail(decodedEmail);
        	usuarioRepository.save(usuarioEmail);
        }
    }
    
    @Transactional
    public void enviarConsiliacaoUsuario(UsuarioBrasilCidadao usuarioBrasilCidadao, String email, String baseUrl) {
    	Optional<Usuario> usuarioExistente = usuarioRepository.findByEmail(email);
	    	if (usuarioExistente.isPresent()){
	    		Random gerador = new Random();
		    	String hashBrasilCidadao = Base64Utils.encodeToString(String.valueOf(gerador.toString().substring(0,2)+usuarioBrasilCidadao.getCodigo()).getBytes());
		    	String hashEmail = Base64Utils.encodeToString(String.valueOf(email).getBytes());
		    	usuarioExistente.get().setUrlConfirmacaoCadastro(baseUrl + "/usuarios/auto-brasil-cidadao/"+ hashBrasilCidadao + "/" + hashEmail);
		        mailer.enviarConsiliacaoUsuario(usuarioExistente.get(),email);
	    	}
    }
    
    @Transactional
    public void enviarBloqueio(String email, String baseUrl) {
    	String keyCodec = DigestUtils.sha1Hex(email);
    	Optional<Usuario> usuarioExistente = usuarioRepository.findByEmail(email);
	    	if (usuarioExistente.isPresent()){
	    		String hashEmail = Base64Utils.encodeToString(String.valueOf(email).getBytes());
		    	usuarioExistente.get().setUrlDesbloqueio(baseUrl + "/usuarios/auto-desbloqueio/"+ keyCodec);
		        mailer.enviarDesbloqueio(usuarioExistente.get(),email);
	    	}
    }
}
