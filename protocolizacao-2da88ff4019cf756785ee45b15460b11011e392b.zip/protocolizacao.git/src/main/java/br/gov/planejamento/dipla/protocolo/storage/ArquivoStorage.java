package br.gov.planejamento.dipla.protocolo.storage;

import org.springframework.web.multipart.MultipartFile;

/**
 *
 * @author Leonardo Dias
 */
public interface ArquivoStorage {

    public String salvarTemporariamente(MultipartFile[] files);

    public byte[] recuperarFotoTemporaria(String nome);

    public byte[] recuperarLogo(String nome);

    public void salvar(String arquivo);

    public byte[] recuperar(String nome);

    public void excluir(String arquivo);

    public void excluirTemporario(String arquivo);

}
