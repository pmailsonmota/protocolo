/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.repositories.helper.protocolo;

import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.repositories.filter.ProtocoloFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 *
 * @author leonardo
 */
public interface ProtocoloRepositoryQueries {

    public Page<Protocolo> filtrar(ProtocoloFilter protocoloFilter, Pageable pageable);

    public Page<Protocolo> filtrarMeusProtocolos(Usuario usuario, ProtocoloFilter protocoloFilter, Pageable pageable);
    
}
