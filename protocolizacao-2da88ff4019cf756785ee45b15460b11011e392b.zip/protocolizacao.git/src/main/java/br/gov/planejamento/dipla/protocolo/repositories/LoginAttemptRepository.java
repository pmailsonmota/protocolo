package br.gov.planejamento.dipla.protocolo.repositories;

import br.gov.planejamento.dipla.protocolo.entities.LoginAttempt;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.Optional;

/**
 *
 * @author Leonardo Dias
 */
@Repository
public interface LoginAttemptRepository extends JpaRepository<LoginAttempt, Integer> {

    public Optional<LoginAttempt> findById(Integer id);
    public Optional<LoginAttempt> findByKey(String key);
    
    @Modifying
    @Transactional
    @Query(value = "UPDATE login_attempt SET amount = :amount , reset_at = :resetAt where `key`= :key", nativeQuery = true)
    int setFixedAmountFor(@Param("amount")Integer amount, @Param("resetAt")Date resetAt, @Param("key")String key);
    
    @Modifying
    @Transactional
    @Query(value = "INSERT INTO login_attempt (`key`) VALUES (:key_teste)", nativeQuery = true)
    void insertLogginAttempt(@Param("key_teste")String key);
}
