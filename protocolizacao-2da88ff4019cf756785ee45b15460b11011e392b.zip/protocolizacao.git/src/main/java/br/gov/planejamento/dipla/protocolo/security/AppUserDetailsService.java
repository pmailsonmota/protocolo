package br.gov.planejamento.dipla.protocolo.security;

import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.repositories.UsuarioRepository;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 *
 * @author Leonardo Dias
 */
@Service
public class AppUserDetailsService implements UserDetailsService {

    @Autowired
    private UsuarioRepository usuarioRepository;
    
    @Autowired
    private LoginAttemptService loginAttemptService;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
    	
    	if (loginAttemptService.isBlocked(email)) {
            throw new RuntimeException("blocked");
        }
    	
        Optional<Usuario> usuarioOptional = usuarioRepository.porEmailEAtivo(email);
        Usuario usuario = usuarioOptional.orElseThrow(() -> new UsernameNotFoundException("Usuário e/ou senha incorretos"));
        usuario.setTemPerfilAdministrador(temPerfilAdministrador(usuario));
        return new UsuarioSistema(usuario, getPermissoes(usuario));
    }

    private Collection<? extends GrantedAuthority> getPermissoes(Usuario usuario) {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();

        List<String> permissoes = usuarioRepository.permissoes(usuario);
        permissoes.forEach(p -> authorities.add(new SimpleGrantedAuthority(p.toUpperCase())));

        return authorities;
    }

    public boolean temPerfilAdministrador(Usuario usuario) {
        List<String> permissoes = usuarioRepository.permissoes(usuario);
        return permissoes.stream().anyMatch((permissao) -> (permissao.equals("ROLE_CADASTRO")));
    }
    
    public boolean temPerfilBrasilCidadao(Usuario usuario) {
        List<String> permissoes = usuarioRepository.permissoes(usuario);
        return permissoes.stream().anyMatch((permissao) -> (permissao.equals("ROLE_BRASILCIDADAO")));
    }
}
