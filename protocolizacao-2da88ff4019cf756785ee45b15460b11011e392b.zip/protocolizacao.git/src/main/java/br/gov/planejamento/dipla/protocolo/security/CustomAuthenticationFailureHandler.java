package br.gov.planejamento.dipla.protocolo.security;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.WebAttributes;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import br.gov.planejamento.dipla.protocolo.entities.LoginAttempt;
import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.repositories.LoginAttemptRepository;
import br.gov.planejamento.dipla.protocolo.services.AutoCadastroService;

@Component
public class CustomAuthenticationFailureHandler extends SimpleUrlAuthenticationFailureHandler {
	
    @Autowired
    private AutoCadastroService autoCadastroService;
    
	@Autowired
    private LoginAttemptRepository loginAttemptRepository;
	
	@Autowired
    private LoginAttemptService loginAttemptService;
    
    @Override
    public void onAuthenticationFailure(final HttpServletRequest request, final HttpServletResponse response, final AuthenticationException exception) throws IOException, ServletException {
        setDefaultFailureUrl("/login?error=true");
        String email = request.getParameter("username");
        if (exception.getMessage().equalsIgnoreCase("blocked")) {
        	setDefaultFailureUrl("/login?erroUserBloqueado=true");
        	String baseUrl = String.format("%s://%s:%d/protocolo",request.getScheme(),  request.getServerName(), request.getServerPort());
        	autoCadastroService.enviarBloqueio(email,baseUrl);
        }
        if (exception.getMessage().equalsIgnoreCase("Bad credentials")) {
           	setDefaultFailureUrl("/login?errorBadcredencials="+loginAttemptService.loginFailed(email));
        }
        
        super.onAuthenticationFailure(request, response, exception);
    }
}
