/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.repositories.filter;

import br.gov.planejamento.dipla.protocolo.entities.Grupo;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 *
 * @author leonardo
 */
@Getter
@Setter
public class UsuarioFilter {

    private String nome;
    private String email;
    private List<Grupo> grupos;

}
