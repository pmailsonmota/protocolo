package br.gov.planejamento.dipla.protocolo.services;

import br.gov.planejamento.dipla.protocolo.dto.ArquivoDTO;
import br.gov.planejamento.dipla.protocolo.entities.AcaoEnum;
import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
import br.gov.planejamento.dipla.protocolo.entities.StatusEnum;
import br.gov.planejamento.dipla.protocolo.mail.Mailer;
import br.gov.planejamento.dipla.protocolo.repositories.ArquivosRepository;
import br.gov.planejamento.dipla.protocolo.repositories.ProtocoloRepository;
import br.gov.planejamento.dipla.protocolo.sei.ws.SeiWSClient;
import br.gov.planejamento.dipla.protocolo.services.event.AprovarProtocoloEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import Sei.RetornoConsultaProcedimento;

import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class EnviarProtocoloService {

    @Autowired
    private SalvarProtocoloService salvarProtocoloService;

    @Autowired
    private ProtocoloRepository protocoloRepository;
    
    @Autowired
    private LogProtocoloService logProtocoloService;
    
    @Autowired
    private ArquivosRepository arquivosRepository;

    @Autowired
    private Mailer mailer;
    
    @Autowired
    private SeiWSClient seiWSClient;

    @Autowired
    private ApplicationEventPublisher publisher;
    

    public void enviar(Protocolo protocolo, List<ArquivoDTO> arquivoDTOList) {
        protocolo.setDataEnvio(new Date());
        salvarProtocoloService.save(protocolo, arquivoDTOList);
        mailer.enviarConfirmacao(protocolo);
    }
    
    public Optional<String> consultarSei(String sei) {
    	RetornoConsultaProcedimento retornoConsultaProcedimento = seiWSClient.consultarProtocoloSei(sei);
    	return Optional.of(retornoConsultaProcedimento.getLinkAcesso());
    }

    public void enviarSEI(Protocolo protocolo, String sei, String tipo) {
        protocolo.setDataEnvio(new Date());
        protocolo.setNupe("Processando...");
        protocolo.setStatus(StatusEnum.PROCESSANDO);
        protocoloRepository.save(protocolo);
        logProtocoloService.saveLog(protocolo,AcaoEnum.ALTERAR);
        publisher.publishEvent(new AprovarProtocoloEvent(this, protocolo, logProtocoloService.recuperarUsuario(), sei, tipo));
    }

    public void recusar(Protocolo protocolo) {
        salvarProtocoloService.reprovar(protocolo);
        mailer.enviarRecusa(protocolo);
    }
    
    public void reenviarRecibo(Protocolo protocolo, String email) {
    	StatusEnum status = protocolo.getStatus();
    	protocolo.setArquivosList(arquivosRepository.findByProtocolo(protocolo));
    	if (email.isEmpty()||email!=null) {
    		protocolo.setInteressado(email);
    	}
    	if(status.equals(StatusEnum.APROVADO)) {
    		mailer.enviarAceite(protocolo);
    	}
    	if(status.equals(StatusEnum.REPROVADO)) {
    		mailer.enviarRecusa(protocolo);
    	}
    	if(status.equals(StatusEnum.PENDENTE)) {
    		mailer.enviarConfirmacao(protocolo);
    	}
    	if(status.equals(StatusEnum.APROVADO_MANUALMENTE)) {
    		mailer.enviarAceite(protocolo);
    	}
    }
    
}
