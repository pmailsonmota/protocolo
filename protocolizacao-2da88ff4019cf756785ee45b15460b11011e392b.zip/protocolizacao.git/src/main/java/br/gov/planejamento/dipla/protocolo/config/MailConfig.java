package br.gov.planejamento.dipla.protocolo.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEnum;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoRepository;

import java.util.Properties;

@Configuration
//@PropertySource(value = {"classpath:/protocolo-mail.properties"})

public class MailConfig {

	@Autowired
    private ConfiguracaoRepository configuracaoRepository;

    @Bean
    public JavaMailSender mailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        mailSender.setHost(configuracaoRepository.recuperarValor(ConfiguracaoEnum.SMTP_SERVER));
        mailSender.setPort(Integer.parseInt(configuracaoRepository.recuperarValor(ConfiguracaoEnum.SMTP_PORT)));

        Properties props = new Properties();
        props.put("mail.transport.protocol", "smtp");
        props.put("mail.smtp.auth", false);
        props.put("mail.smtp.starttls.enable", false);
        props.put("mail.debug", false);
        props.put("mail.smtp.ssl.enable", "false");
        props.put("mail.smtp.ssl.trust", "*");
        props.put("mail.smtp.connectiontimeout", 10000); // miliseconds

        mailSender.setJavaMailProperties(props);

        return mailSender;
    }

}
