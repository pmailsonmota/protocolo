package br.gov.planejamento.dipla.protocolo.repositories;

import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEmail;
import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEnum;
import br.gov.planejamento.dipla.protocolo.entities.MetadadosEmail;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 *
 * @author Leonardo Dias
 */
@Repository
public interface ConfiguracaoEmailRepository extends JpaRepository<ConfiguracaoEmail, Integer> {

    public Optional<ConfiguracaoEmail> findByCodigo(Integer codigo);
    public Optional<ConfiguracaoEmail> findByNome(String nome);
    
}
