package br.gov.planejamento.dipla.protocolo.storage;

import br.gov.planejamento.dipla.protocolo.dto.ArquivoDTO;
import org.springframework.web.context.request.async.DeferredResult;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

/**
 *
 * @author Leonardo Dias
 */
public class ArquivoStorageRunnable implements Runnable {

    private final MultipartFile[] files;
    private final DeferredResult<ArquivoDTO> deferredResult;
    private final ArquivoStorage arquivoStorage;

    public ArquivoStorageRunnable(MultipartFile[] files, DeferredResult<ArquivoDTO> deferredResult, ArquivoStorage arquivoStorage) {
        this.files = files;
        this.deferredResult = deferredResult;
        this.arquivoStorage = arquivoStorage;
    }

    @Override
    public void run() {
        String nomeArquivo = this.arquivoStorage.salvarTemporariamente(files);
        String contentType = files[0].getContentType();
        String nomeOriginal = files[0].getOriginalFilename();
        double s = files[0].getSize();
        double divisor = 1024;
        double size =  BigDecimal.valueOf(s / divisor).setScale(2, RoundingMode.FLOOR).doubleValue();
        NumberFormat nf = NumberFormat.getInstance(new Locale("pt", "BR"));  
        deferredResult.setResult(new ArquivoDTO(nomeOriginal, nomeArquivo, contentType, getLogoArquivo(nomeArquivo), nf.format(size)));
    }

    private String getLogoArquivo(String nomeArquivo) {
        if (nomeArquivo.endsWith("pdf")) {
            return "logos/pdf-logo.png";
            
        } else if (nomeArquivo.endsWith("docx") || nomeArquivo.endsWith("doc")) {
            return "logos/word-logo.png";
            
        } else if (nomeArquivo.endsWith("txt")) {
            return "logos/txt-logo.png";            

        } else if (nomeArquivo.endsWith("zip")) {
            return "logos/zip-logo.png";      
            
        } else if (nomeArquivo.endsWith("png") || nomeArquivo.endsWith("jpg") || nomeArquivo.endsWith("jpeg") || nomeArquivo.endsWith("bmp")) {
            return "logos/img-logo.png";
            
        } else {
            return "";
        }
    }
}
