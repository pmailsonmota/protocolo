package br.gov.planejamento.dipla.protocolo.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.gov.planejamento.dipla.protocolo.config.BrasilCidadaoConfig;
import br.gov.planejamento.dipla.protocolo.dto.TokenRetornoDto;
import br.gov.planejamento.dipla.protocolo.dto.UsuarioBrasilCidadaoDto;
import br.gov.planejamento.dipla.protocolo.entities.Grupo;
import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.entities.UsuarioBrasilCidadao;
import br.gov.planejamento.dipla.protocolo.mail.Mailer;
import br.gov.planejamento.dipla.protocolo.repositories.*;
import br.gov.planejamento.dipla.protocolo.security.BrasilCidadaoUserDetails;
import br.gov.planejamento.dipla.protocolo.security.LoginAttemptService;
import br.gov.planejamento.dipla.protocolo.security.UsuarioSistema;
import br.gov.planejamento.dipla.protocolo.services.AutoCadastroService;
import br.gov.planejamento.dipla.protocolo.services.BrasilCidadaoService;
import br.gov.planejamento.dipla.protocolo.services.CadastroUsuarioService;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;


import javax.servlet.http.HttpServletRequest;

/**
 * @author Leonardo Dias
 */
@Controller
public class LoginController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(LoginController.class);

	@Autowired
	private BrasilCidadaoConfig brasilCidadaoOpenIdConnectConfig;
	
    @Autowired
    private BrasilCidadaoService brasilCidadaoService;
    
    @Autowired
    LoginAttemptService loginAttemptService; 

    @Autowired
    private AutoCadastroService autoCadastroService;
    
    @Autowired
    private UsuarioRepository usuarioRepository;

    private String msgErro =null;
	
    @Value("${versao}")
    private String buildVersion;

    
    @GetMapping("/verificar-usuario")
    public ModelAndView confirmarCadastro(@AuthenticationPrincipal UsuarioSistema usuarioSistema) {
    	List<String> permissoes = usuarioRepository.permissoes(usuarioSistema.getUsuario());
        if (permissoes.contains("ROLE_BRASILCIDADAO")&&!usuarioSistema.getLoginBrasilCidadao()) {
        	usuarioSistema.eraseCredentials();
        	return new ModelAndView("/login");
        }
        loginAttemptService.loginSucceeded(usuarioSistema.getUsername());
        return new ModelAndView("redirect:/");
    }
    
    
    @RequestMapping("/login")
    public ModelAndView login(@RequestParam(value = "code", required = false) String code,
    		@AuthenticationPrincipal User user, 
    		@RequestParam(value = "logout", required = false) String logout,
    		HttpServletRequest httpServletRequest) {
    	msgErro = null;
    	ModelAndView mv = new ModelAndView("/Login");
    	mv.addObject("modalConfirmacaoBrasilCidadao",false);
        httpServletRequest.getSession().setAttribute("versao", buildVersion);
        if(code!=null){
        	try {
	    	  	UsuarioBrasilCidadaoDto usuarioretorno = brasilCidadaoService.autenticarBrasilCidadao(code);
		        if(usuarioretorno!=null) {
		           	Optional<UsuarioBrasilCidadao> usuarioBrasilCidadao = usuarioRepository.buscarBrasilCidadao(usuarioretorno.getCpf());
		        	Optional<Usuario> usuarioEmailExistente = usuarioRepository.findByEmail(usuarioretorno.getEmail());
		        	
		        	String baseUrl = String.format("%s://%s:%d/protocolo",httpServletRequest.getScheme(),  httpServletRequest.getServerName(), httpServletRequest.getServerPort());
	
		        	if(usuarioBrasilCidadao.isPresent()&&usuarioBrasilCidadao.get().getAtivo()) {
		        		mv.setViewName("redirect:/enviar");
		        		//Acesso validado
		        		SecurityContextHolder.getContext().setAuthentication(brasilCidadaoService.autenticarProtocolo(usuarioretorno));
		        		
		        		if(usuarioEmailExistente.isPresent()&&
		        				usuarioEmailExistente.get().getCodigo().equals(usuarioBrasilCidadao.get().getUsuario().getCodigo())) {
		        			autoCadastroService.atualizarBrasilCidadao(usuarioretorno, usuarioBrasilCidadao.get(), true);
		        		}else {
		        			autoCadastroService.atualizarBrasilCidadao(usuarioretorno, usuarioBrasilCidadao.get(), false);
		        			autoCadastroService.enviarConsiliacaoUsuario(usuarioBrasilCidadao.get(),usuarioretorno.getEmail(),baseUrl);
		        			mv.addObject("modalConflito",true);
		        			mv.addObject("email",usuarioretorno.getEmail());
		        		}
	        			
		        	}else if(usuarioBrasilCidadao.isPresent()&&!usuarioBrasilCidadao.get().getAtivo()) {
		        		
		        		//Acesso não validado
		        		if(!usuarioEmailExistente.isPresent()) {
		        			autoCadastroService.cadastrarBrasilCidadao(usuarioretorno);
		        		}
		        		autoCadastroService.enviarConsiliacaoUsuario(usuarioBrasilCidadao.get(),usuarioretorno.getEmail(),baseUrl);
	        			mv.addObject("modalConfirmacaoBrasilCidadao",true);
	        			mv.addObject("email",usuarioretorno.getEmail());
	
		        	}else if(!usuarioBrasilCidadao.isPresent()) {
		        		
		        		//Primeiro Acesso
		        		if(!usuarioEmailExistente.isPresent()) {
		        			autoCadastroService.cadastrarBrasilCidadao(usuarioretorno);
		        		}
		        		autoCadastroService.migrarBrasilCidadao(usuarioretorno);
		        		autoCadastroService.enviarConsiliacaoUsuario(usuarioBrasilCidadao.get(),usuarioretorno.getEmail(),baseUrl);
	        			mv.addObject("modalConfirmacaoBrasilCidadao",true);
	        			mv.addObject("email",usuarioretorno.getEmail());
		        	}
		        	
		        }
        	}catch (Exception e){
        		msgErro=e.getMessage();
        	}
        } 
        if(msgErro!=null&&!msgErro.isEmpty()){
			// Capturar erro na execução do a cesso ao abrasil cidadão
			mv.addObject("userBrasilCidadao",true);
			mv.addObject("msgBrasilCidadao",msgErro);
		}
        mv.addObject("urlLogin",brasilCidadaoOpenIdConnectConfig.gerarUrlAutorizar());
        return mv;
    }
}