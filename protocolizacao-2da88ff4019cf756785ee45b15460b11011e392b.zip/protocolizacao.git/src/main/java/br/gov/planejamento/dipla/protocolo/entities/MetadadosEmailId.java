package br.gov.planejamento.dipla.protocolo.entities;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.Embeddable;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import java.io.Serializable;

/**
 *
 * @author Leonardo Dias
 */
@Getter
@Setter
@EqualsAndHashCode
@Embeddable
public class MetadadosEmailId implements Serializable {

    private static final long serialVersionUID = 1L;

    @ManyToOne
    @JoinColumn(name = "codigo_email")
    private ConfiguracaoEmail email;

    @ManyToOne
    @JoinColumn(name = "codigo_metadado")
    private Metadado metadado;

}
