/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.repositories.helper.tiposDocumento;

import br.gov.planejamento.dipla.protocolo.entities.TiposDocumento;
import br.gov.planejamento.dipla.protocolo.repositories.filter.TiposDocumentoFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 *
 * @author leonardo
 */
public interface TiposDocumentoRepositoryQueries {

    public Page<TiposDocumento> filtrar(TiposDocumentoFilter tiposDocumentoFilter, Pageable pageable);
}
