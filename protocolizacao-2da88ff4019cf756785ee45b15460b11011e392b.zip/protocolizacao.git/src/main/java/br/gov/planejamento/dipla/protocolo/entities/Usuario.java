package br.gov.planejamento.dipla.protocolo.entities;

import br.gov.planejamento.dipla.protocolo.validation.AtributoConfirmacao;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.SafeHtml;
import org.springframework.util.StringUtils;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;
import lombok.AccessLevel;

/**
 *
 * @author Leonardo Dias
 */
@Entity
@Getter
@Setter
@EqualsAndHashCode(of = {"codigo"})
@Table(name = "usuario", schema = "protocolo")
@AtributoConfirmacao(atributo = "senha", atributoConfirmacao = "confirmacaoSenha", message = "Confirmação da senha não confere")
public class Usuario implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codigo;

    @Size(max = 50, message = "O nome só pode conter até 50 caracteres.")
    @NotBlank(message = "Nome é obrigatório.")
    @Getter(AccessLevel.NONE)
    @Column(name = "nome")
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE)
    private String nome;

    @Size(max = 50, message = "O nome social só pode conter até 50 caracteres.")
    @Column(name = "nome_social", nullable = true)
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE)
    private String nome_social;

    @NotBlank(message = "E-mail é obrigatório.")
    @Email(message = "E-mail inválido")
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE)
    private String email;

    private String senha;

    @NotBlank(message = "O telefone é de preenchimento obrigatório.")
    @Length(min = 14, message = "Formato de telefone inválido. Formato esperado (99) 9999-9999 ou (99) 99999-9999 ")
    private String telefone;

    private Boolean ativo;

    @NotNull(message = "Grupo é obrigatório")
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "usuario_grupo", joinColumns = @JoinColumn(name = "codigo_usuario"), inverseJoinColumns = @JoinColumn(name = "codigo_grupo"))
    private List<Grupo> grupos;

    @Transient
    private String confirmacaoSenha;

    @Transient
    private String nomeOriginal;

    @Transient
    private Boolean temPerfilAdministrador;

    @Transient
    private Boolean temPerfilBrasilCidadao;

    @Transient
    private String urlConfirmacaoCadastro;
    
    @Transient
    private String urlDesbloqueio;

    public boolean isNovo() {
        return codigo == null;
    }

    public String getNome() {
        if (isUsaNomeSocial()) {
            return nome_social;
        } else {
            return nome;
        }
    }

    public String getNomeReal() {

        return this.nome;
    }

    public String getNomeOriginal(){
        return this.nome;
    }

    public void setNomeOriginal(String nomeOriginal){
        this.nome=nomeOriginal;
    }

    public boolean isUsaNomeSocial() {
        return nome_social != null && !nome_social.trim().isEmpty();
    }

    @PreUpdate
    private void preUpdate() {
        this.confirmacaoSenha = senha;
    }
}
