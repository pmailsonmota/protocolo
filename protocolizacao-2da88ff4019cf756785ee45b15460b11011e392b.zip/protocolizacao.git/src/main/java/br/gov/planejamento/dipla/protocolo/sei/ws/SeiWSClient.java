package br.gov.planejamento.dipla.protocolo.sei.ws;

import Sei.*;
import br.gov.planejamento.dipla.protocolo.entities.Arquivos;
import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEnum;
import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
import br.gov.planejamento.dipla.protocolo.mail.Mailer;
import br.gov.planejamento.dipla.protocolo.repositories.ArquivosRepository;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoRepository;
import br.gov.planejamento.dipla.protocolo.services.SalvarProtocoloService;
import br.gov.planejamento.dipla.protocolo.storage.ArquivoStorage;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.Base64Utils;

import java.io.Console;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.util.List;
import java.util.Optional;

import static java.nio.file.FileSystems.getDefault;

import java.util.concurrent.CompletableFuture;

import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;





@Component
public class SeiWSClient {

    @Autowired
    private Mailer mailer;

    @Autowired
    private ConfiguracaoRepository configuracaoRepository;

    @Autowired
    private SalvarProtocoloService salvarProtocoloService;

    @Autowired
    private ArquivosRepository arquivosRepository;

    @Autowired
    private ArquivoStorage arquivoStorage;

    private String getDateTime() {
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        Date date = new Date();
        return dateFormat.format(date);
    }

    @Async
    public String enviar(Protocolo protocolo, Long idUsuario, String sei, String tipo) {

        if (sei!=null && tipo!=null && !sei.isEmpty() && tipo.equals("existente")) {
            enviarDocumento( protocolo, idUsuario, sei );
        } else {

            try {
                URL urlEndpoint = new URL( configuracaoRepository.recuperarValor( ConfiguracaoEnum.URL_ENDPOINT ) );
                SeiBindingStub seiBindingStub = new SeiBindingStub( urlEndpoint, null );
                seiBindingStub.setTimeout( 600000 * 60 );


                /*Assunto assunto = new Assunto();
                assunto.setCodigoEstruturado( configuracaoRepository.recuperarValor( ConfiguracaoEnum.ASSUNTO_CODIGO_ESTRUTURADO ) );
                Assunto[] assuntos = {assunto};*/

                Procedimento procedimento = new Procedimento();
                if (tipo.equals("novo")) {
                    procedimento.setNumeroProtocolo( sei );
                    procedimento.setDataAutuacao( getDateTime() );
                }

                procedimento.setAssuntos( recuperaAssunto() );
                procedimento.setEspecificacao( configuracaoRepository.recuperarValor( ConfiguracaoEnum.PROCEDIMENTO_ESPECIFICADO ) );

                Interessado interessado = new Interessado();
                interessado.setNome( protocolo.getUsuario().getNome() );
                interessado.setSigla( "Telefone: " + protocolo.getUsuario().getTelefone() );
                Interessado[] interessados = {interessado};

                procedimento.setInteressados( interessados );

                procedimento.setNivelAcesso( configuracaoRepository.recuperarValor( ConfiguracaoEnum.PROCEDIMENTO_NIVEL_ACESSO ) );
                procedimento.setIdTipoProcedimento( configuracaoRepository.recuperarValor( ConfiguracaoEnum.PROCEDIMENTO_ID_TIPO_PROCEDIMENTO ) );

                List<Arquivos> arquivosList = arquivosRepository.findByProtocolo( protocolo );

                procedimento.setObservacao(
                        protocolo.toString() +
                                "\n" +
                                "Quantidade Arquivos: " + arquivosList.size()
                );


                //criando o procedimento
                RetornoGeracaoProcedimento retornoGeracaoProcedimento = seiBindingStub.gerarProcedimento(
                        configuracaoRepository.recuperarValor( ConfiguracaoEnum.SIGLA_SISTEMA ),
                        configuracaoRepository.recuperarValor( ConfiguracaoEnum.IDENTIFICACAO_SERVICO ),
                        configuracaoRepository.recuperarValor( ConfiguracaoEnum.ID_UNIDADE ),
                        procedimento,
                        null,
                        null,
                        null,
                        "N",
                        "N",
                        null,
                        null,
                        "N",
                        null,
                        null );


                arquivosList.forEach( arquivo -> {
                    try {
                        Documento documento = new Documento();
                        documento.setIdProcedimento( retornoGeracaoProcedimento.getProcedimentoFormatado()
                                .replace( ".", "" )
                                .replace( "/", "" )
                                .replace( "-", "" ) );
                        documento.setObservacao( protocolo.toString());
                        documento.setDescricao( arquivo.getDescricaoDocumento() );
                        documento.setNomeArquivo( arquivo.getNomeOriginal() );
                        documento.setTipo( configuracaoRepository.recuperarValor( ConfiguracaoEnum.DOCUMENTO_TIPO ) );
                        //documento.setIdSerie(env.getProperty("documento.id-serie")); //TODO: Alterar para pegar da combo Tipo Documento
                        documento.setIdSerie( arquivo.getTipoDocumento().getCodigoSei() ); //Tipo documento vindo do banco de dados
                        documento.setData( protocolo.getDataFormatada() );
                        documento.setNivelAcesso( configuracaoRepository.recuperarValor( ConfiguracaoEnum.DOCUMENTO_NIVEL_ACESSO ) );

                        Path path = getDefault().getPath( configuracaoRepository.recuperarValor( ConfiguracaoEnum.STORAGE_PATH ) ).resolve( arquivo.getNome() );
                        documento.setConteudo( Base64Utils.encodeToString( FileUtils.readFileToByteArray( path.toFile() ) ) );

                        seiBindingStub.incluirDocumento(
                                configuracaoRepository.recuperarValor( ConfiguracaoEnum.SIGLA_SISTEMA ),
                                configuracaoRepository.recuperarValor( ConfiguracaoEnum.IDENTIFICACAO_SERVICO ),
                                configuracaoRepository.recuperarValor( ConfiguracaoEnum.ID_UNIDADE ),
                                documento
                        );
                    } catch (IOException e) {
                        protocolo.setErroWs("[ERRO INCLUIR DOCUMENTO] " + e.getMessage()  );
                        throw new RuntimeException( e.getMessage() );
                    }
                } );
                
                protocolo.setLinkSEI(retornoGeracaoProcedimento.getLinkAcesso());
                protocolo.setNupe( retornoGeracaoProcedimento.getProcedimentoFormatado() );
                salvarProtocoloService.aprovar( protocolo, idUsuario );

                //System.out.println("NUP TEMPORÃ�RIO");
                //System.out.println(protocolo.getEmail1());

                protocolo.setArquivosList(arquivosList);
                mailer.enviarAceite( protocolo );

                /*arquivosList.forEach( arquivo -> {
                    arquivoStorage.excluir( arquivo.getNome() );
                } );*/


                return retornoGeracaoProcedimento.getProcedimentoFormatado();

            } catch (Exception e) {
                protocolo.setErroWs("[ERRO GERAR PROCEDIMENTO] " + e.getMessage()  );
                e.printStackTrace();
                rollback( protocolo, e.getMessage() );
            }
        }

        return null;
    }

    /**
     *
     * @return array
     */
    private Assunto[] recuperaAssunto() {
        Assunto assunto = new Assunto();
        assunto.setCodigoEstruturado( configuracaoRepository.recuperarValor( ConfiguracaoEnum.ASSUNTO_CODIGO_ESTRUTURADO ) );
        Assunto[] assuntos = {assunto};
        return assuntos;
    }

    private void rollback(Protocolo protocolo, String msgErro) {
        protocolo.setNupe( null );
        salvarProtocoloService.pendente( protocolo );
        mailer.enviarEmailErroEnvioSEI( protocolo, msgErro );
    }

    public String enviarDocumento(Protocolo protocolo, Long idUsuario, String sei) {
    	String observacaoAnterior="";
    	try {
    		
    		URL urlEndpoint = new URL( configuracaoRepository.recuperarValor( ConfiguracaoEnum.URL_ENDPOINT ) );
            SeiBindingStub seiBindingStub = new SeiBindingStub( urlEndpoint, null );
            seiBindingStub.setTimeout( 600000 * 60 );
    		
            List<Arquivos> arquivosList = arquivosRepository.findByProtocolo( protocolo );

            arquivosList.forEach( arquivo -> {
                try {
                    Documento documento = new Documento();
                    //documento.setIdProcedimento( sei );
                    documento.setIdProcedimento( sei
                            .replace( ".", "" )
                            .replace( "/", "" )
                            .replace( "-", "" ) );
                    documento.setObservacao( protocolo.toString());
                    documento.setDescricao( arquivo.getDescricaoDocumento() );
                    documento.setNomeArquivo( arquivo.getNomeOriginal() );
                    documento.setTipo( configuracaoRepository.recuperarValor( ConfiguracaoEnum.DOCUMENTO_TIPO ) );
                    //documento.setIdSerie(env.getProperty("documento.id-serie")); //TODO: Alterar para pegar da combo Tipo Documento
                    documento.setIdSerie( arquivo.getTipoDocumento().getCodigoSei() ); //Tipo documento vindo do banco de dados
                    documento.setData( protocolo.getDataFormatada() );
                    documento.setNivelAcesso( configuracaoRepository.recuperarValor( ConfiguracaoEnum.DOCUMENTO_NIVEL_ACESSO ) );

                    Path path = getDefault().getPath( configuracaoRepository.recuperarValor( ConfiguracaoEnum.STORAGE_PATH ) ).resolve( arquivo.getNome() );
                    documento.setConteudo( Base64Utils.encodeToString( FileUtils.readFileToByteArray( path.toFile() ) ) );

                    seiBindingStub.incluirDocumento(
                            configuracaoRepository.recuperarValor( ConfiguracaoEnum.SIGLA_SISTEMA ),
                            configuracaoRepository.recuperarValor( ConfiguracaoEnum.IDENTIFICACAO_SERVICO ),
                            configuracaoRepository.recuperarValor( ConfiguracaoEnum.ID_UNIDADE ),
                            documento
                    );
                } catch (IOException e) {
                    protocolo.setErroWs("[ERRO INCLUIR DOCUMENTO] " + e.getMessage()  );
                    throw new RuntimeException( e.getMessage() );
                }
            } );
            
            protocolo.setNupe( sei );
            //protocolo.setNupe( retornoGeracaoProcedimento.getProcedimentoFormatado() );
            salvarProtocoloService.aprovar( protocolo, idUsuario );
            
            protocolo.setArquivosList(arquivosRepository.findByProtocolo(protocolo));
            mailer.enviarAceite( protocolo );

            /*arquivosList.forEach( arquivo -> {
                arquivoStorage.excluir( arquivo.getNome() );
            } );*/


            return sei;


        } catch (Exception e) {
            e.printStackTrace();
            rollback( protocolo, e.getMessage() );
        }

        return null;

    }
    public RetornoConsultaProcedimento consultarProtocoloSei(String sei) {
    	Optional<String> retorno = Optional.ofNullable(null);
    	RetornoConsultaProcedimento retornoConsultaProcedimento = new RetornoConsultaProcedimento();
    	try {
	    	URL urlEndpoint = new URL( configuracaoRepository.recuperarValor( ConfiguracaoEnum.URL_ENDPOINT ) );
	    	SeiBindingStub seiBindingStub = new SeiBindingStub( urlEndpoint, null );
	    	retornoConsultaProcedimento = seiBindingStub.consultarProcedimento(
	            configuracaoRepository.recuperarValor( ConfiguracaoEnum.SIGLA_SISTEMA ),
	            configuracaoRepository.recuperarValor( ConfiguracaoEnum.IDENTIFICACAO_SERVICO ),
	            configuracaoRepository.recuperarValor( ConfiguracaoEnum.ID_UNIDADE ),
	            sei,
	            "S",
	            "S",
	            "S",
	            "S",
	            "S",
	            "S",
	            "S",
	            "S",
	            "S"
	    	);
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
    	return retornoConsultaProcedimento;
    }


}
