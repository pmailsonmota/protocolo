package br.gov.planejamento.dipla.protocolo.repositories.helper.configuracao;

import br.gov.planejamento.dipla.protocolo.dto.MetadadosDTO;
import br.gov.planejamento.dipla.protocolo.entities.Configuracao;
import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEnum;
import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.entities.UsuarioBrasilCidadao;
import br.gov.planejamento.dipla.protocolo.repositories.filter.ConfiguracaoFilter;
import br.gov.planejamento.dipla.protocolo.repositories.filter.ProtocoloFilter;
import br.gov.planejamento.dipla.protocolo.repositories.filter.UsuarioFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

/**
 *
 * @author Leonardo Dias
 */
public interface ConfiguracaoRepositoryQueries {

    public String recuperarValor(ConfiguracaoEnum nome);
    public Page<Configuracao> filtrar(ConfiguracaoFilter configuracaoFilter, Pageable pageable);
    public Optional<Configuracao> findByNome(String nome);
}
