package br.gov.planejamento.dipla.protocolo.services.impl;

import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
import br.gov.planejamento.dipla.protocolo.services.ProtocoloFlagService;
import br.gov.planejamento.dipla.protocolo.repositories.ProtocoloRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Created by dario on 29/09/17.
 */
@Service
public class ProtocoloFlagServiceImpl implements ProtocoloFlagService {

    @Autowired
    private ProtocoloRepository protocoloRepository;


    @Override
    public Optional<Protocolo> buscarStatusPorCodigo(Long codigo) {
        return Optional.ofNullable(protocoloRepository.findByCodigo(codigo));
    }
}
