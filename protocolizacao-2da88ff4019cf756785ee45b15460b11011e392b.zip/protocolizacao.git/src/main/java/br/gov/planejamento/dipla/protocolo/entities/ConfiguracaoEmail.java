package br.gov.planejamento.dipla.protocolo.entities;

import br.gov.planejamento.dipla.protocolo.validation.AtributoConfirmacao;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Leonardo Dias
 */
@Entity
@Getter
@Setter
@EqualsAndHashCode(of = {"codigo"})
@Table(name = "configuracao_email", schema = "protocolo")
public class ConfiguracaoEmail implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer codigo;
    
    @Column(name = "nome")
    private String nome;

    @Column(name = "valor")
    @NotBlank(message = "Valor é obrigatório.")
    private String valor;
    
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "metadado_email", joinColumns = @JoinColumn(name = "codigo_email"), inverseJoinColumns = @JoinColumn(name = "codigo_metadado"))
    private List<Metadado> metadados;
    
    
    
}
