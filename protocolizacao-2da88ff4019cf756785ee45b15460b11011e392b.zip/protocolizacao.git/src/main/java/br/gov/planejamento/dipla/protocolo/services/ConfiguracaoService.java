/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.services;

import br.gov.planejamento.dipla.protocolo.entities.Configuracao;
import br.gov.planejamento.dipla.protocolo.entities.TiposDocumento;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.TiposDocumentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 *
 * @author leonardo
 */
@Service
public class ConfiguracaoService {

    @Autowired
    private ConfiguracaoRepository configuracaoRepository;
    
    public void salvar(Configuracao configuracao) {
        Optional<Configuracao> configuracaoOptional = configuracaoRepository.findByNome(configuracao.getNome());
        if (configuracaoOptional.isPresent()) {
        	configuracaoRepository.delete(configuracaoOptional.get());
        }
        configuracaoRepository.save(configuracao);
    }

    @Transactional
    public void editar(Configuracao configuracao) {
    	Optional<Configuracao> configuracaoSave = configuracaoRepository.findByCodigo(configuracao.getCodigo());
    	configuracaoSave.get().setValor(configuracao.getValor());
    	configuracaoSave.get().setDescricao(configuracao.getDescricao());
    	configuracaoRepository.save(configuracaoSave.get());
    }
    
    public void excluir(Configuracao configuracao) {
    	configuracaoRepository.delete(configuracao);
    }
}
