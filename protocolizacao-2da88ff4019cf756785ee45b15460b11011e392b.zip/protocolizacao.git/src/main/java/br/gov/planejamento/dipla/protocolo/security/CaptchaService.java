package br.gov.planejamento.dipla.protocolo.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEnum;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoRepository;
import br.gov.planejamento.dipla.protocolo.services.exeptions.ReCaptchaUnavailableException;

import javax.servlet.http.HttpServletRequest;
import java.net.URI;

@Service("captchaService")
public class CaptchaService {
    private final static Logger LOGGER = LoggerFactory.getLogger(CaptchaService.class);

    @Autowired
    private ConfiguracaoRepository configuracaoRepository;
    
    @Autowired
    private HttpServletRequest request;


    public Boolean processResponse(final String response) throws ReCaptchaUnavailableException {
        LOGGER.debug("Attempting to validate response {}", response);

        final URI verifyUri = URI.create(String.format("https://www.google.com/recaptcha/api/siteverify?secret=%s&response=%s&remoteip=%s", getReCaptchaSecret(), response, getClientIP()));
        try {
        	RestTemplate restTemplate = new RestTemplate();
            final GoogleResponse googleResponse = restTemplate.getForObject(verifyUri, GoogleResponse.class);
            LOGGER.debug("Google's response: {} ", googleResponse.toString());

            if (!googleResponse.isSuccess()) {
            	throw new ReCaptchaUnavailableException();
            }
            
            if (googleResponse.isSuccess()) {
            	return true;
            }
        } catch (ReCaptchaUnavailableException e) {
        	throw new ReCaptchaUnavailableException("Erro na validação do captcha");
        }
        return false;
    }


    public String getReCaptchaSite() {
        return configuracaoRepository.findByNome(ConfiguracaoEnum.CAPTCHA_SITE_KEY.name()).get().getValor();
    }

    public String getReCaptchaSecret() {
        return configuracaoRepository.findByNome(ConfiguracaoEnum.CAPTCHA_SECRET_KEY.name()).get().getValor();
    }
    
    private String getClientIP() {
        final String xfHeader = request.getHeader("X-Forwarded-For");
        if (xfHeader == null) {
            return request.getRemoteAddr();
        }
        return xfHeader.split(",")[0];
    }
}
