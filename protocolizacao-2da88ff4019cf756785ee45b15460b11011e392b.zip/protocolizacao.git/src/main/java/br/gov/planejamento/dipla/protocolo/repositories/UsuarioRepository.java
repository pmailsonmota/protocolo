package br.gov.planejamento.dipla.protocolo.repositories;

import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.repositories.helper.usuario.UsuarioRepositoryQueries;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 *
 * @author Leonardo Dias
 */
@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long>, UsuarioRepositoryQueries {

    public List<Usuario> findByCodigoIn(Long[] codigos);

    public Optional<Usuario> findByEmail(String email);
    
}
