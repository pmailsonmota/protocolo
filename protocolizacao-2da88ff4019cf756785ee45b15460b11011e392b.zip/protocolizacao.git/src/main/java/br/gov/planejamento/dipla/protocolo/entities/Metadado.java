package br.gov.planejamento.dipla.protocolo.entities;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotBlank;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author Leonardo Dias
 */
@Entity
@Getter
@Setter
@EqualsAndHashCode(of = {"codigo"})
@Table(name = "metadado", schema = "protocolo")
public class Metadado implements Serializable {

    private static final long serialVersionUID = 1L;
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer codigo;

    @Column(name = "nome")
    private String nome;

    @Column(name = "valor")
    private String valor;
    
    @Column(name = "descricao")
    private String descricao;
    
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(name = "metadado_email", joinColumns = @JoinColumn(name = "codigo_metadado"), inverseJoinColumns = @JoinColumn(name = "codigo_email"))
    private List<ConfiguracaoEmail> email;
}
