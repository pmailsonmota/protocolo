/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.entities;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.io.Serializable;

/**
 *
 * @author leonardo
 */
@Entity
@Getter
@Setter
@EqualsAndHashCode(of = {"id"})
@Table(name = "metadado_email", schema = "protocolo")
public class MetadadosEmail implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private MetadadosEmailId id;

}
