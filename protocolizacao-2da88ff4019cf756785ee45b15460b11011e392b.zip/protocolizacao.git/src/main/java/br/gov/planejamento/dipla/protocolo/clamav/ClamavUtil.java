package br.gov.planejamento.dipla.protocolo.clamav;

import fi.solita.clamav.ClamAVClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Component

/* @PropertySource(value = {"file:${HOME}/.protocolo-config/clamav.properties"}) */

public class ClamavUtil {

    @Autowired
    private Environment env;

    public boolean isClean(byte... strem) {
        /*String clamavHost = env.getProperty("clamav.host");
        ClamAVClient cl = new ClamAVClient(clamavHost, 3310);
        byte[] reply;
        try {
            reply = cl.scan(strem);
        } catch (Exception e) {
            throw new RuntimeException("Erro no padrão do PDF: " + e.getMessage(), e);
        }
        return ClamAVClient.isCleanReply(reply);*/
        return true;
    }
}
