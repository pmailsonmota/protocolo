/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.controllers;

import br.gov.planejamento.dipla.protocolo.controllers.page.PageWrapper;
import br.gov.planejamento.dipla.protocolo.entities.TiposDocumento;
import br.gov.planejamento.dipla.protocolo.repositories.TiposDocumentoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.filter.TiposDocumentoFilter;
import br.gov.planejamento.dipla.protocolo.services.TiposDocumentoService;
import br.gov.planejamento.dipla.protocolo.services.exeptions.TipoDocumentoJaCadastradoException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

/**
 *
 * @author leonardo
 */
@Controller
@RequestMapping("/tipos-documento")
public class TiposDocumentoController {

    @Autowired
    private TiposDocumentoRepository tiposDocumentoRepository;

    @Autowired
    private TiposDocumentoService tiposDocumentoService;

    @GetMapping("/novo")
    public ModelAndView novo(TiposDocumento tiposDocumento) {
        ModelAndView mv = new ModelAndView("tipos_documento/CadastroTiposDocumento");
        return mv;
    }

    @PostMapping({"/novo", "{\\d+}"})
    public ModelAndView salvar(@Valid TiposDocumento tiposDocumento, BindingResult result, RedirectAttributes attributes) {
        if (result.hasFieldErrors()) {
            return novo(tiposDocumento);
        }
        try {
            tiposDocumentoService.salvar(tiposDocumento);
        } catch (TipoDocumentoJaCadastradoException e) {
            result.rejectValue("descricao", null, e.getMessage());
            return novo(tiposDocumento);
        } catch (DataIntegrityViolationException e) {
            result.rejectValue("codigo", null, "Não é possível alterar o código pois este Tipo de Documento já  está sendo usando.");
            return novo(tiposDocumento);
        }
        attributes.addFlashAttribute("mensagem", "Tipo de Documento salvo com sucesso.");
        return new ModelAndView("redirect:/tipos-documento/novo");
    }

    @GetMapping()
    public ModelAndView pesquisar(TiposDocumentoFilter tiposDocumentoFilter, BindingResult result, @PageableDefault(size = 10) Pageable pageable, HttpServletRequest httpServletRequest) {
        ModelAndView mv = new ModelAndView("tipos_documento/PesquisaTiposDocumento");
        PageWrapper<TiposDocumento> paginaWrapper = new PageWrapper<>(tiposDocumentoRepository.filtrar(tiposDocumentoFilter, pageable), httpServletRequest);
        mv.addObject("pagina", paginaWrapper);
        return mv;
    }

    @DeleteMapping("/{codigo}")
    public @ResponseBody ResponseEntity<?> excluir(@PathVariable("codigo") TiposDocumento tiposDocumento){
        tiposDocumentoService.excluir(tiposDocumento);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{codigo}")
    public ModelAndView editar(@PathVariable("codigo") TiposDocumento tiposDocumento) {
        ModelAndView mv = new ModelAndView("tipos_documento/EditarTiposDocumento");
        mv.addObject(tiposDocumento);
        return mv;
    }

    /**
     * método para editar o tipo de documento
     * @param tiposDocumento
     * @param result
     * @param attributes
     * @return ModelAndView
     */
    @PostMapping("/editarTipoDocumento/{codigo}")
    public ModelAndView editarTipoDocumento(@Valid TiposDocumento tiposDocumento, BindingResult result, RedirectAttributes attributes) {
        if (result.hasFieldErrors()) {
            return novo(tiposDocumento);
        }
        tiposDocumentoService.editar(tiposDocumento);
        attributes.addFlashAttribute("mensagem", "Tipo de Documento editado com sucesso.");
        return new ModelAndView("redirect:/tipos-documento");
    }
}
