package br.gov.planejamento.dipla.protocolo.services.annotation;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * Created by dario on 27/09/17.
 */
public class GroupProtocoloValidator implements ConstraintValidator<GroupProtocolo, Integer>{
    @Override
    public void initialize(GroupProtocolo groupProtocolo) {
    }

    @Override
    public boolean isValid(Integer integer, ConstraintValidatorContext constraintValidatorContext) {
        return false;
    }
}
