package br.gov.planejamento.dipla.protocolo.services.event;

import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

@Getter
public class AprovarProtocoloEvent extends ApplicationEvent {

    private Protocolo protocolo;
    private Long idUsuario;
    private String sei;
    private String tipo;

    public AprovarProtocoloEvent(Object source, Protocolo protocolo, Long idUsuario, String sei, String tipo) {
        super(source);
        this.protocolo = protocolo;
        this.idUsuario = idUsuario;
        this.sei = sei;
        this.tipo = tipo;
    }
}
