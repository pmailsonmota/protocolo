package br.gov.planejamento.dipla.protocolo.dto;

import lombok.Getter;
import lombok.Setter;
import java.util.Optional;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * Created by dario on 29/09/17.
 */
@Getter
@Setter
public class ProtocoloFlagDTO {
    private String status;
    //private String observacao;
    private Optional<String> observacao = Optional.empty();


    @Override
    public String toString() {
        return "ProtocoloFlagDTO [status="
                + status + ", observacao=" + observacao + "]";
    }
}
