package br.gov.planejamento.dipla.protocolo.repositories;

import br.gov.planejamento.dipla.protocolo.entities.Configuracao;
import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEnum;
import br.gov.planejamento.dipla.protocolo.repositories.helper.configuracao.ConfiguracaoRepositoryQueries;
import br.gov.planejamento.dipla.protocolo.repositories.helper.usuario.UsuarioRepositoryQueries;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 *
 * @author Leonardo Dias
 */
@Repository
public interface ConfiguracaoRepository extends JpaRepository<Configuracao, Long>, ConfiguracaoRepositoryQueries {
    
    public Optional<Configuracao> findByCodigo(Long codigo);
    
    public String recuperarValor(ConfiguracaoEnum nome);
    
}
