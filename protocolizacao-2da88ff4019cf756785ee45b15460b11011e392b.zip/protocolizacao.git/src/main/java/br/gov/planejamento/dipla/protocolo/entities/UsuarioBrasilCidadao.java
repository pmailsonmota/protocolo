package br.gov.planejamento.dipla.protocolo.entities;

import br.gov.planejamento.dipla.protocolo.validation.AtributoConfirmacao;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotBlank;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author Leonardo Dias
 */
@Entity
@Getter
@Setter
@EqualsAndHashCode(of = {"codigo"})
@Table(name = "usuario_brasil_cidadao", schema = "protocolo")
public class UsuarioBrasilCidadao implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codigo;

    @Size(max = 15)
    @NotBlank(message = "Nome é obrigatório.")
    private String cpf;
    
    @Column(name = "email", nullable = true)
    private String email;
    
    @Column(name = "token")
    private String token;

    @Column(name = "ativo")
    private Boolean ativo;

    @OneToOne
    @JoinColumn(name = "codigo_usuario")
    private Usuario usuario;
        
}
