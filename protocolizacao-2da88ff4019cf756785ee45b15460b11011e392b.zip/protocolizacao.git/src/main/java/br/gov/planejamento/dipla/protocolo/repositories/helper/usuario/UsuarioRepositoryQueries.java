package br.gov.planejamento.dipla.protocolo.repositories.helper.usuario;

import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.entities.UsuarioBrasilCidadao;
import br.gov.planejamento.dipla.protocolo.repositories.filter.UsuarioFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

/**
 *
 * @author Leonardo Dias
 */
public interface UsuarioRepositoryQueries {

    public Optional<Usuario> porEmailEAtivo(String email);

    public List<String> permissoes(Usuario usuario);

    public Page<Usuario> filtrar(UsuarioFilter filtro, Pageable pageable);

    public Usuario buscarComGrupos(Long codigo);

	public Optional<UsuarioBrasilCidadao> buscarBrasilCidadao(String cpf);
	
	public Boolean verificarUsuarioBrasilCidadao(Long usuario);
}
