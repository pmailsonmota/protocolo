package br.gov.planejamento.dipla.protocolo.controllers;

import br.gov.planejamento.dipla.protocolo.clamav.ClamavUtil;
import br.gov.planejamento.dipla.protocolo.controllers.sessions.ArquivosSession;
import br.gov.planejamento.dipla.protocolo.dto.ArquivoDTO;
import br.gov.planejamento.dipla.protocolo.entities.Arquivos;
import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEnum;
import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
import br.gov.planejamento.dipla.protocolo.repositories.ArquivosRepository;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoRepository;
import br.gov.planejamento.dipla.protocolo.storage.ArquivoStorage;
import br.gov.planejamento.dipla.protocolo.storage.ArquivoStorageRunnable;
import org.apache.tomcat.util.threads.ThreadPoolExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.config.Task;
import org.springframework.security.access.method.P;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.DeferredResult;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.UriUtils;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URLEncoder;
import java.nio.file.Files;
import java.util.Base64;
import java.util.List;
import java.io.*;







/**
 *
 * @author Leonardo Dias
 */
@RestController
@RequestMapping("/arquivos")
public class ArquivosController {

    @Autowired
    private ArquivoStorage arquivoStorage;
    
    @Autowired
    private ArquivosSession arquivosSession;
    
    @Autowired
    private ArquivosRepository arquivosRepository;

    @Autowired
    private ClamavUtil clamavUtil;

    @Autowired
    private ConfiguracaoRepository configuracaoRepository;

    @PostMapping
    public DeferredResult<ArquivoDTO> upload(@RequestParam("files[]") MultipartFile... files) throws InterruptedException {
        DeferredResult<ArquivoDTO> deferredResult = new DeferredResult<>();

        try {
            if (!clamavUtil.isClean(files[0].getBytes())) {
                throw new RuntimeException("PDF fora do padrão. Não será possível o recebimento.");
            }
        } catch (IOException e) {
            throw new RuntimeException("PDF fora do padrão. Não será possível o recebimento.", e);
        }


        Thread thread = new Thread(new ArquivoStorageRunnable(files, deferredResult, arquivoStorage));
        thread.start();
        //thread.sleep(5000);

        return deferredResult;
    }
    
    @GetMapping(value = "/{uuid}", produces = { MediaType.APPLICATION_JSON_VALUE })
    public @ResponseBody ResponseEntity<List<ArquivoDTO>> listarArquivos(@PathVariable String uuid) {
        return ResponseEntity.ok(arquivosSession.obterArquivos(uuid));
    }
    
    @PostMapping("/anexar")
    public @ResponseBody ResponseEntity<?> anexar(@RequestBody ArquivoDTO arquivoDTO) {
        arquivosSession.adicionarArquivo(arquivoDTO.getUuid(), arquivoDTO);
        return ResponseEntity.ok().build();
    }    
    
    @DeleteMapping(value = "/{uuid}")
    public @ResponseBody ResponseEntity<?> excluir(@PathVariable String uuid, @RequestParam(name = "nome") String nome) {
        arquivosSession.excluirArquivo(uuid, nome);
        return ResponseEntity.ok().build();
    }
    
    @GetMapping(value = "/protocolo", produces = { MediaType.APPLICATION_JSON_VALUE })
    public @ResponseBody ResponseEntity<List<Arquivos>> obterArquivosProtocolo(@RequestParam("htr") String codigo, HttpServletRequest httpServletRequest) {
        Protocolo protocolo = new Protocolo();
        byte[] decodedBytes = Base64.getDecoder().decode( codigo );
        String decodedString = new String(decodedBytes);
        String[] parts = decodedString.split("\\|", -1);
        Long decodedLong = Long.parseLong(parts[1].toString());
        protocolo.setCodigo(decodedLong);
        List<Arquivos> arquivosList = arquivosRepository.findByProtocolo(protocolo);
        arquivosList.forEach((arquivo) -> {
            arquivo.getProtocolo().setArquivosList(null);
            arquivo.setStatus(protocolo.getStatus());
            if(!protocolo.isAprovado()) {
                File f = new File(configuracaoRepository.recuperarValor( ConfiguracaoEnum.STORAGE_PATH ) + "/"+ arquivo.getNome());
                if(f.exists()){
                    try {
                        arquivo.setUrl(httpServletRequest.getContextPath() + "/arquivos/" + UriUtils.encode(arquivo.getNome(),"UTF-8"));
                    }catch(Exception e){
                        arquivo.setUrl(httpServletRequest.getContextPath() + "/arquivos/arquivo-enviado-sei");
                    }
                }else{
                    arquivo.setUrl(httpServletRequest.getContextPath() + "/arquivos/arquivo-enviado-sei");
                }
            } else {
                arquivo.setUrl(httpServletRequest.getContextPath() + "/arquivos/arquivo-enviado-sei");
            }
        });
        return ResponseEntity.ok().body(arquivosList);
    }

    @GetMapping("/arquivo-enviado-sei")
    public ModelAndView arquivoEnviadoSEI() {
        return new ModelAndView("protocolo/ArquivoJaEnviadoSEI");
    }

    @GetMapping("/temp/{nome:.*}")
    public byte[] recuperarFotoTemporaria(@PathVariable String nome) {
        return arquivoStorage.recuperarFotoTemporaria(nome);
    }
    
    @GetMapping("/logos/{nome:.*}")
    public byte[] recuperarLogo(@PathVariable String nome) {
        return arquivoStorage.recuperarLogo(nome);
    }

    @GetMapping("/{nome:.*}")
    public byte[] recuperar(@PathVariable String nome) {
        return arquivoStorage.recuperar(nome);
    }
}
