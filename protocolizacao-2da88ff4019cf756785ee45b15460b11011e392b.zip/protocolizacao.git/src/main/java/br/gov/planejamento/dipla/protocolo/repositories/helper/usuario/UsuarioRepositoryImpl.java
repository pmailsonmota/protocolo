package br.gov.planejamento.dipla.protocolo.repositories.helper.usuario;

import br.gov.planejamento.dipla.protocolo.entities.Grupo;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.Criteria;
import org.hibernate.Hibernate;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.entities.UsuarioBrasilCidadao;
import br.gov.planejamento.dipla.protocolo.entities.UsuarioGrupo;
import br.gov.planejamento.dipla.protocolo.repositories.filter.UsuarioFilter;
import br.gov.planejamento.dipla.protocolo.repositories.paginacao.PaginacaoUtil;
import java.util.Optional;
import org.hibernate.sql.JoinType;

/**
 *
 * @author Leonardo Dias
 */
public class UsuarioRepositoryImpl implements UsuarioRepositoryQueries {

    @PersistenceContext
    private EntityManager manager;

    @Autowired
    private PaginacaoUtil paginacaoUtil;

    @Override
    public Optional<Usuario> porEmailEAtivo(String email) {
        return manager.createQuery("from Usuario where lower(email) = lower(:email) and ativo = true", Usuario.class).setParameter("email", email).getResultList().stream().findFirst();
    }

    @Override
    public List<String> permissoes(Usuario usuario) {
        return manager.createQuery("select distinct p.nome from Usuario u inner join u.grupos g inner join g.permissoes p where u = :usuario", String.class)
                .setParameter("usuario", usuario).getResultList();
    }

    @SuppressWarnings("unchecked")
    @Transactional(readOnly = true)
    @Override
    public Page<Usuario> filtrar(UsuarioFilter filtro, Pageable pageable) {
        Criteria criteria = manager.unwrap(Session.class).createCriteria(Usuario.class);

        paginacaoUtil.preparaPaginacao(criteria, pageable);
        adicionarFiltro(filtro, criteria);
        criteria.addOrder(Order.asc("nome"));

        List<Usuario> filtrados = criteria.list();
        filtrados.forEach(u -> Hibernate.initialize(u.getGrupos()));
        return new PageImpl<>(filtrados, pageable, total(filtro));
    }

    @Transactional(readOnly = true)
    @Override
    public Usuario buscarComGrupos(Long codigo) {
        Criteria criteria = manager.unwrap(Session.class).createCriteria(Usuario.class);
        criteria.createAlias("grupos", "g", JoinType.LEFT_OUTER_JOIN);
        criteria.add(Restrictions.eq("codigo", codigo));
        criteria.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY);
        return (Usuario) criteria.uniqueResult();
    }

    @Transactional(readOnly = true)
    @Override
    public Optional<UsuarioBrasilCidadao> buscarBrasilCidadao(String cpf) {
        Optional<UsuarioBrasilCidadao> userBrasilCidadao = manager.createQuery("from UsuarioBrasilCidadao where cpf = :cpf", UsuarioBrasilCidadao.class).setParameter("cpf", cpf).getResultList().stream().findFirst();
        return userBrasilCidadao;
    }

    @Transactional(readOnly = true)
    @Override
    public Boolean verificarUsuarioBrasilCidadao(Long usuario) {
        Optional<Long> id = manager.createQuery("select codigo from UsuarioBrasilCidadao where usuario.codigo = :usuario", Long.class).setParameter("usuario", usuario).getResultList().stream().findFirst();
        return id.isPresent();
    }

    private Long total(UsuarioFilter filtro) {
        Criteria criteria = manager.unwrap(Session.class).createCriteria(Usuario.class);
        adicionarFiltro(filtro, criteria);
        criteria.setProjection(Projections.rowCount());
        return (Long) criteria.uniqueResult();
    }

    private void adicionarFiltro(UsuarioFilter filtro, Criteria criteria) {
        if (filtro != null) {

            if (!StringUtils.isEmpty(filtro.getNome())) {
                criteria.add(Restrictions.or(
                        Restrictions.ilike("nome", filtro.getNome(), MatchMode.ANYWHERE),
                        Restrictions.ilike("nome_social", filtro.getNome(), MatchMode.ANYWHERE)));

            }

            if (!StringUtils.isEmpty(filtro.getEmail())) {
                criteria.add(Restrictions.ilike("email", filtro.getEmail(), MatchMode.ANYWHERE));
            }

            if (filtro.getGrupos() != null && !filtro.getGrupos().isEmpty()) {
                List<Criterion> subqueries = new ArrayList<>();
                for (Long codigoGrupo : filtro.getGrupos().stream().mapToLong(Grupo::getCodigo).toArray()) {
                    DetachedCriteria dc = DetachedCriteria.forClass(UsuarioGrupo.class);
                    dc.add(Restrictions.eq("id.grupo.codigo", codigoGrupo));
                    dc.setProjection(Projections.property("id.usuario"));

                    subqueries.add(Subqueries.propertyIn("codigo", dc));
                }

                Criterion[] criterions = new Criterion[subqueries.size()];
                criteria.add(Restrictions.and(subqueries.toArray(criterions)));
            }
        }
    }
}
