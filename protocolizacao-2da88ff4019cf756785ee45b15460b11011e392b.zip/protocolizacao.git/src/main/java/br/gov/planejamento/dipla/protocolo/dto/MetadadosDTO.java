package br.gov.planejamento.dipla.protocolo.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.Column;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

import br.gov.planejamento.dipla.protocolo.entities.Configuracao;

/**
 * Created by dario on 29/09/17.
 */
@Getter
@Setter
public class MetadadosDTO {
    private String status;
    //private String observacao;
    
    private String nome;

    private String valor;
}
