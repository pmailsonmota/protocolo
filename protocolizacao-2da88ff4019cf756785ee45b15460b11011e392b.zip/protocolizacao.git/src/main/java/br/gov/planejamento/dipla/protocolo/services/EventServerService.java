package br.gov.planejamento.dipla.protocolo.services;

/**
 * Created by dario on 23/03/18.
 */

import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

@Service
public class EventServerService extends SseEmitter {

    public EventServerService() {
    }
}
