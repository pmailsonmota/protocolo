/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.services;

import br.gov.planejamento.dipla.protocolo.entities.Configuracao;
import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEmail;
import br.gov.planejamento.dipla.protocolo.entities.TiposDocumento;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoEmailRepository;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.TiposDocumentoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

/**
 *
 * @author leonardo
 */
@Service
public class ConfiguracaoEmailService {

    @Autowired
    private ConfiguracaoEmailRepository configuracaoEmailRepository;
    
    public void salvar(ConfiguracaoEmail configuracaoEmail) {
        Optional<ConfiguracaoEmail> configuracaoOptional = configuracaoEmailRepository.findByNome(configuracaoEmail.getNome());
        if (configuracaoOptional.isPresent()) {
        	configuracaoEmailRepository.delete(configuracaoOptional.get());
        }
        configuracaoEmailRepository.save(configuracaoEmail);
    }

    @Transactional
    public void editar(ConfiguracaoEmail configuracaoEmail) {
    	Optional<ConfiguracaoEmail> configuracaoEmailSave = configuracaoEmailRepository.findByCodigo(configuracaoEmail.getCodigo());
    	configuracaoEmailSave.get().setValor(configuracaoEmail.getValor());
    	configuracaoEmailRepository.save(configuracaoEmailSave.get());
    }
    
    public void excluir(ConfiguracaoEmail configuracaoEmail) {
    	configuracaoEmailRepository.delete(configuracaoEmail);
    }
}
