package br.gov.planejamento.dipla.protocolo.dto;

public class TesteRetornoBrasilCidadaoDto {

    private String code;
	private String state;
    private String dados;
    
    public TesteRetornoBrasilCidadaoDto(String code,String state,String dados){
    	this.code = code;
    	this.state = state;
    	this.state = dados;
    }
    public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getDados() {
		return dados;
	}
	public void setDados(String dados) {
		this.state = dados;
	}

}
