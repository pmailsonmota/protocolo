/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.controllers;

import br.gov.planejamento.dipla.protocolo.config.BrasilCidadaoConfig;
import br.gov.planejamento.dipla.protocolo.controllers.page.PageWrapper;
import br.gov.planejamento.dipla.protocolo.dto.ProtocoloFlagDTO;
import br.gov.planejamento.dipla.protocolo.entities.Grupo;
import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.repositories.GrupoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.UsuarioRepository;
import br.gov.planejamento.dipla.protocolo.repositories.filter.UsuarioFilter;
import br.gov.planejamento.dipla.protocolo.response.Response;
import br.gov.planejamento.dipla.protocolo.security.CaptchaService;
import br.gov.planejamento.dipla.protocolo.security.UsuarioSistema;
import br.gov.planejamento.dipla.protocolo.services.AutoCadastroService;
import br.gov.planejamento.dipla.protocolo.services.CadastroUsuarioService;
import br.gov.planejamento.dipla.protocolo.services.StatusUsuario;
import br.gov.planejamento.dipla.protocolo.services.exeptions.EmailUsuarioJaCadastradoException;
import br.gov.planejamento.dipla.protocolo.services.exeptions.ReCaptchaUnavailableException;
import br.gov.planejamento.dipla.protocolo.services.exeptions.SenhaObrigatoriaUsuarioException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.websocket.server.PathParam;
import java.util.List;
/**
 *
 * @author leonardo
 */
@Controller
@RequestMapping("/usuarios")
public class UsuarioController {

	
	@Autowired
	private CaptchaService captchaService;
	
	@Autowired
	private BrasilCidadaoConfig brasilCidadaoOpenIdConnectConfig;
	
    @Autowired
    private CadastroUsuarioService cadastroUsuarioService;

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private GrupoRepository grupoRepository;

    @Autowired
    private AutoCadastroService autoCadastroService;

    @GetMapping("/auto-cadastro")
    public ModelAndView autoCadastro(Usuario usuario) {
        ModelAndView mv = new ModelAndView("/usuario/NovoUsuario");
        return mv;
    }

    @GetMapping("/novo")
    public ModelAndView novo(Usuario usuario) {
        ModelAndView mv = new ModelAndView("/usuario/CadastroUsuario");
        List<Grupo> grupos = grupoRepository.findAll();
        if(!usuario.isNovo()) {
	        List<String> permissoes = usuarioRepository.permissoes(usuario);
	        if (permissoes.contains("ROLE_BRASILCIDADAO")){
	        	grupos.remove(grupoRepository.findOne(2L));
	        }else {
	        	grupos.remove(grupoRepository.findOne(3L));
	        }
        }else {
        	grupos.remove(grupoRepository.findOne(3L));
        }
        mv.addObject("grupos", grupos);
        return mv;
    }

    @GetMapping("/esqueci-senha")
    public ModelAndView esqueciSenha(Usuario usuario) {
        ModelAndView mv = new ModelAndView("/usuario/EsqueciSenha");
        return mv;
    }

    @PostMapping("/esqueci-senha")
    public ModelAndView enviarSenhaPorEmail(Usuario usuario, BindingResult result, RedirectAttributes attributes,HttpServletRequest httpServletRequest) {
    	final String response = httpServletRequest.getParameter("g-recaptcha-response");
    	try {
    		captchaService.processResponse(response);
            cadastroUsuarioService.reiniciarSenha(usuario);
            attributes.addFlashAttribute("mensagem", "Foi enviado um email para " + usuario.getEmail() + " com a nova senha de acesso.");
            return new ModelAndView("redirect:/usuarios/esqueci-senha");
        }catch (ReCaptchaUnavailableException e) {
        	ModelAndView mv = new ModelAndView("/usuario/EsqueciSenha");
        	mv.addObject("erroCaptch",true);
        	mv.addObject("erroCaptchMsg", e.getMessage());
        	mv.addObject("usuario",usuario);
        	return mv;
        }catch (Exception e) {
            result.rejectValue("email", e.getMessage(), e.getMessage());
            return esqueciSenha(usuario);
        }
    }

    @PostMapping("/auto-cadastro")
    public ModelAndView salvarAutoCadastro(@Valid Usuario usuario, BindingResult result, RedirectAttributes attributes, HttpServletRequest httpServletRequest) {
        if (result.hasErrors()) {
            return autoCadastro(usuario);
        }
        final String response = httpServletRequest.getParameter("g-recaptcha-response");
        try {
        	captchaService.processResponse(response);
            usuario.setUrlConfirmacaoCadastro(httpServletRequest.getRequestURL().toString());
            autoCadastroService.salvar(usuario);
            attributes.addFlashAttribute("mensagem", "Cadastro realizado com sucesso.");
        } catch (EmailUsuarioJaCadastradoException e) {
            result.rejectValue("email", e.getMessage(), e.getMessage());
            return autoCadastro(usuario);
        } catch (SenhaObrigatoriaUsuarioException e) {
            result.rejectValue("senha", e.getMessage(), e.getMessage());
            return autoCadastro(usuario);
        } catch (ReCaptchaUnavailableException e) {
        	ModelAndView mv = new ModelAndView("/usuario/NovoUsuario");
        	mv.addObject("erroCaptch",true);
        	mv.addObject("erroCaptchMsg", e.getMessage());
        	mv.addObject("usuario",usuario);
        	return mv;
        }
        return new ModelAndView("redirect:/usuarios/auto-cadastro");
    }
    
    @GetMapping("/auto-brasil-cidadao/{hasBrasilCidadao}/{hasEmail}")
    public ModelAndView confirmarConsiliacaoBrasil(
    		@PathVariable("hasBrasilCidadao") String hashBrasilCidadao,
    		@PathVariable("hasEmail") String hashEmail) {
    	autoCadastroService.confirmarConciliacao(hashBrasilCidadao,hashEmail);
    	ModelAndView mv = new ModelAndView("/fragments/ConfirmacaoConsiliacaoUsuario");
    	mv.addObject("urlLogin", brasilCidadaoOpenIdConnectConfig.gerarUrlAutorizar());
        return mv;
    }
    
    @GetMapping("/auto-desbloqueio/{hashUser}")
    public ModelAndView confirmarConsiliacaoBrasil(
    		@PathVariable("hashUser") String hashUser) {
    	autoCadastroService.confirmarDesbloqueio(hashUser);
    	ModelAndView mv = new ModelAndView("/fragments/ConfirmacaoDesbloqueioUsuario");
    	mv.addObject("urlLogin", brasilCidadaoOpenIdConnectConfig.gerarUrlAutorizar());
        return mv;
    }

    @GetMapping("/auto-cadastro/{hashUsuario}")
    public ModelAndView confirmarCadastro(@PathVariable("hashUsuario") String hashUsuario) {
        autoCadastroService.confirmarCadastro(hashUsuario);
        return new ModelAndView("/fragments/ConfirmacaoCadastroSucesso");
    }

    @PostMapping({"/novo", "{\\d+}"})
    public ModelAndView salvar(@Valid Usuario usuario, BindingResult result, RedirectAttributes attributes) {
        if (result.hasErrors()) {
            return novo(usuario);
        }

        try {
            cadastroUsuarioService.salvar(usuario);
        } catch (EmailUsuarioJaCadastradoException e) {
            result.rejectValue("email", e.getMessage(), e.getMessage());
            return novo(usuario);
        } catch (SenhaObrigatoriaUsuarioException e) {
            result.rejectValue("senha", e.getMessage(), e.getMessage());
            return novo(usuario);
        }

        attributes.addFlashAttribute("mensagem", "Usuário salvo com sucesso");
        return new ModelAndView("redirect:/usuarios/novo");
    }

    @GetMapping("/{codigo}")
    public ModelAndView editar(@PathVariable Long codigo) {
        Usuario usuario = usuarioRepository.buscarComGrupos(codigo);
        ModelAndView mv = novo(usuario);
        mv.addObject(usuario);
        return mv;
    }

    @GetMapping
    public ModelAndView pesquisar(UsuarioFilter usuarioFilter, @PageableDefault(size = 10) Pageable pageable, HttpServletRequest httpServletRequest) {
        ModelAndView mv = new ModelAndView("/usuario/PesquisaUsuarios");
        mv.addObject("grupos", grupoRepository.findAll());

        PageWrapper<Usuario> paginaWrapper = new PageWrapper<>(usuarioRepository.filtrar(usuarioFilter, pageable), httpServletRequest);
        mv.addObject("pagina", paginaWrapper);
        return mv;
    }

    @PutMapping("/status")
    @ResponseStatus(HttpStatus.OK)
    public void atualizarStatus(@RequestParam("codigos[]") Long[] codigos, @RequestParam("status") StatusUsuario statusUsuario) {
        cadastroUsuarioService.alterarStatus(codigos, statusUsuario);
    }

    @DeleteMapping("/{codigo}")
    public @ResponseBody
    ResponseEntity<?> excluir(@PathParam("codigo") Usuario usuario) {
    	Response<String> response = new Response<String>();
    	try {    	
        	cadastroUsuarioService.excluir(usuario);
        }catch(Exception e) {
        	response.getErrors().add("Erro usuário possui registros no banco, que impedem exclusão do usuário.");
            return ResponseEntity.badRequest().body(response);
        }
        return ResponseEntity.ok().build();
    }

    @GetMapping("/perfil")
    public ModelAndView perfil(@AuthenticationPrincipal UsuarioSistema usuarioSistema) {
        ModelAndView mv = new ModelAndView("/usuario/PerfilUsuario");
        mv.addObject("usuario", usuarioRepository.findOne(usuarioSistema.getUsuario().getCodigo()));
        return mv;
    }

    @PostMapping("/perfil")
    public ModelAndView atualizarPerfil(@Valid Usuario usuario, BindingResult result, RedirectAttributes attributes, @AuthenticationPrincipal UsuarioSistema usuarioSistema) {
        if (result.hasErrors()) {
            return  new ModelAndView("/usuario/PerfilUsuario");
        }
        try {
            Usuario usuarioGrupo = usuarioRepository.buscarComGrupos(usuario.getCodigo());
            usuario.setGrupos(usuarioGrupo.getGrupos());
            cadastroUsuarioService.salvar(usuario);
        } catch (EmailUsuarioJaCadastradoException e) {
            result.rejectValue("email", e.getMessage(), e.getMessage());
            return novo(usuario);
        } catch (SenhaObrigatoriaUsuarioException e) {
            result.rejectValue("senha", e.getMessage(), e.getMessage());
            return novo(usuario);
        }

        attributes.addFlashAttribute("mensagem", "Perfil atualizado com sucesso. Para que as modificações sejam aplicadas favor logar novamente no sistema.");
        return new ModelAndView("redirect:/usuarios/perfil");
    }

}
