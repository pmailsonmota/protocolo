package br.gov.planejamento.dipla.protocolo.repositories;

import br.gov.planejamento.dipla.protocolo.entities.Classificacao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Leonardo Dias
 */
@Repository
public interface ClassificacaoRepository extends JpaRepository<Classificacao, Long>{
	public Optional<Classificacao> findByNome(String nome);
}
