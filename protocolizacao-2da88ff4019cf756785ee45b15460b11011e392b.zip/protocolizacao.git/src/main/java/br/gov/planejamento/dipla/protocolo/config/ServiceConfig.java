package br.gov.planejamento.dipla.protocolo.config;

import br.gov.planejamento.dipla.protocolo.entities.ConfiguracaoEnum;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoRepository;
import br.gov.planejamento.dipla.protocolo.storage.ArquivoStorage;
import br.gov.planejamento.dipla.protocolo.storage.local.ArquivoStorageLocal;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static java.nio.file.FileSystems.getDefault;

/**
 *
 * @author Leonardo Dias
 */
@Configuration
//@PropertySource(value = {"classpath:/protocolo-storage.properties"})

public class ServiceConfig {

	@Autowired
    private ConfiguracaoRepository configuracaoRepository;

    @Bean
    public ArquivoStorage arquivoStorage() {
        Path path;
        if(StringUtils.isEmpty(configuracaoRepository.recuperarValor(ConfiguracaoEnum.STORAGE_PATH))) {
            path = getDefault().getPath(System.getenv("HOME"));
        } else {
            path = getDefault().getPath(configuracaoRepository.recuperarValor(ConfiguracaoEnum.STORAGE_PATH));
        }

        return new ArquivoStorageLocal(path);
    }

}
