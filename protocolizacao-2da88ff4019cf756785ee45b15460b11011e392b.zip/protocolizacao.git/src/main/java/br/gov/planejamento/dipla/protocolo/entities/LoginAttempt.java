package br.gov.planejamento.dipla.protocolo.entities;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.Date;

@Entity
@Getter
@Setter
@EqualsAndHashCode(of = {"id"})
@Table(name = "login_attempt", schema = "protocolo")
public class LoginAttempt {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
	
	@Column(name = "key")
	private String key;
	
	@Column(name = "amount", insertable = false)
	private Integer amount;
	
	@Column(name = "reset_at", insertable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date resetAt;

	@Column(name = "created_at", insertable = false, updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date createdAt;

	@Column(name = "updated_at", insertable = false, updatable = false)
	@Temporal(TemporalType.TIMESTAMP)
	private Date updatedAt;
	

}
