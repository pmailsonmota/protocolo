/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.repositories.helper.protocolo;

import br.gov.planejamento.dipla.protocolo.entities.Protocolo;
import br.gov.planejamento.dipla.protocolo.entities.StatusEnum;
import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.repositories.filter.ProtocoloFilter;
import br.gov.planejamento.dipla.protocolo.repositories.paginacao.PaginacaoUtil;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Date;

/**
 * @author leonardo
 */
public class ProtocoloRepositoryImpl implements ProtocoloRepositoryQueries {

    @PersistenceContext
    private EntityManager manager;

    @Autowired
    private PaginacaoUtil paginacaoUtil;

    @Override
    public Page<Protocolo> filtrar(ProtocoloFilter protocoloFilter, Pageable pageable) {
        Criteria criteria = manager.unwrap(Session.class).createCriteria(Protocolo.class);

        paginacaoUtil.preparaPaginacao(criteria, pageable);

        adicionarFiltro(protocoloFilter, criteria);

        return new PageImpl<>(criteria.list(), pageable, total(protocoloFilter));
    }

    @Override
    public Page<Protocolo> filtrarMeusProtocolos(Usuario usuario, ProtocoloFilter protocoloFilter, Pageable pageable) {
        Criteria criteria = manager.unwrap(Session.class).createCriteria(Protocolo.class);

        paginacaoUtil.preparaPaginacao(criteria, pageable);

        adicionarFiltroMeusProtocolos(usuario, protocoloFilter, criteria);

        return new PageImpl<>(criteria.list(), pageable, totalMeusProtocolos(usuario, protocoloFilter));
    }

    private Long total(ProtocoloFilter protocoloFilter) {
        Criteria criteria = manager.unwrap(Session.class).createCriteria(Protocolo.class);
        adicionarFiltro(protocoloFilter, criteria);
        criteria.setProjection(Projections.rowCount());
        return (Long) criteria.uniqueResult();
    }

    private Long totalMeusProtocolos(Usuario usuario, ProtocoloFilter protocoloFilter) {
        Criteria criteria = manager.unwrap(Session.class).createCriteria(Protocolo.class);
        criteria.add(Restrictions.eq("usuario", usuario));
        adicionarFiltro(protocoloFilter, criteria);
        criteria.setProjection(Projections.rowCount());
        return (Long) criteria.uniqueResult();
    }

    private void adicionarFiltro(ProtocoloFilter filtro, Criteria criteria) {
        criteria.createAlias("usuario", "u");
        if (filtro != null) {
            if (filtro.getPesquisa() != null) {
                criteria.add(Restrictions.or(
                        Restrictions.ilike("numero", filtro.getPesquisa(), MatchMode.ANYWHERE),
                        Restrictions.ilike("nupe", filtro.getPesquisa(), MatchMode.ANYWHERE),
                        Restrictions.ilike("u.nome", filtro.getPesquisa(), MatchMode.ANYWHERE),
                        Restrictions.ilike("u.email", filtro.getPesquisa(), MatchMode.ANYWHERE),
                        Restrictions.ilike("u.nome_social", filtro.getPesquisa(), MatchMode.ANYWHERE)
                ));
            }

            if (filtro.getDesde() != null) {
                LocalDateTime ldt = LocalDateTime.of(filtro.getDesde(), LocalTime.of(0, 0));
                Date desde = Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());
                criteria.add(Restrictions.ge("dataHora", desde));
            }

            if (filtro.getAte() != null) {
                LocalDateTime ldt = LocalDateTime.of(filtro.getAte(), LocalTime.of(23, 59));
                Date ate = Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());
                criteria.add(Restrictions.le("dataHora", ate));
            }

            if (filtro.getStatus() != null) {
                if (filtro.getStatus().equals(StatusEnum.APROVADO)) {
                    criteria.add(
                            Restrictions.or(
                                    Restrictions.eq("status", StatusEnum.APROVADO),
                                    Restrictions.eq("status", StatusEnum.PROCESSANDO)
                            )
                    );
                } else {
                    criteria.add(Restrictions.eq("status", filtro.getStatus()));
                }
            }
        }
    }

    private void adicionarFiltroMeusProtocolos(Usuario usuario, ProtocoloFilter filtro, Criteria criteria) {
        criteria.createAlias("usuario", "u");
        criteria.add(Restrictions.eq("usuario", usuario));
        if (filtro != null) {
            if (filtro.getPesquisa() != null) {
                criteria.add(Restrictions.or(
                        Restrictions.ilike("numero", filtro.getPesquisa(), MatchMode.ANYWHERE),
                        Restrictions.ilike("nupe", filtro.getPesquisa(), MatchMode.ANYWHERE)
                ));
            }

            if (filtro.getDesde() != null) {
                LocalDateTime ldt = LocalDateTime.of(filtro.getDesde(), LocalTime.of(0, 0));
                Date desde = Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());
                criteria.add(Restrictions.ge("dataHora", desde));
            }

            if (filtro.getAte() != null) {
                LocalDateTime ldt = LocalDateTime.of(filtro.getAte(), LocalTime.of(23, 59));
                Date ate = Date.from(ldt.atZone(ZoneId.systemDefault()).toInstant());
                criteria.add(Restrictions.le("dataHora", ate));
            }

            if (filtro.getStatus() != null) {
                criteria.add(Restrictions.eq("status", filtro.getStatus()));
            }
        }
    }
}
