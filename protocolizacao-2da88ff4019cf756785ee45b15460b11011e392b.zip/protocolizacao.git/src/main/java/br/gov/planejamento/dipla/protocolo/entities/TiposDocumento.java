/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.entities;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.validator.constraints.NotBlank;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

/**
 *
 * @author leonardo
 */
@Entity
@Getter
@Setter
@EqualsAndHashCode(of = {"codigo"})
@Table(name = "tipo_documento", schema = "protocolo")
public class TiposDocumento implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    //@NotNull(message = "O campo código é de preenchimento obrigatório")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codigo;

    @NotBlank(message = "O campo descrição é de preenchimento obrigatório")
    private String descricao;

    @NotBlank(message = "O campo código é de preenchimento obrigatório")
    @Column(name = "codigo_sei")
    private String codigoSei;

    private Boolean ativo;
    
    public boolean isNovo() {
        return codigo == codigo;
    }
}
