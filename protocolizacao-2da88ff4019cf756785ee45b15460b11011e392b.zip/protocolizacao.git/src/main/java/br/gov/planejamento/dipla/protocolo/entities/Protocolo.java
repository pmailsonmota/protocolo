package br.gov.planejamento.dipla.protocolo.entities;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.SafeHtml;

import javax.persistence.*;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.persistence.Transient;
import java.util.Optional;

/**
 * @author Leonardo Dias
 */
@Getter
@Setter
@EqualsAndHashCode(of = {"codigo"})
@Entity
@DynamicUpdate
@Table(name = "protocolo", schema = "protocolo")
public class Protocolo implements Serializable {

    @Transient
    private static final String padraoURL = "https://protocolointegrado.gov.br/protocolo/documento/detalhes_documento.jsf?protocolo=";

    private String observacao;

    private String erroWs;

    @Transient
    private String linkNup;
    @Transient
    private static final String urlNup = "";
 
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codigo;

    private String numero;

    @Column(name = "data_hora")
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date dataHora;

    @ManyToOne
    @JoinColumn(name = "codigo_usuario")
    private Usuario usuario;

    @Enumerated(EnumType.STRING)
    private StatusEnum status = StatusEnum.PENDENTE;

    @Email(message = "Formato do e-mail 1 está inválido.")
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE)
    private String email1;

    @Email(message = "Formato do e-mail 2 está inválido.")
    @SafeHtml(whitelistType = SafeHtml.WhiteListType.NONE)
    private String email2;

    @Column(name = "observacao", nullable = true)
    public String getObservacao() {
        return observacao;
    }

    @Column(name = "erro_ws", nullable = true)
    public String erroWs() {
        return erroWs;
    }

    @Transient
    public Optional<String> getObservacaoOpt() {
        return Optional.ofNullable(observacao);
    }

    public void setObservaco(String observacao) {
        this.observacao = observacao;
    }

    @Column(name = "data_envio")
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date dataEnvio;

    private String nupe;

    @OneToMany(mappedBy = "protocolo", cascade = CascadeType.ALL)
    private List<Arquivos> arquivosList = new ArrayList<>();

    @Column(name = "nr_protocolo_anterior")
    private String numeroProtocoloAnterior;

    private Long idUnidade;

    @Transient
    private String uuid;
    
    @Transient
    private String interessado;

    @Transient
    private Arquivos arquivo = new Arquivos();

    @Column(name = "linksei", nullable = true)
    private String linkSEI;

    @Transient
    private String possuiProtocoloAnterior;

    @PrePersist
    private void prePersist() {
        status = StatusEnum.PENDENTE;
    }

    public String getDataHoraFormatada() {
        return new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(dataHora);
    }

    public String getDataFormatada() {
        return new SimpleDateFormat("dd/MM/yyyy").format(dataHora);
    }

    public String getDataEnvioFormatada() {
        if (dataEnvio != null) {
            return new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(dataEnvio);
        }
        return "";
    }

    public boolean isAprovado() {
        return (StatusEnum.APROVADO.equals(status)||StatusEnum.APROVADO_MANUALMENTE.equals(status));
    }

    @Override
    public String toString() {
        StringBuilder retorno = new StringBuilder();
        retorno.append("Nº Protocolo Provisório: " + numero + "\n");
        retorno.append("Data e Hora: " + getDataHoraFormatada() + "\n");
        retorno.append("Nome: " + usuario.getNome() + "\n");
        retorno.append("Telefone: " + usuario.getTelefone() + "\n");
        retorno.append("E-mail: " + usuario.getEmail() + "\n");
        return retorno.toString();
    }

    public String getLinkNup() {
        if (nupe != null
                && !nupe.isEmpty()
                && linkNup == null) {
            this.linkNup = padraoURL + nupe.replace("-", "").replace(".", "").replace("/", "");
        }
        return this.linkNup;
    }

    
    public boolean isExibirLinkNup() {
        return !"Processando...".equals(nupe);
    }
    
	public String toLog() {
		return "Protocolo [observacao=" + observacao + ", erroWs=" + erroWs + ", linkNup=" + linkNup + ", codigo="
				+ codigo + ", numero=" + numero + ", dataHora=" + dataHora + ", usuario=" + usuario + ", status="
				+ status + ", email1=" + email1 + ", email2=" + email2 + ", dataEnvio=" + dataEnvio + ", nupe=" + nupe
				+ ", arquivosList=" + arquivosList + ", numeroProtocoloAnterior=" + numeroProtocoloAnterior
				+ ", idUnidade=" + idUnidade + ", uuid=" + uuid + ", interessado=" + interessado + ", arquivo="
				+ arquivo + ", linkSEI=" + linkSEI + ", possuiProtocoloAnterior=" + possuiProtocoloAnterior + "]";
	}
}