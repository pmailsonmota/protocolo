/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.entities;

/**
 *
 * @author leonardo
 */
public enum ConfiguracaoEnum {
	//server-email
	SMTP_SERVER, 
	SMTP_PORT, 
	MAIL_FROM,
	EMAIL_RESPONSAVEL,
	//sei
	URL_ENDPOINT,
	ASSUNTO_CODIGO_ESTRUTURADO,
	PROCEDIMENTO_ESPECIFICADO,
	PROCEDIMENTO_NIVEL_ACESSO,
	PROCEDIMENTO_ID_TIPO_PROCEDIMENTO,
	DOCUMENTO_TIPO,
	DOCUMENTO_ID_SERIE,
	DOCUMENTO_NIVEL_ACESSO,
	SIGLA_SISTEMA,
	IDENTIFICACAO_SERVICO,
	ID_UNIDADE,
	//storage
	STORAGE_PATH,
	//brasil-cidadao
	URL_AUTORIZAR,
	URL_TOKEN,
	URL_DADOS_USUARIO,
	CLIENT_ID,
	SCOPE,
	REDIRECT_URI,
	CLIENT_SECRET,
	ESCOPO,
	URL_BRASIL_CIDADAO,
	URL_PRIMEIRO_ACESSO,
	//captcha
	CAPTCHA_SITE_KEY,
	CAPTCHA_SECRET_KEY;
	
}
