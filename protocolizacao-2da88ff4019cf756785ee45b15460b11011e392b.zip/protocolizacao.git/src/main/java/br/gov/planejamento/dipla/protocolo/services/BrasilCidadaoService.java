/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.services;

import br.gov.planejamento.dipla.protocolo.config.BrasilCidadaoConfig;
import br.gov.planejamento.dipla.protocolo.dto.TokenRetornoDto;
import br.gov.planejamento.dipla.protocolo.dto.UsuarioBrasilCidadaoDto;
import br.gov.planejamento.dipla.protocolo.entities.Configuracao;
import br.gov.planejamento.dipla.protocolo.entities.TiposDocumento;
import br.gov.planejamento.dipla.protocolo.entities.Usuario;
import br.gov.planejamento.dipla.protocolo.entities.UsuarioBrasilCidadao;
import br.gov.planejamento.dipla.protocolo.repositories.ConfiguracaoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.TiposDocumentoRepository;
import br.gov.planejamento.dipla.protocolo.repositories.UsuarioRepository;
import br.gov.planejamento.dipla.protocolo.security.BrasilCidadaoUserDetails;
import br.gov.planejamento.dipla.protocolo.security.UsuarioSistema;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.nio.charset.Charset;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 *
 * @author leonardo
 */
@Service
public class BrasilCidadaoService {
    
    private String msgErro =null;
	
    @Autowired
    private UsuarioRepository usuarioRepository;
    
	@Autowired
	private BrasilCidadaoConfig brasilCidadaoOpenIdConnectConfig;
	
	
	public UsuarioBrasilCidadaoDto autenticarBrasilCidadao(String code) throws Exception{
			UsuarioBrasilCidadaoDto usuarioretorno = new UsuarioBrasilCidadaoDto();

			RestTemplate restTemplate = new RestTemplate();
			restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));
			
	      	HttpEntity<String> entityToken = new HttpEntity<String>(brasilCidadaoOpenIdConnectConfig.gerarRequisicaoAtributo(code), brasilCidadaoOpenIdConnectConfig.gerarRequisicaoHeader());
	    	
	      	//Enviando autorização com code
	      	
	      	ResponseEntity<String> respEntToken = restTemplate.exchange(brasilCidadaoOpenIdConnectConfig.gerarUrlToken(), HttpMethod.POST, entityToken, String.class);
			
	      	if(respEntToken.getStatusCodeValue()!=200) {
	      		throw new Exception("Erro no recebimento do token");
	      	}
	      	
	      	//Capturando token
	      	TokenRetornoDto retorno = new ObjectMapper().readValue(respEntToken.getBody().toString(), TokenRetornoDto.class);
			
			//Enviando token
	      	ResponseEntity<String> respEntUsuario = restTemplate.exchange(brasilCidadaoOpenIdConnectConfig.gerarUrlDadosUsuarios(retorno.getAccess_token()),HttpMethod.GET,null,String.class);
			
	      	if(respEntUsuario.getStatusCodeValue()!=200) {
	      		throw new Exception("Erro no recebimento dos dados do usuario");
	      	}
			
			//Capturando dados usuario
			usuarioretorno = new ObjectMapper().readValue(respEntUsuario.getBody().toString() , UsuarioBrasilCidadaoDto.class);
			usuarioretorno.setToken(retorno.getAccess_token());
			
			return usuarioretorno;
	}
	
	public UsernamePasswordAuthenticationToken autenticarProtocolo(UsuarioBrasilCidadaoDto usuarioretorno) throws Exception {
    	Optional<UsuarioBrasilCidadao> usuarioBrasilCidadao = usuarioRepository.buscarBrasilCidadao(usuarioretorno.getCpf());
    	
    	BrasilCidadaoUserDetails userDetails = new BrasilCidadaoUserDetails(usuarioBrasilCidadao.get().getUsuario().getEmail());
		Optional<Usuario> usuario = usuarioRepository.findByEmail(usuarioBrasilCidadao.get().getUsuario().getEmail());
		
		
        List<String> permissoes = usuarioRepository.permissoes(usuario.get());
        usuario.get().setTemPerfilBrasilCidadao(true);
		
		UsuarioSistema usuarioSistema = new UsuarioSistema(usuario.get(),getPermissoes(),true);
		
		UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(
			usuarioSistema,
			usuarioretorno.getToken(),getPermissoes());
        return auth;
	}
	
	private Collection<? extends GrantedAuthority> getPermissoes() {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
        authorities.add(new SimpleGrantedAuthority("ROLE_BRASILCIDADAO"));
        return authorities;
    }

}
