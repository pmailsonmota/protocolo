/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.gov.planejamento.dipla.protocolo.entities;

/**
 *
 * @author leonardo
 */
public enum EmailEnum {

	EMAIL_CONTEUDO_CADASTRO,
	EMAIL_CONTEUDO_CONSOLIDACAO,
	EMAIL_CONTEUDO_ERRO_SEI,
	EMAIL_CONTEUDO_ESQUECI_SENHA,
	EMAIL_CONTEUDO_PROTOCOLO,
	EMAIL_CONTEUDO_NEGADO,
	EMAIL_CONTEUDO_RECEBIMENTO_SEI,
	EMAIL_CONTEUDO_DESBLOQUEIO,
	EMAIL_CABECALHO,
	EMAIL_RODAPE,
	EMAIL_MSG_CORPO,
	EMAIL_MSG_TITULO;	
	
}
