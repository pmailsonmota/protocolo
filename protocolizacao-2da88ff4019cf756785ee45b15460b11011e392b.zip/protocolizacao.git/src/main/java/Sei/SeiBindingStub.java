/**
 * SeiBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package Sei;

public class SeiBindingStub extends org.apache.axis.client.Stub implements SeiPortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[3];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("gerarProcedimento");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SiglaSistema"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "IdentificacaoServico"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "IdUnidade"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "Procedimento"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("Sei", "Procedimento"), Procedimento.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "Documentos"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("Sei", "ArrayOfDocumento"), Documento[].class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "ProcedimentosRelacionados"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("Sei", "ArrayOfProcedimentoRelacionado"), String[].class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "UnidadesEnvio"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("Sei", "ArrayOfIdUnidade"), String[].class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SinManterAbertoUnidade"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SinEnviarEmailNotificacao"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "DataRetornoProgramado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "DiasRetornoProgramado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SinDiasUteisRetornoProgramado"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "IdMarcador"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "TextoMarcador"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("Sei", "RetornoGeracaoProcedimento"));
        oper.setReturnClass(RetornoGeracaoProcedimento.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "parametros"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("incluirDocumento");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SiglaSistema"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "IdentificacaoServico"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "IdUnidade"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "Documento"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("Sei", "Documento"), Documento.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("Sei", "RetornoInclusaoDocumento"));
        oper.setReturnClass(RetornoInclusaoDocumento.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "parametros"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        _operations[1] = oper;
        
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("consultarProcedimento");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SiglaSistema"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "IdentificacaoServico"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "IdUnidade"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "ProtocoloProcedimento"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SinRetornarAssuntos"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SinRetornarInteressados"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SinRetornarObservacoes"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SinRetornarAndamentoGeracao"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SinRetornarAndamentoConclusao"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SinRetornarUltimoAndamento"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SinRetornarUnidadesProcedimentoAberto"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SinRetornarProcedimentosRelacionados"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("", "SinRetornarProcedimentosAnexados"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"), java.lang.String.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("Sei", "RetornoConsultaProcedimento"));
        oper.setReturnClass(Sei.RetornoConsultaProcedimento.class);
        oper.setReturnQName(new javax.xml.namespace.QName("", "parametros"));
        oper.setStyle(org.apache.axis.constants.Style.RPC);
        oper.setUse(org.apache.axis.constants.Use.ENCODED);
        _operations[2] = oper;

    }

    public SeiBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public SeiBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public SeiBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("Sei", "Andamento");
            cachedSerQNames.add(qName);
            cls = Sei.Andamento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "AndamentoMarcador");
            cachedSerQNames.add(qName);
            cls = Sei.AndamentoMarcador.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "ArquivoExtensao");
            cachedSerQNames.add(qName);
            cls = Sei.ArquivoExtensao.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfAndamento");
            cachedSerQNames.add(qName);
            cls = Sei.Andamento[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Andamento");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfAndamentoMarcador");
            cachedSerQNames.add(qName);
            cls = Sei.AndamentoMarcador[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "AndamentoMarcador");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfArquivoExtensao");
            cachedSerQNames.add(qName);
            cls = Sei.ArquivoExtensao[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "ArquivoExtensao");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfAssinatura");
            cachedSerQNames.add(qName);
            cls = Sei.Assinatura[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Assinatura");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfAssunto");
            cachedSerQNames.add(qName);
            cls = Sei.Assunto[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Assunto");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfAtributoAndamento");
            cachedSerQNames.add(qName);
            cls = Sei.AtributoAndamento[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "AtributoAndamento");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfCampo");
            cachedSerQNames.add(qName);
            cls = Sei.Campo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Campo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfCargo");
            cachedSerQNames.add(qName);
            cls = Sei.Cargo[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Cargo");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfCidade");
            cachedSerQNames.add(qName);
            cls = Sei.Cidade[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Cidade");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfContato");
            cachedSerQNames.add(qName);
            cls = Sei.Contato[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Contato");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfDefinicaoMarcador");
            cachedSerQNames.add(qName);
            cls = Sei.DefinicaoMarcador[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "DefinicaoMarcador");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfDestinatario");
            cachedSerQNames.add(qName);
            cls = Sei.Destinatario[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Destinatario");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfDocumento");
            cachedSerQNames.add(qName);
            cls = Sei.Documento[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Documento");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfDocumentoFormatado");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfEstado");
            cachedSerQNames.add(qName);
            cls = Sei.Estado[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Estado");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfHipoteseLegal");
            cachedSerQNames.add(qName);
            cls = Sei.HipoteseLegal[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "HipoteseLegal");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfIdUnidade");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfInteressado");
            cachedSerQNames.add(qName);
            cls = Sei.Interessado[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Interessado");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfMarcador");
            cachedSerQNames.add(qName);
            cls = Sei.Marcador[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Marcador");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfObservacao");
            cachedSerQNames.add(qName);
            cls = Sei.Observacao[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Observacao");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfPais");
            cachedSerQNames.add(qName);
            cls = Sei.Pais[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Pais");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfProcedimentoRelacionado");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfProcedimentoResumido");
            cachedSerQNames.add(qName);
            cls = Sei.ProcedimentoResumido[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "ProcedimentoResumido");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfProtocoloBloco");
            cachedSerQNames.add(qName);
            cls = Sei.ProtocoloBloco[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "ProtocoloBloco");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfRetornoInclusaoDocumento");
            cachedSerQNames.add(qName);
            cls = Sei.RetornoInclusaoDocumento[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "RetornoInclusaoDocumento");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfSerie");
            cachedSerQNames.add(qName);
            cls = Sei.Serie[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Serie");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfString");
            cachedSerQNames.add(qName);
            cls = java.lang.String[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfTipoConferencia");
            cachedSerQNames.add(qName);
            cls = Sei.TipoConferencia[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "TipoConferencia");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfTipoProcedimento");
            cachedSerQNames.add(qName);
            cls = Sei.TipoProcedimento[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "TipoProcedimento");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfUnidade");
            cachedSerQNames.add(qName);
            cls = Sei.Unidade[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Unidade");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfUnidadeProcedimentoAberto");
            cachedSerQNames.add(qName);
            cls = Sei.UnidadeProcedimentoAberto[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "UnidadeProcedimentoAberto");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "ArrayOfUsuario");
            cachedSerQNames.add(qName);
            cls = Sei.Usuario[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("Sei", "Usuario");
            qName2 = null;
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("Sei", "Assinatura");
            cachedSerQNames.add(qName);
            cls = Sei.Assinatura.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Assunto");
            cachedSerQNames.add(qName);
            cls = Sei.Assunto.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "AtributoAndamento");
            cachedSerQNames.add(qName);
            cls = Sei.AtributoAndamento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Campo");
            cachedSerQNames.add(qName);
            cls = Sei.Campo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Cargo");
            cachedSerQNames.add(qName);
            cls = Sei.Cargo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Cidade");
            cachedSerQNames.add(qName);
            cls = Sei.Cidade.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Contato");
            cachedSerQNames.add(qName);
            cls = Sei.Contato.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "DefinicaoMarcador");
            cachedSerQNames.add(qName);
            cls = Sei.DefinicaoMarcador.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Destinatario");
            cachedSerQNames.add(qName);
            cls = Sei.Destinatario.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Documento");
            cachedSerQNames.add(qName);
            cls = Sei.Documento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Estado");
            cachedSerQNames.add(qName);
            cls = Sei.Estado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "HipoteseLegal");
            cachedSerQNames.add(qName);
            cls = Sei.HipoteseLegal.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Interessado");
            cachedSerQNames.add(qName);
            cls = Sei.Interessado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Marcador");
            cachedSerQNames.add(qName);
            cls = Sei.Marcador.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Observacao");
            cachedSerQNames.add(qName);
            cls = Sei.Observacao.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Pais");
            cachedSerQNames.add(qName);
            cls = Sei.Pais.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Procedimento");
            cachedSerQNames.add(qName);
            cls = Sei.Procedimento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "ProcedimentoResumido");
            cachedSerQNames.add(qName);
            cls = Sei.ProcedimentoResumido.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "ProtocoloBloco");
            cachedSerQNames.add(qName);
            cls = Sei.ProtocoloBloco.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Publicacao");
            cachedSerQNames.add(qName);
            cls = Sei.Publicacao.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "PublicacaoImprensaNacional");
            cachedSerQNames.add(qName);
            cls = Sei.PublicacaoImprensaNacional.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Remetente");
            cachedSerQNames.add(qName);
            cls = Sei.Remetente.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "RetornoConsultaBloco");
            cachedSerQNames.add(qName);
            cls = Sei.RetornoConsultaBloco.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "RetornoConsultaDocumento");
            cachedSerQNames.add(qName);
            cls = Sei.RetornoConsultaDocumento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "RetornoConsultaProcedimento");
            cachedSerQNames.add(qName);
            cls = Sei.RetornoConsultaProcedimento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "RetornoGeracaoProcedimento");
            cachedSerQNames.add(qName);
            cls = Sei.RetornoGeracaoProcedimento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "RetornoInclusaoDocumento");
            cachedSerQNames.add(qName);
            cls = Sei.RetornoInclusaoDocumento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Serie");
            cachedSerQNames.add(qName);
            cls = Sei.Serie.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "TipoConferencia");
            cachedSerQNames.add(qName);
            cls = Sei.TipoConferencia.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "TipoProcedimento");
            cachedSerQNames.add(qName);
            cls = Sei.TipoProcedimento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Unidade");
            cachedSerQNames.add(qName);
            cls = Sei.Unidade.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "UnidadeProcedimentoAberto");
            cachedSerQNames.add(qName);
            cls = Sei.UnidadeProcedimentoAberto.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("Sei", "Usuario");
            cachedSerQNames.add(qName);
            cls = Sei.Usuario.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                String key = (String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        Class cls = (Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            Class sf = (Class)
                                 cachedSerFactories.get(i);
                            Class df = (Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public RetornoGeracaoProcedimento gerarProcedimento(String siglaSistema, String identificacaoServico, String idUnidade, Procedimento procedimento, Documento[] documentos, String[] procedimentosRelacionados, String[] unidadesEnvio, String sinManterAbertoUnidade, String sinEnviarEmailNotificacao, String dataRetornoProgramado, String diasRetornoProgramado, String sinDiasUteisRetornoProgramado, String idMarcador, String textoMarcador) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("SeiAction");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("Sei", "gerarProcedimento"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        Object _resp = _call.invoke(new Object[] {siglaSistema, identificacaoServico, idUnidade, procedimento, documentos, procedimentosRelacionados, unidadesEnvio, sinManterAbertoUnidade, sinEnviarEmailNotificacao, dataRetornoProgramado, diasRetornoProgramado, sinDiasUteisRetornoProgramado, idMarcador, textoMarcador});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (RetornoGeracaoProcedimento) _resp;
            } catch (Exception _exception) {
                return (RetornoGeracaoProcedimento) org.apache.axis.utils.JavaUtils.convert(_resp, RetornoGeracaoProcedimento.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

    public RetornoInclusaoDocumento incluirDocumento(String siglaSistema, String identificacaoServico, String idUnidade, Documento documento) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("SeiAction");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("Sei", "incluirDocumento"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        Object _resp = _call.invoke(new Object[] {siglaSistema, identificacaoServico, idUnidade, documento});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (RetornoInclusaoDocumento) _resp;
            } catch (Exception _exception) {
                return (RetornoInclusaoDocumento) org.apache.axis.utils.JavaUtils.convert(_resp, RetornoInclusaoDocumento.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }
    
    public RetornoConsultaProcedimento consultarProcedimento(String siglaSistema, 
    		String identificacaoServico, 
    		String idUnidade, 
    		String protocoloProcedimento, 
    		String sinRetornarAssuntos, 
    		String sinRetornarInteressados, 
    		String sinRetornarObservacoes, 
    		String sinRetornarAndamentoGeracao, 
    		String sinRetornarAndamentoConclusao, 
    		String sinRetornarUltimoAndamento, 
    		String sinRetornarUnidadesProcedimentoAberto, 
    		String sinRetornarProcedimentosRelacionados, 
    		String sinRetornarProcedimentosAnexados) throws java.rmi.RemoteException {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("SeiAction");
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("Sei", "consultarProcedimento"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {siglaSistema, identificacaoServico, idUnidade, protocoloProcedimento, sinRetornarAssuntos, sinRetornarInteressados, sinRetornarObservacoes, sinRetornarAndamentoGeracao, sinRetornarAndamentoConclusao, sinRetornarUltimoAndamento, sinRetornarUnidadesProcedimentoAberto, sinRetornarProcedimentosRelacionados, sinRetornarProcedimentosAnexados});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (RetornoConsultaProcedimento) _resp;
            } catch (java.lang.Exception _exception) {
                return (RetornoConsultaProcedimento) org.apache.axis.utils.JavaUtils.convert(_resp, RetornoConsultaProcedimento.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
  throw axisFaultException;
}
    }

}
