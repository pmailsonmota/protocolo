/**
 * SeiPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package Sei;

public interface SeiPortType extends java.rmi.Remote {

    /**
     * Geracao de processos
     */
    public RetornoGeracaoProcedimento gerarProcedimento(String siglaSistema, String identificacaoServico, String idUnidade, Procedimento procedimento, Documento[] documentos, String[] procedimentosRelacionados, String[] unidadesEnvio, String sinManterAbertoUnidade, String sinEnviarEmailNotificacao, String dataRetornoProgramado, String diasRetornoProgramado, String sinDiasUteisRetornoProgramado, String idMarcador, String textoMarcador) throws java.rmi.RemoteException;

    /**
     * Geracao de documentos
     */
    public RetornoInclusaoDocumento incluirDocumento(String siglaSistema, String identificacaoServico, String idUnidade, Documento documento) throws java.rmi.RemoteException;
}
