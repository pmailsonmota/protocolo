package Sei;

import fi.solita.clamav.ClamAVClient;
import org.apache.commons.io.FileUtils;
import org.springframework.util.Base64Utils;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.text.Normalizer;

public class TesteIncluirDocumento {

    public static String removerCaracteresEspeciais(String string) {
        string = Normalizer.normalize(string, Normalizer.Form.NFD);
        string = string.replaceAll("[^\\p{ASCII}]", "");
        return string;
    }

    public static void main(String... a) throws Exception {
        //String string = "0.498961861934341|100|0.7975876445654828";
        /*String string = "12313|666";
        String[] parts = string.split("\\|",-1);
        String part1 = parts[0]; // 004
        String part2 = parts[1]; // 034556

        System.out.println(part2);*/

        ClamAVClient cl = new ClamAVClient("10.209.40.206", 3310);
        final byte[] reply;
        try {
            System.out.println("Tudo limpo.");
            reply = cl.scan(new FileInputStream("/home/dario/Documentos/virus.pdf"));

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        if (!ClamAVClient.isCleanReply(reply)) {
            System.out.println("Virus encontrado.");
        } else {
            System.out.println("Tudo limpo.");
        }
    }



    public static void enviar() throws Exception {
        System.out.println(removerCaracteresEspeciais("Cabeção !@#$%*()"));


//        Path path = Paths.get("/home/leonardo/Downloads/");
//        System.out.println(path.resolve("PaytoStudy_Student_Guide_HiBonjour_PT.pdf").toFile().getAbsolutePath());

//
        URL urlEndpoint = new URL("https://seitreina.nuvem.gov.br/sei/ws/SeiWS.php");
        SeiBindingStub seiBindingStub = new SeiBindingStub(urlEndpoint, null);

        Assunto assunto = new Assunto();
        assunto.setCodigoEstruturado("520.1"); //Tipo de assunto
        Assunto[] assuntos = {assunto};

        Procedimento procedimento = new Procedimento();
        procedimento.setAssuntos(assuntos);
        procedimento.setEspecificacao("Especificacao do processo");

        Interessado interessado = new Interessado();
        interessado.setNome("Leonardo Dias de Oliveira");
        interessado.setSigla("04642559701");
        Interessado[] interessados = {interessado};

        procedimento.setInteressados(interessados);

        procedimento.setObservacao("Obs");
        procedimento.setNivelAcesso("0"); // 0 = Publico, 1 = Restrito, 2 = Sigiloso
        procedimento.setIdTipoProcedimento("100000346"); // Tipo de Processo => Adesão de atas
//
//
//
////
//        Documento[] documentos = {documento};
//
//        RetornoGeracaoProcedimento retornoGeracaoProcedimento = seiBindingStub.gerarProcedimento("UNB",
//                "testeunb",
//                "110001972",
//                procedimento, null,
//                null,
//                null, "S", "N", null, null, null, null, null);
//
//        System.out.println("************ RetornoGeracaoProcedimento = " + retornoGeracaoProcedimento.getProcedimentoFormatado());
//        System.out.println("************ RetornoGeracaoProcedimento = " + retornoGeracaoProcedimento.getLinkAcesso());

        Documento documento = new Documento();
        documento.setIdProcedimento("03154000037201729");
        documento.setDescricao("Meu documento 5");
        documento.setNomeArquivo("PaytoStudy_Student_Guide_HiBonjour_PT.pdf");
        documento.setConteudo(Base64Utils.encodeToString(FileUtils.readFileToByteArray(new File("/home/leonardo/Downloads/PaytoStudy_Student_Guide_HiBonjour_PT.pdf"))));
        documento.setTipo("R");
        documento.setIdSerie("1");
        documento.setData("16/08/2017");

        RetornoInclusaoDocumento retornoInclusaoDocumento = seiBindingStub.incluirDocumento("UNB", "testeunb", "110001972", documento);
        System.out.println("Link = " + retornoInclusaoDocumento.getLinkAcesso());
    }
}
