package Sei;

public class SeiPortTypeProxy implements Sei.SeiPortType {
  private String _endpoint = null;
  private Sei.SeiPortType seiPortType = null;
  
  public SeiPortTypeProxy() {
    _initSeiPortTypeProxy();
  }
  
  public SeiPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initSeiPortTypeProxy();
  }
  
  private void _initSeiPortTypeProxy() {
    try {
      seiPortType = (new Sei.SeiServiceLocator()).getSeiPortService();
      if (seiPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)seiPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)seiPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (seiPortType != null)
      ((javax.xml.rpc.Stub)seiPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public Sei.SeiPortType getSeiPortType() {
    if (seiPortType == null)
      _initSeiPortTypeProxy();
    return seiPortType;
  }
  
  public Sei.RetornoGeracaoProcedimento gerarProcedimento(java.lang.String siglaSistema, java.lang.String identificacaoServico, java.lang.String idUnidade, Sei.Procedimento procedimento, Sei.Documento[] documentos, java.lang.String[] procedimentosRelacionados, java.lang.String[] unidadesEnvio, java.lang.String sinManterAbertoUnidade, java.lang.String sinEnviarEmailNotificacao, java.lang.String dataRetornoProgramado, java.lang.String diasRetornoProgramado, java.lang.String sinDiasUteisRetornoProgramado, java.lang.String idMarcador, java.lang.String textoMarcador) throws java.rmi.RemoteException{
    if (seiPortType == null)
      _initSeiPortTypeProxy();
    return seiPortType.gerarProcedimento(siglaSistema, identificacaoServico, idUnidade, procedimento, documentos, procedimentosRelacionados, unidadesEnvio, sinManterAbertoUnidade, sinEnviarEmailNotificacao, dataRetornoProgramado, diasRetornoProgramado, sinDiasUteisRetornoProgramado, idMarcador, textoMarcador);
  }
  
  public Sei.RetornoInclusaoDocumento incluirDocumento(java.lang.String siglaSistema, java.lang.String identificacaoServico, java.lang.String idUnidade, Sei.Documento documento) throws java.rmi.RemoteException{
    if (seiPortType == null)
      _initSeiPortTypeProxy();
    return seiPortType.incluirDocumento(siglaSistema, identificacaoServico, idUnidade, documento);
  }
  
}